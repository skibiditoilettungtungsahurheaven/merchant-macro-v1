"""Окно (UI) для Merchant Macro (покупает выбранные товары у Mysterious Merchant). Логика зрения/кликов — в potion_macro.py."""
import base64
import ctypes
import json
import math
import os
import queue
import random
import threading
import time
import tkinter as tk
from ctypes import wintypes

import cv2
import numpy as np

import potion_macro as pm

if not (hasattr(pm, "identify_stock") and hasattr(pm, "check_update") and hasattr(pm, "card_shows")):  # новый macro_gui.pyw, а potion_macro.py старый
    from tkinter import messagebox
    _r = tk.Tk()
    _r.withdraw()
    messagebox.showerror("Merchant Macro", "potion_macro.py is outdated — copy the new potion_macro.py too.\n\n"
                                           "Файл potion_macro.py старый — скопируй и новый potion_macro.py тоже.")
    raise SystemExit(1)

CONFIG = pm.CONFIG
DEFAULTS = {"buttons": None, "scan_interval": 10, "clicks": 3, "open_key": "",
            "jump_interval": 300,
            "hotkeys": {"start": "F3", "check": "F11", "calib": "F7", "exit": "F10"},
            "webhook": "", "webhook_on": True, "webhook_text": None, "lang": "en",
            "discord_id": "", "ping_stock": True,
            "hook_success": True, "ping_success": True, "hook_fail": True, "ping_fail": True,
            "theme": "purple", "enhanced": False,
            # товары: порядок = приоритет (сверху важнее), items_on — что вообще покупать
            "items_order": [i for i, _ in pm.ITEMS], "items_on": ["large", "small"],
            # погода: о каких погодах сообщать (по умолчанию ни о каких), пинг и ссылка на приватный сервер
            "weather_on": [], "weather_ping": True, "weather_link": "",
            "update_skipped": ""}   # версия, от обновления до которой отказались: окно о ней больше не показываем

HOTKEYS = ("start", "check", "calib", "exit")
SPECIAL_VK = {"INSERT": 0x2D, "DELETE": 0x2E, "HOME": 0x24, "END": 0x23, "PRIOR": 0x21, "NEXT": 0x22,
              "PAGEUP": 0x21, "PAGEDOWN": 0x22, "PAUSE": 0x13, "SCROLLLOCK": 0x91}

# ---------------- ПЕРЕВОДЫ / TRANSLATIONS ----------------
LANGS = {"en": "English", "ru": "Russian", "es": "Spanish"}
TEXT = {
    "status_calib": ("● Calibration needed", "● Нужна калибровка"),
    "status_run": ("● Running   ·   buy attempts: {n}", "● Работает   ·   куплено попыток: {n}"),
    "status_pause": ("● Paused", "● На паузе"),
    "btn_start": ("▶  Start  ({k})", "▶  Старт  ({k})"),
    "btn_pause": ("⏸  Pause  ({k})", "⏸  Пауза  ({k})"),
    "btn_check": ("Check now ({k})", "Проверить сейчас ({k})"),
    "tab_main": ("Main", "Главное"),
    "tab_settings": ("Settings", "Настройки"),
    "tab_discord": ("Discord", "Discord"),
    "p_calib": ("Calibration", "Калибровка"),
    "btn_reset_calib": ("Reset calibration", "Сбросить калибровку"),
    "p_preview": ("What the macro sees", "Что видит макрос"),
    "preview_empty": ("(press “Check now”)", "(нажми «Проверить сейчас»)"),
    "p_log": ("Log", "Лог"),
    "p_macro": ("Macro", "Макрос"),
    "f_interval": ("Check every (sec):", "Проверять каждые (сек):"),
    "f_clicks": ("Clicks on TAP TO TRADE:", "Кликов по TAP TO TRADE:"),
    "f_openkey": ("Key to open the merchant\n(empty — don't press):",
                  "Клавиша открытия торговца\n(пусто — не нажимать):"),
    "f_jump": ("Anti-AFK: jump every (sec)\n(0 — off):", "Анти-АФК: прыжок каждые (сек)\n(0 — выключено):"),
    "c_top": ("Keep this window on top", "Окно макроса поверх всех окон"),
    "btn_testjump": ("Test jump (in 3 sec)", "Тест прыжка (через 3 сек)"),
    "p_discord": ("Discord webhook", "Вебхук Discord"),
    "l_hook": ("Webhook URL:", "Ссылка вебхука:"),
    "l_hooktext": ("Message text (@everyone works):", "Текст сообщения (можно @everyone):"),
    "c_hookon": ("Send the stock screenshot once an hour (on refresh)", "Скрин стока раз в час (при обновлении)"),
    "c_hooksuccess": ("Send screenshot when an item is bought successfully",
                      "Скрин, когда вещь купилась успешно (SUCCESS!)"),
    "c_hookfail": ("Send screenshot when the purchase failed", "Скрин, когда покупка провалилась (FAILED)"),
    "c_ping": ("Ping me", "Пинговать меня"),
    "p_events": ("When to send", "Когда отправлять"),
    "l_userid": ("Your Discord user ID (for pings):", "Твой ID в Discord (для пингов):"),
    "id_help": ("How to get the ID: Discord → Settings → Advanced → turn on Developer Mode, then right-click "
                "your name → Copy User ID.",
                "Как узнать ID: Discord → Настройки → Расширенные → включи Режим разработчика, потом ПКМ "
                "по своему нику → Копировать ID пользователя."),
    "log_id_bad": ("Discord: the user ID must be digits only — no ping until it's fixed.",
                   "Discord: ID должен состоять только из цифр — пока не исправишь, пинга не будет."),
    "buy_success": ("✅ Purchase succeeded: slot {n} — {kind}", "✅ Покупка удалась: слот {n} — {kind}"),
    "buy_fail": ("❌ Purchase failed: slot {n} — {kind}", "❌ Покупка провалилась: слот {n} — {kind}"),
    "log_buy_success": ("SUCCESS! The purchase went through.", "SUCCESS! Покупка удалась."),
    "log_buy_fail": ("FAILED — the purchase didn't go through.", "FAILED — покупка провалилась."),
    "log_buy_unknown": ("Didn't see SUCCESS!/FAILED after clicking.", "После кликов не увидел SUCCESS!/FAILED."),
    "log_buy_changed": ("The card changed or the merchant window closed — not clicking.",
                        "Карточка сменилась или окно торговца закрылось — не кликаю."),
    "log_buy_gone": ("The colours near the button changed, but the merchant card with this item isn't on screen — "
                     "that's not a purchase result, not reporting it.",
                     "Цвет на месте кнопки сменился, но карточки торговца с этим товаром на экране нет — "
                     "это не результат покупки, не сообщаю."),
    "log_already": ("Already traded this hour — waiting for new deals.",
                    "В этом часу сделка уже была — жду новый сток."),
    "btn_testhook": ("Send a test screenshot", "Отправить тестовый скрин"),
    "hook_help": ("How to get the URL: Discord → channel settings → Integrations → Webhooks → "
                  "New Webhook → Copy Webhook URL.",
                  "Как получить ссылку: Discord → настройки канала → Интеграции → Вебхуки → "
                  "Новый вебхук → Копировать URL вебхука."),
    "hook_default": ("🧪 New merchant stock!", "🧪 Новый сток у торговца!"),
    "p_hotkeys": ("Hotkeys — click a field and press a key", "Горячие клавиши — кликни в поле и нажми клавишу"),
    "hk_start": ("Start/pause", "Старт/пауза"),
    "hk_check": ("Check", "Проверка"),
    "hk_calib": ("Calibrate", "Калибровка"),
    "hk_exit": ("Exit", "Выход"),
    "hk_allowed": ("Allowed: F1–F12, Insert, Home, End, PageUp, PageDown, Pause, Delete",
                   "Можно: F1–F12, Insert, Home, End, PageUp, PageDown, Pause, Delete"),
    "calib_progress": ("Saved {n}/3. Hover TAP TO TRADE of slot {next} and press {k}.",
                       "Записано {n}/3. Наведи на TAP TO TRADE слота {next} и нажми {k}."),
    "calib_done": ("✔ Done:  ", "✔ Готово:  "),
    "calib_help": ("Open the merchant. Hover TAP TO TRADE of slot 1 → {k}, slot 2 → {k}, slot 3 → {k}.",
                   "Открой торговца. Наведи мышь на TAP TO TRADE слота 1 → {k}, слота 2 → {k}, слота 3 → {k}."),
    "log_ready": ("Ready. {c} — calibrate, {s} — start/pause, {e} — exit.",
                  "Готово. {c} — калибровка, {s} — старт/пауза, {e} — выход."),
    "log_badkey": ("Can't use “{k}”: Roblox uses it too. Pick F1–F12, Insert, Home…",
                   "Клавишу «{k}» нельзя: Roblox тоже её ловит. Возьми F1–F12, Insert, Home…"),
    "log_keybusy": ("{k} is already used for “{a}”.", "{k} уже занята под «{a}»."),
    "log_keyset": ("“{a}” is now on {k}.", "«{a}» теперь на {k}."),
    "log_need_calib": ("Calibrate first ({k} three times).", "Сначала калибровка ({k} три раза)."),
    "log_start": ("STARTED", "СТАРТ"),
    "log_pause": ("PAUSED", "ПАУЗА"),
    "log_calib_reset": ("Calibration reset.", "Калибровка сброшена."),
    "log_calib_point": ("Slot {n} button: {x},{y}", "Кнопка слота {n}: {x},{y}"),
    "log_calib_saved": ("Calibration saved.", "Калибровка сохранена."),
    "why_afk": ("Anti-AFK", "Анти-АФК"),
    "why_test": ("Test", "Тест"),
    "log_jump": ("{why}: jump.", "{why}: прыжок."),
    "log_testjump": ("Jump test: click the Roblox window, jumping in 3 sec…",
                     "Тест прыжка: кликни по окну Roblox, прыжок через 3 сек…"),
    "log_hook_none": ("Discord: paste the webhook URL first.", "Discord: сначала вставь ссылку вебхука."),
    "log_hook_bad": ("Discord: that doesn't look like a webhook URL (it should start with "
                     "https://discord.com/api/webhooks/).",
                     "Discord: это не похоже на ссылку вебхука (должна начинаться с "
                     "https://discord.com/api/webhooks/)."),
    "log_hook_ok": ("Discord: sent.", "Discord: отправлено."),
    "log_hook_err": ("Discord: error — {m}.", "Discord: ошибка — {m}."),
    "log_hook_testing": ("Discord: sending a test screenshot…", "Discord: отправляю тестовый скрин…"),
    "hook_test_msg": ("✅ Webhook test — this is how the screenshot will look.",
                      "✅ Тест вебхука — так будет выглядеть скрин."),
    "stock_potions": ("Stock: {list}", "Сток: {list}"),
    "stock_slot": ("slot {n}: {kind}", "слот {n}: {kind}"),
    "stock_none": ("Couldn't read the items.", "Не смог прочитать товары."),
    "log_stock_saved": ("Stock saved. I'll send a screenshot when it refreshes.",
                        "Сток запомнен. Пришлю скрин, когда он обновится."),
    "log_stock_new": ("The merchant's stock refreshed!", "Сток у торговца обновился!"),
    "log_stock_hour": ("An hour has passed and I didn't see the stock refresh — sending the stock anyway.",
                       "Прошёл час, а обновление стока я не заметил — отправляю сток и так."),
    "log_stock_early": ("The stock changed, but the hourly screenshot isn't due for another {m} min — not sending.",
                        "Сток сменился, но до ежечасного скрина ещё {m} мин — не отправляю."),
    "log_popup": ("Reward window “CLICK ANYWHERE TO CLOSE” — closing it.",
                  "Окно награды «CLICK ANYWHERE TO CLOSE» — закрываю."),
    "log_popup_test": ("I see “CLICK ANYWHERE TO CLOSE” — while running I'll click once to close it.",
                       "Вижу «CLICK ANYWHERE TO CLOSE» — во время работы кликну 1 раз, чтобы закрыть."),
    "log_timer_reset": ("Timer jumped to 59:xx — new deals!", "Таймер перескочил на 59:xx — новые сделки!"),
    "log_timer_five": ("Timer: minutes start with 5 (50–59 min left).",
                       "Таймер: минуты начинаются с 5 (осталось 50–59 мин)."),
    "log_timer_other": ("Timer: under 50 min left.", "Таймер: осталось меньше 50 мин."),
    "log_timer_none": ("Timer: can't see “New deals in” — is the merchant open?",
                       "Таймер: не вижу «New deals in» — торговец открыт?"),
    "log_no_potion": ("Can't see the items — is the merchant open?", "Не вижу товаров — торговец открыт?"),
    "log_seen_none": ("Items: {seen}. Nothing from your list.", "Товары: {seen}. Из твоего списка ничего нет."),
    "log_unsure": ("Items: {seen}. Not sure about one card yet — waiting, so I don't buy the wrong one.",
                   "Товары: {seen}. Одну карточку пока не узнал точно — жду, чтобы не купить не то."),
    "log_too_small": ("The Roblox window is too small to read item names — make it bigger and recalibrate (F7).",
                      "Окно Roblox слишком маленькое — названия не прочитать. Сделай его больше и перекалибруй (F7)."),
    "slot_kind": ("slot {n}: {kind}", "слот {n}: {kind}"),
    "log_seen_test": ("Items: {seen}. Picked slot {n} — {kind} (test, no click).",
                      "Товары: {seen}. Выбрал слот {n} — {kind} (тест, без клика)."),
    "log_buying": ("Items: {seen}. Buying slot {n} — {kind}!", "Товары: {seen}. Покупаю слот {n} — {kind}!"),
    "log_clicked": ("Clicked TAP TO TRADE {c} times.", "Кликнул {c} раз по TAP TO TRADE."),
    "log_error": ("Error: {e}", "Ошибка: {e}"),
    "log_lang": ("Language: English", "Язык: Русский"),
    "kind_unknown": ("unknown", "неизвестно"),
    "tab_items": ("Items", "Предметы"),
    "p_items": ("What to buy", "Что покупать"),
    "items_help": ("Tick the items to buy. ▲▼ set the priority: if several ticked items are in stock, "
                   "the macro buys the one that is higher in the list.",
                   "Отметь галочкой, что покупать. Стрелки ▲▼ задают приоритет: если в стоке несколько "
                   "отмеченных, макро купит тот, что выше в списке."),
    "log_items_empty": ("Nothing is ticked in “Items” — I won't buy anything.",
                        "Во вкладке «Предметы» ничего не отмечено — покупать нечего."),
    "tab_important": ("IMPORTANT", "ВАЖНО"),
    "p_important": ("Important", "Важно"),
    "important_text": ("If you happen to get a \"double cutscene\" your merchant window will close, the only way to get "
                       "around this is by standing on the merchant's head with the anti-afk jump cuz it jumps just "
                       "high enough to close and open the merchant window again.",
                       "Если выпадет «двойная катсцена», окно торговца закроется. Обойти это можно только так: встань "
                       "на голову торговцу и включи анти-АФК прыжок — он прыгает ровно настолько высоко, чтобы окно "
                       "торговца закрылось и снова открылось."),
    "tab_credits": ("Credits", "Благодарности"),
    "p_credits": ("Credits", "Благодарности"),
    "credits_text": ("Credits: the macro has Spanish language due to this guy, say thanks to him",
                     "Благодарности: испанский язык в макросе появился благодаря этому человеку, скажи ему спасибо"),
    "p_theme": ("Theme", "Тема"),
    "log_theme": ("Theme: {t}", "Тема: {t}"),
    "tab_better": ("Better Themes", "Лучшие темы"),
    "p_better": ("Better Themes", "Лучшие темы"),
    "c_enhance": ("Enhances UI themes (eats some RAM and CPU)", "Улучшает интерфейс тем (ест немного ОЗУ и ЦП)"),
    "log_enh_on": ("Enhanced themes: ON", "Улучшенные темы: ВКЛ"),
    "log_enh_off": ("Enhanced themes: OFF", "Улучшенные темы: ВЫКЛ"),
    "theme_purple": ("Purple", "Фиолетовая"),
    "theme_sky": ("Ocean", "Океан"),
    "theme_emerald": ("Emerald", "Изумруд"),
    "theme_crimson": ("Crimson", "Багровая"),
    "theme_futuristic": ("Futuristic", "Футуризм"),
    "theme_gold": ("Gold", "Золото"),
    "theme_sakura": ("Sakura", "Сакура"),
    "theme_light": ("Light", "Светлая"),
    "tab_weather": ("Weather", "Погода"),
    "p_weather": ("Weather detection", "Детект погоды"),
    "weather_help": ("Tick the weathers you want to hear about. While the macro is running it watches the icon row "
                     "at the top of the screen. When a ticked weather starts, it writes to the log and sends "
                     "a screenshot to Discord (the webhook from the Discord tab). It reacts only to the weather "
                     "icon itself — the square with a coloured frame and a timer that appears at the left of that "
                     "row — never to the colours of the screen.",
                     "Отметь погоды, о которых сообщать. Пока макро работает, он следит за рядом иконок вверху "
                     "экрана. Когда начинается отмеченная погода, он пишет в лог и шлёт скрин в Discord "
                     "(вебхук со вкладки Discord). Он реагирует только на саму иконку погоды — квадрат с цветной "
                     "рамкой и таймером, который появляется слева в этом ряду, — а не на цвет экрана."),
    "p_weather_msg": ("Discord message", "Сообщение в Discord"),
    "l_weather_link": ("Private server link (optional, added to the message):",
                       "Ссылка на приватный сервер (не обязательно, добавится в сообщение):"),
    "btn_weather_check": ("Check weather now", "Проверить погоду сейчас"),
    "weather_msg": ("{e} Weather: {w}!", "{e} Погода: {w}!"),
    "log_weather_start": ("Weather started: {w}.", "Началась погода: {w}."),
    "log_weather_end": ("Weather is over: {w}.", "Погода закончилась: {w}."),
    "log_weather_now": ("Weather now: {list}.", "Погода сейчас: {list}."),
    "log_weather_none": ("Weather: no weather icon in the top row (closest: {w}, {p}%; {min}% is needed).",
                         "Погода: иконки погоды в верхнем ряду нет (ближе всего {w}, {p}%; нужно {min}%)."),
    "log_weather_fake": ("Weather: no weather icon in the top row. Something there looks like {w} ({p}%), but it is "
                         "not a weather icon (no coloured frame with a timer), so it doesn't count.",
                         "Погода: иконки погоды в верхнем ряду нет. Что-то там похоже на {w} ({p}%), но это не иконка "
                         "погоды (нет цветной рамки с таймером) — не считается."),
    "log_weather_noscreen": ("Weather: the top icon row doesn't fit on the screen — check the calibration.",
                             "Погода: ряд иконок вверху не помещается на экран — проверь калибровку."),
    "log_weather_nohook": ("Weather: no Discord webhook yet — I'll only write to the log.",
                           "Погода: вебхук Discord не указан — буду писать только в лог."),
    "upd_title": ("A New Update Is Available!", "Доступно новое обновление!"),
    "upd_ver": ("Version {new} (you have {old})", "Версия {new} (у тебя {old})"),
    "upd_yes": ("Update", "Обновить"),
    "upd_no": ("No, thanks.", "Нет, спасибо."),
    "upd_sure": ("Are you sure you don't wanna update the macro?", "Ты точно не хочешь обновить макро?"),
    "upd_sure_yes": ("Yes", "Да"),
    "upd_sure_no": ("No", "Нет"),
    "upd_working": ("Downloading the update…", "Скачиваю обновление…"),
    "upd_failed": ("Couldn't update: {e}", "Не получилось обновить: {e}"),
    "log_upd_found": ("A new update is available: version {new} (you have {old}).",
                      "Доступно новое обновление: версия {new} (у тебя {old})."),
    "log_upd_later": ("The update window will open when you pause the macro.",
                      "Окно обновления откроется, когда поставишь макро на паузу."),
    "log_upd_skip": ("OK, not updating. I won't ask about version {new} again — only when a newer one comes out.",
                     "Хорошо, не обновляю. Про версию {new} больше не спрошу — только когда выйдет следующая."),
    "log_upd_done": ("Updated to version {new}. Restarting the macro…",
                     "Обновлено до версии {new}. Перезапускаю макро…"),
}

# Español — gracias a Nakoshi
TEXT_ES = {
    "status_calib": "● Falta calibrar",
    "status_run": "● Funcionando   ·   intentos de compra: {n}",
    "status_pause": "● En pausa",
    "btn_start": "▶  Iniciar  ({k})",
    "btn_pause": "⏸  Pausa  ({k})",
    "btn_check": "Revisar ahora ({k})",
    "tab_main": "Principal",
    "tab_settings": "Ajustes",
    "tab_discord": "Discord",
    "p_calib": "Calibración",
    "btn_reset_calib": "Reiniciar calibración",
    "p_preview": "Lo que ve el macro",
    "preview_empty": "(pulsa «Revisar ahora»)",
    "p_log": "Registro",
    "p_macro": "Macro",
    "f_interval": "Revisar cada (seg):",
    "f_clicks": "Clics en TAP TO TRADE:",
    "f_openkey": "Tecla para abrir al mercader\n(vacío — no pulsar):",
    "f_jump": "Anti-AFK: saltar cada (seg)\n(0 — desactivado):",
    "c_top": "Mantener esta ventana encima",
    "btn_testjump": "Probar salto (en 3 seg)",
    "p_discord": "Webhook de Discord",
    "l_hook": "URL del webhook:",
    "l_hooktext": "Texto del mensaje (@everyone funciona):",
    "c_hookon": "Captura del stock una vez por hora (al cambiar)",
    "c_hooksuccess": "Enviar captura cuando la compra salga bien (SUCCESS!)",
    "c_hookfail": "Enviar captura cuando la compra falle (FAILED)",
    "c_ping": "Mencionarme",
    "p_events": "Cuándo enviar",
    "l_userid": "Tu ID de usuario de Discord (para menciones):",
    "id_help": ("Cómo obtener el ID: Discord → Ajustes → Avanzado → activa el Modo desarrollador, luego clic "
                "derecho en tu nombre → Copiar ID de usuario."),
    "log_id_bad": "Discord: el ID solo debe tener números — no habrá mención hasta que lo corrijas.",
    "buy_success": "✅ Compra exitosa: casilla {n} — {kind}",
    "buy_fail": "❌ Compra fallida: casilla {n} — {kind}",
    "log_buy_success": "SUCCESS! La compra salió bien.",
    "log_buy_fail": "FAILED — la compra falló.",
    "log_buy_unknown": "No vi SUCCESS!/FAILED después de hacer clic.",
    "log_buy_changed": "La carta cambió o la ventana del mercader se cerró — no hago clic.",
    "log_buy_gone": ("Los colores junto al botón cambiaron, pero la carta del mercader con este artículo no está "
                     "en pantalla — no es el resultado de una compra, no lo aviso."),
    "log_already": "El trato de esta hora ya se hizo — espero las nuevas ofertas.",
    "btn_testhook": "Enviar captura de prueba",
    "hook_help": ("Cómo obtener la URL: Discord → ajustes del canal → Integraciones → Webhooks → "
                  "Nuevo webhook → Copiar URL del webhook."),
    "hook_default": "🧪 ¡Nuevo stock del mercader!",
    "p_hotkeys": "Teclas rápidas — haz clic en un campo y pulsa una tecla",
    "hk_start": "Iniciar/pausa",
    "hk_check": "Revisar",
    "hk_calib": "Calibrar",
    "hk_exit": "Salir",
    "hk_allowed": "Permitidas: F1–F12, Insert, Home, End, PageUp, PageDown, Pause, Delete",
    "calib_progress": "Guardado {n}/3. Pon el ratón sobre TAP TO TRADE de la casilla {next} y pulsa {k}.",
    "calib_done": "✔ Listo:  ",
    "calib_help": ("Abre al mercader. Pon el ratón sobre TAP TO TRADE de la casilla 1 → {k}, casilla 2 → {k}, "
                   "casilla 3 → {k}."),
    "log_ready": "Listo. {c} — calibrar, {s} — iniciar/pausa, {e} — salir.",
    "log_badkey": "No se puede usar «{k}»: Roblox también la usa. Elige F1–F12, Insert, Home…",
    "log_keybusy": "{k} ya se usa para «{a}».",
    "log_keyset": "«{a}» ahora está en {k}.",
    "log_need_calib": "Primero calibra ({k} tres veces).",
    "log_start": "INICIADO",
    "log_pause": "EN PAUSA",
    "log_calib_reset": "Calibración reiniciada.",
    "log_calib_point": "Botón de la casilla {n}: {x},{y}",
    "log_calib_saved": "Calibración guardada.",
    "why_afk": "Anti-AFK",
    "why_test": "Prueba",
    "log_jump": "{why}: salto.",
    "log_testjump": "Prueba de salto: haz clic en la ventana de Roblox, salto en 3 seg…",
    "log_hook_none": "Discord: primero pega la URL del webhook.",
    "log_hook_bad": ("Discord: eso no parece una URL de webhook (debe empezar con "
                     "https://discord.com/api/webhooks/)."),
    "log_hook_ok": "Discord: enviado.",
    "log_hook_err": "Discord: error — {m}.",
    "log_hook_testing": "Discord: enviando captura de prueba…",
    "hook_test_msg": "✅ Prueba del webhook — así se verá la captura.",
    "stock_potions": "Stock: {list}",
    "stock_slot": "casilla {n}: {kind}",
    "stock_none": "No pude leer los artículos.",
    "log_stock_saved": "Stock guardado. Enviaré una captura cuando cambie.",
    "log_stock_new": "¡El stock del mercader cambió!",
    "log_stock_hour": "Pasó una hora y no vi cambiar el stock — envío el stock de todos modos.",
    "log_stock_early": "El stock cambió, pero faltan {m} min para la captura de esta hora — no la envío.",
    "log_popup": "Ventana de recompensa «CLICK ANYWHERE TO CLOSE» — la cierro.",
    "log_popup_test": "Veo «CLICK ANYWHERE TO CLOSE» — en marcha haré un clic para cerrarla.",
    "log_timer_reset": "El temporizador saltó a 59:xx — ¡nuevas ofertas!",
    "log_timer_five": "Temporizador: los minutos empiezan con 5 (quedan 50–59 min).",
    "log_timer_other": "Temporizador: quedan menos de 50 min.",
    "log_timer_none": "Temporizador: no veo «New deals in» — ¿está abierto el mercader?",
    "log_no_potion": "No veo los artículos — ¿está abierto el mercader?",
    "log_seen_none": "Artículos: {seen}. Nada de tu lista.",
    "log_unsure": "Artículos: {seen}. Aún no estoy seguro de una carta — espero para no comprar la equivocada.",
    "log_too_small": "La ventana de Roblox es demasiado pequeña para leer los nombres — hazla más grande y recalibra (F7).",
    "slot_kind": "casilla {n}: {kind}",
    "log_seen_test": "Artículos: {seen}. Elegí la casilla {n} — {kind} (prueba, sin clic).",
    "log_buying": "Artículos: {seen}. ¡Comprando la casilla {n} — {kind}!",
    "log_clicked": "Hice clic en TAP TO TRADE {c} veces.",
    "log_error": "Error: {e}",
    "log_lang": "Idioma: Español",
    "kind_unknown": "desconocido",
    "tab_items": "Artículos",
    "p_items": "Qué comprar",
    "items_help": "Marca lo que quieres comprar. ▲▼ ordenan la prioridad: si hay varios marcados en el stock, "
                  "el macro compra el que está más arriba en la lista.",
    "log_items_empty": "No hay nada marcado en «Artículos» — no compraré nada.",
    "tab_important": "IMPORTANTE",
    "p_important": "Importante",
    "important_text": "Si te sale una \"doble cinemática\", la ventana del mercader se cerrará. La única forma de "
                      "evitarlo es pararte sobre la cabeza del mercader con el salto anti-AFK, porque salta justo lo "
                      "suficiente para cerrar y volver a abrir la ventana del mercader.",
    "tab_credits": "Créditos",
    "p_credits": "Créditos",
    "credits_text": "Créditos: el macro tiene idioma español gracias a este chico, dale las gracias",
    "p_theme": "Tema",
    "log_theme": "Tema: {t}",
    "tab_better": "Mejores temas",
    "p_better": "Mejores temas",
    "c_enhance": "Mejora la interfaz de los temas (consume algo de RAM y CPU)",
    "log_enh_on": "Temas mejorados: SÍ",
    "log_enh_off": "Temas mejorados: NO",
    "theme_purple": "Morado",
    "theme_sky": "Océano",
    "theme_emerald": "Esmeralda",
    "theme_crimson": "Carmesí",
    "theme_futuristic": "Futurista",
    "theme_gold": "Oro",
    "theme_sakura": "Sakura",
    "theme_light": "Claro",
    "tab_weather": "Clima",
    "p_weather": "Detección del clima",
    "weather_help": "Marca los climas de los que quieres que te avise. Mientras el macro funciona, vigila la fila de "
                    "iconos de la parte superior de la pantalla. Cuando empieza un clima marcado, lo escribe en el "
                    "registro y envía una captura a Discord (el webhook de la pestaña Discord). Solo reacciona al "
                    "propio icono del clima — el cuadro con marco de color y temporizador que aparece a la izquierda "
                    "de esa fila —, nunca a los colores de la pantalla.",
    "p_weather_msg": "Mensaje de Discord",
    "l_weather_link": "Enlace del servidor privado (opcional, se añade al mensaje):",
    "btn_weather_check": "Revisar el clima ahora",
    "weather_msg": "{e} ¡Clima: {w}!",
    "log_weather_start": "Empezó el clima: {w}.",
    "log_weather_end": "Terminó el clima: {w}.",
    "log_weather_now": "Clima ahora: {list}.",
    "log_weather_none": "Clima: no hay icono de clima en la fila superior (lo más parecido: {w}, {p}%; "
                        "hace falta {min}%).",
    "log_weather_fake": "Clima: no hay icono de clima en la fila superior. Algo ahí se parece a {w} ({p}%), pero no "
                        "es un icono de clima (no tiene marco de color con temporizador), así que no cuenta.",
    "log_weather_noscreen": "Clima: la fila de iconos de arriba no cabe en la pantalla — revisa la calibración.",
    "log_weather_nohook": "Clima: aún no hay webhook de Discord — solo escribiré en el registro.",
    "upd_title": "¡Hay una nueva actualización!",
    "upd_ver": "Versión {new} (tienes la {old})",
    "upd_yes": "Actualizar",
    "upd_no": "No, gracias.",
    "upd_sure": "¿Seguro que no quieres actualizar el macro?",
    "upd_sure_yes": "Sí",
    "upd_sure_no": "No",
    "upd_working": "Descargando la actualización…",
    "upd_failed": "No se pudo actualizar: {e}",
    "log_upd_found": "Hay una nueva actualización: versión {new} (tienes la {old}).",
    "log_upd_later": "La ventana de actualización se abrirá cuando pongas el macro en pausa.",
    "log_upd_skip": "Vale, no actualizo. No volveré a preguntar por la versión {new}, solo cuando salga otra más nueva.",
    "log_upd_done": "Actualizado a la versión {new}. Reiniciando el macro…",
}
assert set(TEXT_ES) == set(TEXT), sorted(set(TEXT) ^ set(TEXT_ES))
for _k, _v in TEXT_ES.items():
    TEXT[_k] = TEXT[_k] + (_v,)
LANG_INDEX = {"en": 0, "ru": 1, "es": 2}

# Превью «Что видит макрос» подстраивается под ширину окна, но не больше этого размера.
PREVIEW_W, PREVIEW_H = 720, 720

# Как часто смотреть на таймер «New deals in» (сек), чтобы прислать скрин ровно на 59:59.
TIMER_CHECK_SEC = 0.1
# Сток шлётся раз в час — один скрин на 60 минут. Обычно скрин уходит в ту же секунду, когда сток обновился:
# обновление, замеченное не раньше чем за STOCK_EARLY_SEC до конца часа, сразу заканчивает этот час, и следующий
# считается от него. Обновление, «замеченное» раньше, — повтор (экран ожил после сворачивания RDP): скрин не шлём.
# Если обновление не замечено вовсе (окно торговца было закрыто, таймер не прочитался), через STOCK_LATE_SEC
# после конца часа сток уходит и так — как только окно торговца видно; следующий час при этом считается от
# прежнего срока, а не от опоздавшего скрина.
STOCK_PERIOD_SEC = 60 * 60
STOCK_EARLY_SEC = 10 * 60
STOCK_LATE_SEC = 2 * 60
STOCK_SAME_SEC = 5 * 60       # два способа замечают одно и то же обновление — второе «обновление» за это время не в счёт
# После удачной сделки те же три карточки висят до нового стока: жать их снова незачем («Pick one, and only one»).
# Через 55 минут забываем — на случай, если новый сток окажется точно таким же.
BOUGHT_HOLD_SEC = 55 * 60
# После перескока таймера на 59:59 карточки меняются не разом — столько секунд сток не читаем и не покупаем.
REFRESH_SETTLE_SEC = 2.5

# Как часто искать окно «CLICK ANYWHERE TO CLOSE» (сек). Одна проверка ~25 мс — почти не грузит.
POPUP_CHECK_SEC = 0.5
# Погода: как часто смотреть на ряд иконок вверху экрана (сек; одна проверка ~50 мс), сколько проверок подряд
# иконка должна быть видна, чтобы сообщить, и через сколько секунд без иконки погода считается закончившейся
# (раньше этого срока о той же погоде второй раз не сообщаем: ряд иконок пропадает на время катсцен).
WEATHER_CHECK_SEC = 1.0
UPDATE_CHECK_SEC = 3600       # раз во сколько секунд смотреть, не вышла ли новая версия (первый раз — сразу при запуске)
WEATHER_HITS = 2
WEATHER_GAP_SEC = 60
WEATHER_EMOJI = {"rainy": "\U0001F327\uFE0F", "foggy": "\U0001F32B\uFE0F", "thunderstorm": "\u26C8\uFE0F",
                 "full_moon": "\U0001F315", "solar_eclipse": "\U0001F311"}
ITEM_ROW_H = 30   # высота строки во вкладке «Предметы»

# Куда поворачивается стрелка при открытии списка: 90 — вниз, -90 — вверх.
CHEVRON_OPEN_ANGLE = 90


def key_to_vk(name):
    """'F9' / 'Insert' / 'Home' -> код клавиши Windows, или None."""
    n = (name or "").strip().upper().replace(" ", "").replace("_", "")
    if len(n) >= 2 and n[0] == "F" and n[1:].isdigit() and 1 <= int(n[1:]) <= 24:
        return 0x70 + int(n[1:]) - 1
    return SPECIAL_VK.get(n)


# ---------------- ТЕМЫ / THEMES ----------------
# bg, panel, fg, muted, accent, текст на accent, hover, шрифт, жирный шрифт, моноширинный
_SEGOE = ("Segoe UI", "Segoe UI Semibold", "Consolas")
THEMES = {
    "purple":     ("#16141f", "#221f2e", "#ece9f5", "#9a94ad", "#8b5cf6", "#ffffff", "#2e2a3d") + _SEGOE,
    "sky":        ("#0e1623", "#172335", "#e7f4ff", "#8ba6c4", "#38bdf8", "#04121d", "#213149") + _SEGOE,
    "emerald":    ("#0c1713", "#14241d", "#e6fbf1", "#87a99a", "#10b981", "#03140d", "#1d3429") + _SEGOE,
    "crimson":    ("#1a0e11", "#29161b", "#fdeef0", "#b08f96", "#f43f5e", "#ffffff", "#3a2026") + _SEGOE,
    "futuristic": ("#05070d", "#0a101b", "#d6f6ff", "#4f7a91", "#00e5ff", "#001018", "#102236",
                   "Bahnschrift", "Bahnschrift SemiBold", "Consolas"),
    "gold":       ("#0f0d08", "#1c1910", "#fbf3dc", "#a89a73", "#f5b301", "#1a1405", "#2b261a") + _SEGOE,
    "sakura":     ("#1b1118", "#2a1a25", "#ffeef8", "#b996ab", "#f472b6", "#2a0618", "#3a2433") + _SEGOE,
    "light":      ("#eceaf3", "#ffffff", "#1d1b26", "#6b6880", "#7c3aed", "#ffffff", "#e2def0") + _SEGOE,
}
GOOD, BAD, WARN = "#22c55e", "#ef4444", "#f59e0b"

# Второй цвет градиента и эффект в шапке для каждой темы
THEME_FX = {
    "purple":     ("#ec4899", "stars"),
    "sky":        ("#6366f1", "bubbles"),
    "emerald":    ("#a3e635", "fireflies"),
    "crimson":    ("#fb923c", "embers"),
    "futuristic": ("#ff2bd6", "grid"),
    "gold":       ("#ff7a00", "sparkles"),
    "sakura":     ("#c084fc", "petals"),
    "light":      ("#ec4899", "orbs"),
}
ACCENT2, FX = "#ec4899", "stars"


def _rgb(c):
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def mix(c1, c2, t):
    """Смешивает два цвета: t=0 — c1, t=1 — c2."""
    a, b = _rgb(c1), _rgb(c2)
    t = max(0.0, min(1.0, t))
    return "#%02x%02x%02x" % tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


class CanvasText:
    """Текст на холсте, который можно менять как Label: .configure(text=..., fg=...)."""

    def __init__(self, canvas, item):
        self.canvas, self.item, self.fg = canvas, item, FG

    def configure(self, text=None, fg=None):
        if fg:
            self.fg = fg
        kw = {}
        if text is not None:
            kw["text"] = text[2:] if text.startswith("● ") else text  # точку рисует сама шапка
        if fg:
            kw["fill"] = fg
        self.canvas.itemconfigure(self.item, **kw)


def apply_theme(name):
    """Переключает цвета и шрифты (глобальные переменные, которые читают все виджеты)."""
    global BG, PANEL, FG, MUTED, ACCENT, ACCENT_FG, HOVER, UI_FONT, UI_BOLD, MONO, FONT, ACCENT2, FX, LINE
    (BG, PANEL, FG, MUTED, ACCENT, ACCENT_FG, HOVER,
     UI_FONT, UI_BOLD, MONO) = THEMES.get(name, THEMES["purple"])
    FONT = (UI_FONT, 10)
    ACCENT2, FX = THEME_FX.get(name, THEME_FX["purple"])
    LINE = mix(PANEL, ACCENT, 0.28)


apply_theme("purple")


def flag_png(code, w=30, h=20):
    """Рисует флаг картинкой (Windows не показывает эмодзи флагов). Возвращает PNG в base64."""
    W, H = w * 8, h * 8
    img = np.zeros((H, W, 3), np.uint8)
    if code == "ru":
        img[:H // 3] = (255, 255, 255)
        img[H // 3:2 * H // 3] = (166, 57, 0)
        img[2 * H // 3:] = (30, 43, 213)
    elif code == "es":
        img[:] = (27, 21, 170)
        img[H // 4:3 * H // 4] = (0, 191, 241)
    else:  # Великобритания
        img[:] = (105, 33, 1)
        t = H // 5
        cv2.line(img, (0, 0), (W, H), (255, 255, 255), t)
        cv2.line(img, (0, H), (W, 0), (255, 255, 255), t)
        cv2.line(img, (0, 0), (W, H), (46, 16, 200), t // 3)
        cv2.line(img, (0, H), (W, 0), (46, 16, 200), t // 3)
        cw, rw = H // 3, H // 5
        cv2.rectangle(img, (0, (H - cw) // 2), (W, (H + cw) // 2), (255, 255, 255), -1)
        cv2.rectangle(img, ((W - cw) // 2, 0), ((W + cw) // 2, H), (255, 255, 255), -1)
        cv2.rectangle(img, (0, (H - rw) // 2), (W, (H + rw) // 2), (46, 16, 200), -1)
        cv2.rectangle(img, ((W - rw) // 2, 0), ((W + rw) // 2, H), (46, 16, 200), -1)
    img = cv2.resize(img, (w, h), interpolation=cv2.INTER_AREA)
    cv2.rectangle(img, (0, 0), (w - 1, h - 1), (70, 60, 75), 1)
    return base64.b64encode(cv2.imencode(".png", img)[1].tobytes())


def load_cfg():
    cfg = dict(DEFAULTS)
    try:
        with open(CONFIG, encoding="utf-8") as f:
            cfg.update(json.load(f))
    except Exception:
        pass
    cfg.pop("require_focus", None)      # настройки «только когда активен Roblox» больше нет
    if cfg["buttons"]:
        cfg["buttons"] = [tuple(b) for b in cfg["buttons"]]
    cfg["hotkeys"] = {**DEFAULTS["hotkeys"], **(cfg.get("hotkeys") or {})}
    if cfg.get("lang") not in LANGS:
        cfg["lang"] = "en"
    if cfg.get("theme") not in THEMES:
        cfg["theme"] = "purple"
    known = [i for i, _ in pm.ITEMS]
    order = [i for i in (cfg.get("items_order") or []) if i in known]
    cfg["items_order"] = list(dict.fromkeys(order + known))   # новые товары — в конец списка
    cfg["items_on"] = [i for i in (cfg.get("items_on") or []) if i in known]
    cfg["weather_on"] = [w for w, _ in pm.WEATHERS if w in (cfg.get("weather_on") or [])]
    cfg["weather_link"] = str(cfg.get("weather_link") or "")
    cfg["update_skipped"] = str(cfg.get("update_skipped") or "")
    return cfg


def save_cfg(cfg):
    with open(CONFIG, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=1)


class App:
    def __init__(self, root):
        self.root = root
        self.cfg = load_cfg()
        if self.cfg["webhook_text"] is None:
            self.cfg["webhook_text"] = self.t("hook_default")
        self.running = False
        self.calib = []
        self.q = queue.Queue()
        self.stop_evt = threading.Event()
        self.bought = 0
        self.stock_sig = None      # отпечаток текущего стока
        self.stock_pending = None  # новый отпечаток, ждёт подтверждения следующей проверкой
        self.timer_prev = None     # была ли «5» первой цифрой минут на прошлой проверке
        self.timer_prev_t = 0.0    # когда таймер последний раз удалось прочитать
        self.stock_due = None      # когда кончается текущий «час» стока (None — макро ещё не запускали)
        self.stock_synced = False  # час отсчитан от настоящего обновления стока, а не от запуска макро
        self.stock_refresh_t = 0.0  # когда в последний раз заметили обновление стока или отправили сток
        self.bought_stock = None   # сток (три товара), в котором сделка уже удалась
        self.bought_at = 0.0
        self.bought_logged = False
        self._best_frame = None    # кадр, по которому выбран товар для покупки
        self.weather_active = {}   # погоды, которые сейчас идут: id -> когда иконку видели последний раз
        self.update_info = None    # сведения о вышедшей версии новее этой (pm.check_update)
        self.update_win = None     # открытое окно обновления
        self.update_step = 0       # какое окно открыто: 1 — «вышло обновление», 2 — «точно не хочешь?»
        self.update_busy = False   # обновление скачивается
        self.stock_lock = threading.RLock()
        self.scan_lock = threading.Lock()
        self.flags = {c: tk.PhotoImage(data=flag_png(c)) for c in LANGS}
        self._img = None
        self._raw_preview = None   # последняя картинка в полном размере — масштабируется под окно
        self.log_lines = []        # чтобы лог не пропадал при смене темы
        self.cur_tab = "tab_main"
        apply_theme(self.cfg["theme"])
        root.title("Merchant Macro v" + pm.VERSION)
        root.geometry("500x880" if self.cfg["enhanced"] else "500x840")
        root.minsize(420, 600)
        root.attributes("-topmost", True)
        self.build_ui()
        if self.cfg["enhanced"]:
            self._fade_in(0.0)
        self.root.after(100, self._fx_frame)
        self.reset_key_states()
        self.worker = threading.Thread(target=self.loop, daemon=True)
        self.worker.start()
        threading.Thread(target=self.timer_loop, daemon=True).start()
        threading.Thread(target=self.popup_loop, daemon=True).start()
        threading.Thread(target=self.weather_loop, daemon=True).start()
        threading.Thread(target=self.update_loop, daemon=True).start()
        root.protocol("WM_DELETE_WINDOW", self.quit)
        root.bind("<Escape>", lambda e: self.close_lang_menu())
        self.poll()
        h = self.cfg["hotkeys"]
        self.log(self.t("log_ready", c=h["calib"], s=h["start"], e=h["exit"]))

    def build_ui(self):
        root = self.root
        self.tr_widgets = []       # (виджет, ключ перевода) — обновляются при смене языка
        self._panel_titles = set()
        self.lang_menu = None
        self.fx_panels = []        # панели с анимированной обводкой (улучшенные темы)
        self.log_fx = []           # новые строки лога, которые подсвечиваются и гаснут
        self.tab_ind = None
        self.floor = None
        root.configure(bg=BG)

        enh = self.cfg["enhanced"]
        self.hdr = None
        if not enh:
            # --- обычная шапка: название, статус, язык ---
            top = tk.Frame(root, bg=BG)
            top.pack(fill="x", padx=14, pady=(12, 6))
            left = tk.Frame(top, bg=BG)
            left.pack(side="left", fill="x", expand=True)
            tk.Label(left, text="Merchant Macro", bg=BG, fg=FG, font=(UI_BOLD, 15)).pack(anchor="w")
            self.status = tk.Label(left, text="", bg=BG, fg=MUTED, font=(UI_BOLD, 11))
            self.status.pack(anchor="w", pady=(2, 0))
            self._build_lang_button(top)
            self.lang_box.pack(side="right", anchor="n", pady=(4, 0))
        else:
            self._build_enhanced_header(root)
            # неоновая «подсветка пола» внизу окна
            self.floor = tk.Canvas(root, height=4, bg=BG, highlightthickness=0)
            self.floor.pack(side="bottom", fill="x")

        self._build_body(root)

    def _build_enhanced_header(self, root):
        # --- шапка: градиент, анимация темы, название, статус, язык ---
        self.hdr = tk.Canvas(root, height=88, bg=BG, highlightthickness=0)
        self.hdr.pack(fill="x", pady=(0, 4))
        import tkinter.font as tkfont
        f = tkfont.Font(family=UI_BOLD, size=16)
        self.title_chars, x = [], 16
        for ch in "Merchant Macro":
            self.title_chars.append((ch, x))
            x += f.measure(ch)
        self.title_w = x - 16
        self.status = CanvasText(self.hdr, self.hdr.create_text(34, 57, text="", anchor="w", fill=MUTED,
                                                               font=(UI_BOLD, 10), tags="txt"))
        self._build_lang_button(self.hdr)
        self.hdr_lang = self.hdr.create_window(0, 14, window=self.lang_box, anchor="ne")
        self.fx_parts = []
        self.hdr.bind("<Configure>", lambda e: self._draw_header_bg())

    def _build_body(self, root):
        enh = self.cfg["enhanced"]

        # --- кнопки ---
        btns = tk.Frame(root, bg=BG)
        btns.pack(fill="x", padx=14, pady=6)
        self.start_btn = self._btn(btns, "", self.toggle, ACCENT)
        self.start_btn.pack(side="left", fill="x", expand=True)
        self.check_btn = self._btn(btns, "", self.check_now, PANEL)
        self.check_btn.pack(side="left", fill="x", expand=True, padx=(8, 0))

        # --- вкладки ---
        tabbar = tk.Frame(root, bg=BG)
        tabbar.pack(fill="x", padx=14, pady=(6, 0))
        # две строки: во вторую вкладки переносятся, только когда не помещаются в одну (см. _fit_tabs)
        self.tab_rows = [tk.Frame(tabbar, bg=BG), tk.Frame(tabbar, bg=BG)]
        self.tab_rows[0].pack(fill="x")
        self._tab_first = None
        self.pages, self.tab_btns = {}, {}
        self.tab_bars = {}
        for key in ("tab_main", "tab_items", "tab_weather", "tab_settings", "tab_discord", "tab_credits",
                    "tab_better", "tab_important"):
            cell = tk.Frame(tabbar, bg=BG)
            cell.pack(in_=self.tab_rows[0], side="left")
            b = tk.Button(cell, command=lambda k=key: self.show_tab(k), relief="flat", bd=0,
                          font=(UI_BOLD, 9), padx=7, pady=6, cursor="hand2",
                          activebackground=PANEL, activeforeground=FG)
            b.pack(fill="x")
            bar = tk.Frame(cell, height=2, bg=BG)
            bar.pack(fill="x")
            b.bind("<Enter>", lambda e, k=key: k != self.cur_tab and self.tab_btns[k].configure(fg=FG))
            b.bind("<Leave>", lambda e, k=key: k != self.cur_tab and self.tab_btns[k].configure(fg=MUTED))
            self._tr(b, key)
            self.tab_btns[key] = b
            self.tab_bars[key] = bar
            self.pages[key] = tk.Frame(root, bg=BG)
        self.tabbar = tabbar
        tabbar.bind("<Configure>", lambda e: self._fit_tabs())
        if enh:
            self.tab_ind = tk.Canvas(root, height=4, bg=BG, highlightthickness=0)
            self.tab_ind.pack(fill="x", padx=14)
            self.ind_x, self.ind_w = None, 0.0

        # ===== Главное =====
        main = self.pages["tab_main"]
        cal = self._panel(main, "p_calib")
        self.cal_lbl = tk.Label(cal, bg=PANEL, fg=FG, font=FONT, justify="left", anchor="w", wraplength=400)
        self.cal_lbl.pack(fill="x")
        self._tr(self._btn(cal, "", self.reset_calib, BG), "btn_reset_calib").pack(anchor="w", pady=(6, 0))

        pv = self._panel(main, "p_preview")
        self.preview = tk.Label(pv, bg=PANEL, fg=MUTED, font=FONT)
        self.preview.pack(fill="x")
        self._tr(self.preview, "preview_empty")
        self.pv_width = 400
        pv.bind("<Configure>", self._preview_resized)

        lg = self._panel(main, "p_log", expand=True)
        self.log_box = tk.Text(lg, bg=BG, fg=FG, font=(MONO, 9), height=8, relief="flat",
                               state="disabled", wrap="word", padx=6, pady=4, highlightthickness=1,
                               highlightbackground=LINE, highlightcolor=LINE, selectbackground=ACCENT)
        self.log_box.pack(fill="both", expand=True)

        # ===== Предметы =====
        self._build_items(self.pages["tab_items"])

        # ===== Погода =====
        wpage = self.pages["tab_weather"]
        wp = self._panel(wpage, "p_weather")
        wh = tk.Label(wp, bg=PANEL, fg=MUTED, font=(UI_FONT, 9), justify="left", anchor="w", wraplength=400)
        self._tr(wh, "weather_help").grid(row=0, column=0, sticky="we", pady=(0, 6))
        wh.bind("<Configure>", lambda e: e.widget.configure(wraplength=max(e.width - 6, 100)))
        self.weather_vars = {}
        for row, (wid, name) in enumerate(pm.WEATHERS, start=1):     # названия погод — как в игре, без перевода
            v = tk.BooleanVar(value=wid in self.cfg["weather_on"])
            self.weather_vars[wid] = v
            tk.Checkbutton(wp, text=name, variable=v, command=self.save_weather, bg=PANEL, fg=FG, selectcolor=BG,
                           activebackground=PANEL, activeforeground=FG, font=FONT, anchor="w").grid(
                row=row, column=0, sticky="w")
        wp.grid_columnconfigure(0, weight=1)
        wm = self._panel(wpage, "p_weather_msg")
        self.v_wping = tk.BooleanVar(value=self.cfg["weather_ping"])
        self.v_wlink = tk.StringVar(value=self.cfg["weather_link"])
        self._check(wm, "c_ping", self.v_wping, 0)
        self._tr(tk.Label(wm, bg=PANEL, fg=FG, font=FONT, justify="left", anchor="w", wraplength=400),
                 "l_weather_link").grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))
        tk.Entry(wm, textvariable=self.v_wlink, bg=BG, fg=FG, insertbackground=FG, relief="flat",
                 font=FONT).grid(row=2, column=0, columnspan=2, sticky="we", pady=(2, 6))
        self._tr(self._btn(wm, "", self.check_weather_now, BG), "btn_weather_check").grid(
            row=3, column=0, columnspan=2, sticky="w", pady=(4, 0))
        wm.grid_columnconfigure(0, weight=1)
        for v in (self.v_wping, self.v_wlink):
            v.trace_add("write", lambda *_: self.apply_settings())

        # ===== Настройки =====
        sets = self.pages["tab_settings"]
        st = self._panel(sets, "p_macro")
        self.v_interval = tk.StringVar(value=str(self.cfg["scan_interval"]))
        self.v_clicks = tk.StringVar(value=str(self.cfg["clicks"]))
        self.v_key = tk.StringVar(value=self.cfg["open_key"])
        self.v_jump = tk.StringVar(value=str(self.cfg["jump_interval"]))
        self.v_top = tk.BooleanVar(value=True)
        self._field(st, "f_interval", self.v_interval, 0)
        self._field(st, "f_clicks", self.v_clicks, 1)
        self._field(st, "f_openkey", self.v_key, 2)
        self._field(st, "f_jump", self.v_jump, 3)
        self._check(st, "c_top", self.v_top, 4, lambda: root.attributes("-topmost", self.v_top.get()))
        self._tr(self._btn(st, "", self.test_jump, BG), "btn_testjump").grid(
            row=5, column=0, columnspan=2, sticky="w", pady=(6, 0))
        for v in (self.v_interval, self.v_clicks, self.v_key, self.v_jump):
            v.trace_add("write", lambda *_: self.apply_settings())

        hk = self._panel(sets, "p_hotkeys")
        self.hot_entries = {}
        for col, key in enumerate(HOTKEYS):
            self._tr(tk.Label(hk, bg=PANEL, fg=MUTED, font=(UI_FONT, 9)), "hk_" + key).grid(
                row=0, column=col, sticky="w")
            e = tk.Entry(hk, width=9, bg=BG, fg=FG, insertbackground=BG, relief="flat",
                         font=(UI_BOLD, 10), justify="center", cursor="hand2")
            e.insert(0, self.cfg["hotkeys"][key])
            e.grid(row=1, column=col, sticky="we", padx=(0, 6), pady=(2, 0))
            e.bind("<KeyPress>", lambda ev, k=key: self.capture_hotkey(k, ev))
            e.bind("<FocusIn>", lambda ev: ev.widget.configure(bg=ACCENT, fg=ACCENT_FG))
            e.bind("<FocusOut>", lambda ev: ev.widget.configure(bg=BG, fg=FG))
            hk.grid_columnconfigure(col, weight=1)
            self.hot_entries[key] = e
        self._tr(tk.Label(hk, bg=PANEL, fg=MUTED, font=(UI_FONT, 8), justify="left", wraplength=400),
                 "hk_allowed").grid(
            row=2, column=0, columnspan=4, sticky="w", pady=(4, 0))

        th = self._panel(sets, "p_theme")
        self.theme_cards = {}
        for i, name in enumerate(THEMES if not enh else ()):
            tb, tp, tf, tm, ta, taf = THEMES[name][:6]
            on = name == self.cfg["theme"]
            b = tk.Button(th, command=lambda n=name: self.set_theme(n), relief="flat", bd=0, cursor="hand2",
                          bg=ta if on else tp, fg=taf if on else ta, activebackground=ta, activeforeground=taf,
                          font=(THEMES[name][8], 9), pady=5, highlightthickness=2,
                          highlightbackground=ta if on else tb)
            b.grid(row=i // 4, column=i % 4, sticky="we", padx=2, pady=2)
            self._tr(b, "theme_" + name)
        for i, name in enumerate(THEMES if enh else ()):
            c = tk.Canvas(th, height=46, width=90, bg=PANEL, highlightthickness=0, cursor="hand2")
            c.grid(row=i // 4, column=i % 4, sticky="we", padx=3, pady=3)
            c.bind("<Button-1>", lambda e, n=name: self.set_theme(n))
            c.bind("<Configure>", lambda e, n=name: self._draw_theme_card(n))
            c.bind("<Enter>", lambda e, n=name: self._draw_theme_card(n, hover=True))
            c.bind("<Leave>", lambda e, n=name: self._draw_theme_card(n))
            self.theme_cards[name] = c
        for col in range(4):
            th.grid_columnconfigure(col, weight=1, uniform="theme")

        # ===== Лучшие темы =====
        bt = self._panel(self.pages["tab_better"], "p_better")
        self.v_enh = tk.BooleanVar(value=enh)
        self._check(bt, "c_enhance", self.v_enh, 0, cmd=lambda: self.set_enhanced(self.v_enh.get()), wrap=340)

        # ===== ВАЖНО =====
        imp = self._panel(self.pages["tab_important"], "p_important")
        imp_lbl = tk.Label(imp, bg=PANEL, fg=FG, font=(UI_BOLD, 11), justify="left", anchor="w", wraplength=400)
        self._tr(imp_lbl, "important_text").pack(fill="x")
        imp_lbl.bind("<Configure>", lambda e: e.widget.configure(wraplength=max(e.width - 6, 100)))

        # ===== Благодарности =====
        cr = self._panel(self.pages["tab_credits"], "p_credits")
        txt = tk.Text(cr, bg=PANEL, fg=FG, font=(UI_BOLD, 12), relief="flat", bd=0, highlightthickness=0,
                      wrap="word", height=3, width=1, cursor="arrow")
        txt.pack(fill="x")
        self._emoji = tk.PhotoImage(data=_scaled_png(EMOJI_B64, height=34))
        txt.insert("end", self.t("credits_text") + " ")
        txt.image_create("end", image=self._emoji, align="center")
        txt.configure(state="disabled")
        self.credits_txt = txt
        self._credits_img = tk.PhotoImage(data=_scaled_png(CREDITS_B64, width=400))
        tk.Label(cr, image=self._credits_img, bg=PANEL).pack(anchor="w", pady=(10, 0))

        # ===== Discord =====
        dpage = self.pages["tab_discord"]
        dc = self._panel(dpage, "p_discord")
        self.v_hook = tk.StringVar(value=self.cfg["webhook"])
        self.v_hook_text = tk.StringVar(value=self.cfg["webhook_text"])
        self.v_id = tk.StringVar(value=self.cfg["discord_id"])
        self._tr(tk.Label(dc, bg=PANEL, fg=FG, font=FONT), "l_hook").grid(row=0, column=0, sticky="w")
        tk.Entry(dc, textvariable=self.v_hook, bg=BG, fg=FG, insertbackground=FG, relief="flat", font=FONT,
                 show="•").grid(row=1, column=0, columnspan=2, sticky="we", pady=(2, 6))
        self._tr(tk.Label(dc, bg=PANEL, fg=FG, font=FONT), "l_hooktext").grid(row=2, column=0, sticky="w")
        tk.Entry(dc, textvariable=self.v_hook_text, bg=BG, fg=FG, insertbackground=FG, relief="flat",
                 font=FONT).grid(row=3, column=0, columnspan=2, sticky="we", pady=(2, 6))
        self._tr(tk.Label(dc, bg=PANEL, fg=FG, font=FONT), "l_userid").grid(row=4, column=0, sticky="w")
        tk.Entry(dc, textvariable=self.v_id, bg=BG, fg=FG, insertbackground=FG, relief="flat",
                 font=FONT).grid(row=5, column=0, columnspan=2, sticky="we", pady=(2, 2))
        self._tr(tk.Label(dc, bg=PANEL, fg=MUTED, font=(UI_FONT, 8), justify="left", wraplength=400),
                 "id_help").grid(row=6, column=0, columnspan=2, sticky="w")
        self._tr(self._btn(dc, "", self.test_webhook, BG), "btn_testhook").grid(
            row=7, column=0, columnspan=2, sticky="w", pady=(8, 0))
        self._tr(tk.Label(dc, bg=PANEL, fg=MUTED, font=(UI_FONT, 8), justify="left", wraplength=400),
                 "hook_help").grid(row=8, column=0, columnspan=2, sticky="w", pady=(8, 0))
        dc.grid_columnconfigure(0, weight=1)

        ev = self._panel(dpage, "p_events")
        self.ev_vars = {}
        for row, (send_key, ping_key, label) in enumerate((("webhook_on", "ping_stock", "c_hookon"),
                                                           ("hook_success", "ping_success", "c_hooksuccess"),
                                                           ("hook_fail", "ping_fail", "c_hookfail"))):
            vs = tk.BooleanVar(value=self.cfg[send_key])
            vp = tk.BooleanVar(value=self.cfg[ping_key])
            self.ev_vars[send_key], self.ev_vars[ping_key] = vs, vp
            self._check(ev, label, vs, row, wrap=250)
            self._tr(tk.Checkbutton(ev, variable=vp, bg=PANEL, fg=FG, selectcolor=BG, activebackground=PANEL,
                                    activeforeground=FG, font=FONT, anchor="e"), "c_ping").grid(
                row=row, column=2, sticky="e", padx=(10, 0))
        ev.grid_columnconfigure(0, weight=1)
        for v in (self.v_hook, self.v_hook_text, self.v_id, *self.ev_vars.values()):
            v.trace_add("write", lambda *_: self.apply_settings())

        self.show_tab(self.cur_tab)
        self.refresh_texts()
        # вернуть лог и превью после пересборки окна
        self.log_box.configure(state="normal")
        for line in self.log_lines:
            self.log_box.insert("end", line + "\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")
        if self._raw_preview is not None:
            self.root.after_idle(self._render_preview)

    def rebuild_ui(self):
        self._fit_key = None
        self.close_lang_menu()
        for w in self.root.winfo_children():
            w.destroy()
        self.build_ui()

    def _fit_tabs(self):
        """Ужимает вкладки (отступы, потом шрифт), если они не влезают в ширину окна; если не влезают и так —
        переносит последние на вторую строку обычным шрифтом."""
        if getattr(self, "_fitting", False):
            return
        try:
            avail = self.tabbar.winfo_width()
        except tk.TclError:
            return
        if avail < 50:
            return
        key = (avail, self.cfg["lang"])
        if key == getattr(self, "_fit_key", None):
            return  # ширина и язык те же — уже подогнано, ничего не трогаем (иначе вкладки дёргаются)
        self._fit_key = key
        self._fitting = True
        try:
            btns = list(self.tab_btns.values())
            for padx, size in ((7, 9), (5, 9), (3, 9), (3, 8), (7, 9)):   # последний шаг — в две строки
                for b in btns:
                    b.configure(padx=padx, font=(UI_BOLD, size))
                if sum(b.winfo_reqwidth() for b in btns) <= avail:
                    break
            first, used = 0, 0                 # сколько вкладок помещается в первую строку
            for b in btns:
                if first and used + b.winfo_reqwidth() > avail:
                    break
                used += b.winfo_reqwidth()
                first += 1
            if first != self._tab_first:
                self._tab_first = first
                for b in btns:
                    b.master.pack_forget()
                for i, b in enumerate(btns):
                    b.master.pack(in_=self.tab_rows[0 if i < first else 1], side="left")
                if first < len(btns):
                    self.tab_rows[1].pack(fill="x")
                else:
                    self.tab_rows[1].pack_forget()
        finally:
            self._fitting = False

    def set_theme(self, name):
        if name == self.cfg["theme"]:
            return
        self.cfg["theme"] = name
        save_cfg(self.cfg)
        apply_theme(name)
        self.rebuild_ui()
        self.log(self.t("log_theme", t=self.t("theme_" + name)))

    def set_enhanced(self, on):
        if bool(on) == bool(self.cfg["enhanced"]):
            return
        self.cfg["enhanced"] = bool(on)
        save_cfg(self.cfg)
        if on and self.root.winfo_height() < 880:  # улучшенной шапке и карточкам нужно чуть больше места
            self.root.geometry("%dx880" % self.root.winfo_width())
        self.rebuild_ui()
        if on:
            self._fade_in(0.35)
        self.log(self.t("log_enh_on" if on else "log_enh_off"))

    # ---------- оформление ----------
    def _fade_in(self, a):
        """Окно плавно проявляется (улучшенные темы)."""
        try:
            self.root.attributes("-alpha", min(a, 1.0))
        except tk.TclError:
            return
        if a < 1.0:
            self.root.after(16, lambda: self._fade_in(a + 0.07))

    def _fx_body(self, t):
        """Анимации ниже шапки (улучшенные темы): неоновые панели, индикатор вкладок, пол, кнопка, лог."""
        # панели: обводка «дышит», по линии заголовка бежит комета
        for p in self.fx_panels:
            o = p["outer"]
            if not o.winfo_ismapped():
                continue
            k = p["k"]
            wave = (math.sin(t * 0.07 + k * 1.1) + 1) / 2
            o.configure(highlightbackground=mix(LINE, mix(ACCENT, ACCENT2, wave), 0.2 + 0.45 * wave))
            c = p["rule"]
            w = c.winfo_width()
            c.delete("all")
            c.create_line(0, 2, w, 2, fill=LINE)
            x = (t * 4 + k * 97) % (w + 140) - 70
            for j in range(10):
                q = j / 9
                c.create_line(x - 60 + j * 6, 2, x - 54 + j * 6, 2, width=1 + (j > 6),
                              fill=mix(LINE, mix(ACCENT, ACCENT2, q), q))
            c.create_oval(x - 2, 0, x + 3, 5, fill="#ffffff", outline="")
        # вкладки: индикатор плавно доезжает до выбранной
        ti = self.tab_ind
        if ti is not None and ti.winfo_exists():
            b = self.tab_btns.get(self.cur_tab)
            cell = b.master
            tx, tw = cell.winfo_x(), cell.winfo_width()
            if self.ind_x is None:
                self.ind_x, self.ind_w = float(tx), float(tw)
            self.ind_x += (tx - self.ind_x) * 0.25
            self.ind_w += (tw - self.ind_w) * 0.25
            W = ti.winfo_width()
            ti.delete("all")
            ti.create_line(0, 3, W, 3, fill=LINE)
            x0, x1 = self.ind_x, self.ind_x + self.ind_w
            ti.create_line(x0 - 6, 2, x1 + 6, 2, width=4, fill=mix(BG, ACCENT, 0.35))   # мягкое свечение
            n = 12
            for j in range(n):
                q = j / (n - 1)
                shine = max(0.0, 1 - abs(q - ((t * 0.03) % 1.6 - 0.3)) * 5)          # блик едет по полоске
                ti.create_line(x0 + (x1 - x0) * j / n, 2, x0 + (x1 - x0) * (j + 1) / n, 2, width=3,
                               fill=mix(mix(ACCENT, ACCENT2, q), "#ffffff", shine * 0.7))
        # «пол» внизу окна: переливающийся градиент
        fl = self.floor
        if fl is not None and fl.winfo_exists():
            W = fl.winfo_width()
            fl.delete("all")
            for x in range(0, W, 6):
                q = (math.sin(x / 70 - t * 0.09) + 1) / 2
                fl.create_line(x, 2, x + 6, 2, width=4, fill=mix(BG, mix(ACCENT, ACCENT2, x / max(W, 1)),
                                                                 0.35 + 0.6 * q))
        # кнопка «Старт/Пауза» дышит, пока макро работает
        sb = self.start_btn
        if self.running and not getattr(sb, "hov", False):
            sb.configure(bg=mix(ACCENT, ACCENT2, 0.55 * (math.sin(t * 0.15) + 1) / 2))
            self._sb_pulsing = True
        elif getattr(self, "_sb_pulsing", False) and not getattr(sb, "hov", False):
            sb.configure(bg=ACCENT)
            self._sb_pulsing = False
        # лог: свежие строки гаснут из цвета темы в обычный
        keep = []
        for tag, t0 in self.log_fx:
            age = (t - t0) / 30
            if age >= 1:
                self.log_box.tag_configure(tag, foreground=FG)
            else:
                self.log_box.tag_configure(tag, foreground=mix(ACCENT2, FG, age))
                keep.append((tag, t0))
        self.log_fx = keep

    def _draw_theme_card(self, name, hover=False):
        """Мини-превью темы: градиент её цветов, название её шрифтом, галочка у выбранной."""
        c = self.theme_cards.get(name)
        if c is None:
            return
        tb, tp, tf, tm, ta, taf = THEMES[name][:6]
        a2 = THEME_FX[name][0]
        c.delete("all")
        w, h = max(c.winfo_width(), 40), max(c.winfo_height(), 30)
        on = name == self.cfg["theme"]
        for x in range(0, w, 2):
            t = x / w
            c.create_line(x, 0, x, h, width=2, fill=mix(mix(ta, a2, t), tb, 0.15 if (on or hover) else 0.55))
        c.create_rectangle(0, h - 15, w, h, fill=tb, outline="")
        c.create_line(0, h - 15, w, h - 15, fill=mix(ta, a2, 0.5))
        c.create_text(w // 2 + 1, 16, text=self.t("theme_" + name), font=(THEMES[name][8], 9),
                      fill="#000000")
        c.create_text(w // 2, 15, text=self.t("theme_" + name), font=(THEMES[name][8], 9), fill="#ffffff")
        for k, col in enumerate((ta, a2, tf)):  # маленькие «капли» палитры
            c.create_oval(6 + k * 10, h - 11, 13 + k * 10, h - 4, fill=col, outline="")
        if on:
            c.create_rectangle(1, 1, w - 2, h - 2, outline="#ffffff", width=2)
            c.create_text(w - 8, h - 8, text="✓", fill=ta, font=(UI_BOLD, 9, "bold"))
        elif hover:
            c.create_rectangle(1, 1, w - 2, h - 2, outline=mix(ta, "#ffffff", 0.4), width=1)

    def _draw_header_bg(self):
        """Неподвижная часть шапки: градиент, линия снизу, сетка (футуризм)."""
        c = self.hdr
        c.delete("bg")
        w, h = max(c.winfo_width(), 100), int(c.cget("height"))
        for x in range(0, w, 3):  # горизонтальный градиент: фон → цвет темы
            t = x / w
            c.create_line(x, 0, x, h, width=3, fill=mix(BG, mix(ACCENT, ACCENT2, t), 0.10 + 0.22 * t ** 1.5),
                          tags="bg")
        if FX == "grid":
            for x in range(0, w, 18):
                c.create_line(x, 0, x, h, fill=mix(BG, ACCENT, 0.13), tags="bg")
            for y in range(0, h, 18):
                c.create_line(0, y, w, y, fill=mix(BG, ACCENT, 0.13), tags="bg")
            for (x, y, dx, dy) in ((4, 4, 1, 1), (w - 5, h - 6, -1, -1)):
                c.create_line(x, y, x + 14 * dx, y, fill=ACCENT, width=2, tags="bg")
                c.create_line(x, y, x, y + 14 * dy, fill=ACCENT, width=2, tags="bg")
        for x in range(0, w, 3):  # светящаяся линия снизу
            c.create_line(x, h - 3, x + 3, h - 3, width=3, fill=mix(ACCENT, ACCENT2, x / w), tags="bg")
        c.tag_lower("bg")
        c.coords(self.hdr_lang, w - 14, 16)
        self._init_particles(w, h)

    def _init_particles(self, w, h):
        rnd = random.Random(7)
        n = {"stars": 28, "bubbles": 14, "fireflies": 12, "embers": 22, "grid": 1, "sparkles": 12,
             "petals": 14, "orbs": 5}[FX]
        self.fx_parts = [{"x": rnd.uniform(0, w), "y": rnd.uniform(0, h - 6), "s": rnd.uniform(0.4, 1.0),
                          "p": rnd.uniform(0, 6.28), "v": rnd.uniform(0.3, 1.0)} for _ in range(n)]
        self.fx_size = (w, h)

    def _fx_frame(self):
        """Кадр анимации шапки (раз в 50 мс)."""
        try:
            c = self.hdr
            if not c.winfo_exists():
                raise tk.TclError
        except (tk.TclError, AttributeError):
            self.root.after(200, self._fx_frame)
            return
        self.fx_t = getattr(self, "fx_t", 0) + 1
        t = self.fx_t
        w, h = getattr(self, "fx_size", (460, 88))
        c.delete("fx")
        hb = h - 6
        # северное сияние: две мягкие волны позади всего
        for k, (amp, spd, col, wid) in enumerate(((9, 0.035, mix(BG, ACCENT, 0.22), 10),
                                                  (6, -0.05, mix(BG, ACCENT2, 0.30), 4))):
            pts = []
            for x in range(-10, w + 20, 16):
                pts += [x, h * 0.62 + math.sin(x / 55 + t * spd + k * 2) * amp + math.sin(x / 23 - t * spd * 1.7) * 3]
            c.create_line(*pts, smooth=True, width=wid, fill=col, capstyle="round", tags="fx")
        c.tag_lower("fx")
        c.tag_lower("bg")
        for q in self.fx_parts:
            ph = q["p"] + t * 0.08 * q["v"]
            if FX == "stars":
                b = (math.sin(ph) + 1) / 2
                r = 0.8 + 1.6 * q["s"] * b
                col = mix(BG, mix("#ffffff", ACCENT2, q["s"] * 0.6), 0.25 + 0.75 * b)
                c.create_oval(q["x"] - r, q["y"] - r, q["x"] + r, q["y"] + r, fill=col, outline="", tags="fx")
                if b > 0.85 and q["s"] > 0.75:
                    c.create_line(q["x"] - 5, q["y"], q["x"] + 5, q["y"], fill=col, tags="fx")
                    c.create_line(q["x"], q["y"] - 5, q["x"], q["y"] + 5, fill=col, tags="fx")
            elif FX == "bubbles":
                q["y"] -= 0.35 * q["v"]
                if q["y"] < -8:
                    q["y"], q["x"] = hb + 8, random.uniform(0, w)
                x = q["x"] + math.sin(ph) * 4
                r = 2 + 5 * q["s"]
                c.create_oval(x - r, q["y"] - r, x + r, q["y"] + r, outline=mix(BG, ACCENT, 0.7), tags="fx")
                c.create_oval(x - r * 0.45, q["y"] - r * 0.6, x - r * 0.05, q["y"] - r * 0.2,
                              fill=mix(BG, "#ffffff", 0.6), outline="", tags="fx")
            elif FX == "fireflies":
                q["x"] = (q["x"] + math.cos(ph * 0.7) * 0.6) % w
                q["y"] = min(hb - 4, max(4, q["y"] + math.sin(ph) * 0.4))
                b = (math.sin(ph * 1.7) + 1) / 2
                for r, k in ((6, 0.18), (3.5, 0.4), (1.6, 1.0)):
                    c.create_oval(q["x"] - r, q["y"] - r, q["x"] + r, q["y"] + r,
                                  fill=mix(BG, ACCENT2, k * (0.3 + 0.7 * b)), outline="", tags="fx")
            elif FX == "embers":
                q["y"] -= 0.6 * q["v"]
                q["x"] += math.sin(ph) * 0.5
                if q["y"] < -4:
                    q["y"], q["x"] = hb, random.uniform(0, w)
                life = q["y"] / hb
                r = 1 + 1.8 * q["s"] * life
                c.create_oval(q["x"] - r, q["y"] - r, q["x"] + r, q["y"] + r,
                              fill=mix(BG, mix("#ffe08a", ACCENT2 if life > 0.5 else ACCENT, 1 - life), 0.25 + 0.75 * life),
                              outline="", tags="fx")
            elif FX == "grid":
                y = (t * 2) % (hb + 30) - 15  # сканер сверху вниз
                for k, col in enumerate((mix(BG, ACCENT, 0.15), mix(BG, ACCENT, 0.35), ACCENT)):
                    c.create_line(0, y + (2 - k) * 3, w, y + (2 - k) * 3, fill=col, width=1 + (k == 2), tags="fx")
                bx = (t * 6) % (w + 120) - 60  # бегущая полоса по нижней линии
                c.create_line(bx - 40, h - 3, bx + 40, h - 3, fill="#ffffff", width=3, tags="fx")
                c.create_text(w - 16, h - 14, text="SYS.ONLINE %04X" % (t * 37 % 65536), anchor="e",
                              fill=mix(BG, ACCENT, 0.55), font=(MONO, 7), tags="fx")
            elif FX == "sparkles":
                b = max(0.0, math.sin(ph))
                L = 2 + 6 * q["s"] * b
                col = mix(BG, mix("#fff3b0", ACCENT, 0.4), b)
                if b > 0.05:
                    c.create_polygon(q["x"], q["y"] - L, q["x"] + L * 0.25, q["y"] - L * 0.25, q["x"] + L, q["y"],
                                     q["x"] + L * 0.25, q["y"] + L * 0.25, q["x"], q["y"] + L,
                                     q["x"] - L * 0.25, q["y"] + L * 0.25, q["x"] - L, q["y"],
                                     q["x"] - L * 0.25, q["y"] - L * 0.25, fill=col, outline="", tags="fx")
                if b < 0.02:
                    q["x"], q["y"] = random.uniform(0, w), random.uniform(4, hb - 4)
            elif FX == "petals":
                q["y"] += 0.45 * q["v"]
                q["x"] += 0.35 + math.sin(ph) * 0.5
                if q["y"] > hb + 6 or q["x"] > w + 6:
                    q["y"], q["x"] = -6, random.uniform(-40, w)
                a = ph * 1.5
                r1, r2 = 4 + 2 * q["s"], 2 + q["s"]
                pts = []
                for k in range(8):
                    ang = k * math.pi / 4
                    px, py = math.cos(ang) * r1, math.sin(ang) * r2
                    pts += [q["x"] + px * math.cos(a) - py * math.sin(a), q["y"] + px * math.sin(a) + py * math.cos(a)]
                c.create_polygon(*pts, smooth=True, fill=mix(BG, mix("#ffd1e8", ACCENT, q["s"]), 0.85),
                                 outline="", tags="fx")
            elif FX == "orbs":
                x = q["x"] + math.sin(ph * 0.5) * 30
                y = q["y"] + math.cos(ph * 0.4) * 10
                base = mix(ACCENT, ACCENT2, q["s"])
                for k in range(6, 0, -1):
                    r = 6 + k * 5 * q["s"]
                    c.create_oval(x - r, y - r, x + r, y + r, fill=mix(BG, base, 0.05 + 0.05 * (6 - k)),
                                  outline="", tags="fx")
        # заголовок: каждая буква своим цветом градиента + бегущий белый блик
        glint = (t * 6) % (self.title_w + 260) - 130
        c.create_text(17, 28, text="Merchant Macro", anchor="w", font=(UI_BOLD, 16), fill=mix(BG, ACCENT, 0.7),
                      tags="fx")  # тень-свечение под буквами
        for ch, x in self.title_chars:
            q = (x - 16) / max(self.title_w, 1)
            base = mix(FG, mix(ACCENT, ACCENT2, q), 0.35 + 0.25 * math.sin(t * 0.06 + q * 4))
            g = max(0.0, 1 - abs(x - 16 - glint) / 26)
            c.create_text(x, 27, text=ch, anchor="w", font=(UI_BOLD, 16), fill=mix(base, "#ffffff", g),
                          tags="fx")
        # пульсирующая точка статуса
        col = getattr(self.status, "fg", MUTED)
        if self.running:  # круги-радар
            for k in range(2):
                r = (t * 0.7 + k * 14) % 28
                c.create_oval(20 - r, 57 - r, 20 + r, 57 + r, outline=mix(col, BG, r / 28), tags="fx")
        pulse = (math.sin(t * 0.18) + 1) / 2 if self.running else 0.3
        for r, k in ((9, 0.12 * pulse), (6, 0.3 * pulse), (3.5, 1.0)):
            c.create_oval(20 - r, 57 - r, 20 + r, 57 + r, fill=mix(mix(BG, ACCENT, 0.2), col, k + (0 if r > 4 else 0)),
                          outline="", tags="fx")
        c.tag_raise("txt")
        c.tag_raise(self.hdr_lang)
        try:
            self._fx_body(t)
        except tk.TclError:
            pass
        self.root.after(50, self._fx_frame)

    # ---------- перевод ----------
    def t(self, key, **kw):
        s = TEXT[key][LANG_INDEX[self.cfg["lang"]]]
        return s.format(**kw) if kw else s

    def _tr(self, widget, key):
        self.tr_widgets.append((widget, key))
        widget.configure(text=self.t(key))
        return widget

    def kind_name(self, kind):
        return pm.ITEM_NAMES.get(kind) or self.t("kind_unknown")

    # ---------- вкладка «Предметы»: что покупать и в каком порядке ----------
    def _build_items(self, page):
        it = self._panel(page, "p_items")
        self._tr(tk.Label(it, bg=PANEL, fg=MUTED, font=(UI_FONT, 9), justify="left", anchor="w", wraplength=400),
                 "items_help").pack(fill="x", pady=(0, 6))
        order = self.cfg["items_order"]
        self.items_box = tk.Frame(it, bg=PANEL, height=ITEM_ROW_H * len(order))
        self.items_box.pack(fill="x")
        self.item_icons = {k: tk.PhotoImage(data=v) for k, v in ITEM_ICONS.items()}
        self.item_rows, self.item_vars = {}, {}
        self._items_anim_on = False
        for idx, item in enumerate(order):
            v = tk.BooleanVar(value=item in self.cfg["items_on"])
            self.item_vars[item] = v
            row = tk.Frame(self.items_box, bg=PANEL)
            cb = tk.Checkbutton(row, variable=v, command=self.save_items, bg=PANEL, fg=FG, selectcolor=BG,
                                activebackground=PANEL, bd=0, highlightthickness=0, cursor="hand2")
            cb.pack(side="left")
            ic = tk.Label(row, image=self.item_icons[item], bg=PANEL, width=26, height=26)
            ic.pack(side="left", padx=(0, 6))
            for sym, d in (("▼", 1), ("▲", -1)):
                tk.Button(row, text=sym, command=lambda i=item, d=d: self.move_item(i, d), relief="flat", bd=0,
                          bg=BG, fg=MUTED, activebackground=ACCENT, activeforeground=ACCENT_FG,
                          font=(UI_BOLD, 8), width=2, cursor="hand2").pack(side="right", padx=(3, 0))
            name = tk.Label(row, bg=PANEL, fg=FG, font=FONT, anchor="w", cursor="hand2", text=pm.ITEM_NAMES[item])
            name.pack(side="left", fill="x", expand=True)
            name.bind("<Button-1>", lambda e, var=v: (var.set(not var.get()), self.save_items()))
            r = {"row": row, "ws": (row, cb, ic, name), "y": float(idx * ITEM_ROW_H), "flash": 0.0, "hov": False}
            for w in r["ws"]:
                w.bind("<Enter>", lambda e, i=item: self._item_hover(i), add="+")
                w.bind("<Leave>", lambda e, i=item: self.root.after(1, lambda: self._item_hover(i)), add="+")
            row.place(x=0, y=int(r["y"]), relwidth=1, height=ITEM_ROW_H - 2)
            self.item_rows[item] = r

    def _paint_item(self, r):
        bg = HOVER if r["hov"] else PANEL
        if r["flash"] > 0.01:
            bg = mix(bg, ACCENT, 0.45 * r["flash"])
        for w in r["ws"]:
            w.configure(bg=bg)
        r["ws"][1].configure(activebackground=bg)

    def _item_hover(self, item):
        r = self.item_rows.get(item)
        if not r:
            return
        try:
            w = self.root.winfo_containing(*self.root.winfo_pointerxy())
        except (tk.TclError, KeyError):
            w = None
        hov = w is not None and str(w).startswith(str(r["row"]))
        if hov != r["hov"]:
            r["hov"] = hov
            self._paint_item(r)

    def move_item(self, item, d):
        order = self.cfg["items_order"]
        i = order.index(item)
        j = i + d
        if 0 <= j < len(order):
            order[i], order[j] = order[j], order[i]
            save_cfg(self.cfg)
            self.item_rows[item]["flash"] = 1.0       # подсвечиваем строку, которую двигаем
            self.item_rows[item]["row"].lift()         # и она едет поверх соседней
            if not self._items_anim_on:
                self._items_anim_on = True
                self._items_anim()

    def _items_anim(self):
        """Кадр анимации списка: строки плавно едут на свои места, подсветка гаснет."""
        busy = False
        try:
            for idx, item in enumerate(self.cfg["items_order"]):
                r = self.item_rows[item]
                target = idx * ITEM_ROW_H
                if abs(target - r["y"]) > 0.5:
                    r["y"] += (target - r["y"]) * 0.28
                    busy = True
                else:
                    r["y"] = float(target)
                r["row"].place_configure(y=int(round(r["y"])))
                if r["flash"] > 0.01:
                    r["flash"] *= 0.9
                    busy = True
                    self._paint_item(r)
                elif r["flash"]:
                    r["flash"] = 0.0
                    self._paint_item(r)
        except (tk.TclError, KeyError):
            busy = False
        if busy:
            self.root.after(16, self._items_anim)
        else:
            self._items_anim_on = False

    def save_items(self):
        self.cfg["items_on"] = [i for i in self.cfg["items_order"] if self.item_vars[i].get()]
        save_cfg(self.cfg)

    def refresh_texts(self):
        for w, key in self.tr_widgets:
            if w is self.preview and self._img is not None:
                continue
            w.configure(text=self.t(key).upper() if w in self._panel_titles else self.t(key))
        self.lang_name.configure(text=LANGS[self.cfg["lang"]])
        self.credits_txt.configure(state="normal")
        self.credits_txt.delete("1.0", "end")
        self.credits_txt.insert("end", self.t("credits_text") + " ")
        self.credits_txt.image_create("end", image=self._emoji, align="center")
        self.credits_txt.configure(state="disabled")
        self.lang_flag.configure(image=self.flags[self.cfg["lang"]])
        for n in self.theme_cards:
            self._draw_theme_card(n)
        if getattr(self, "tabbar", None) is not None:
            self.root.after_idle(self._fit_tabs)
        self.update_status()
        self.update_calib_label()

    def set_lang(self, code):
        self.close_lang_menu()
        if code == self.cfg["lang"]:
            return
        old_default = self.t("hook_default")
        self.cfg["lang"] = code
        if self.v_hook_text.get() == old_default:  # стандартный текст — переводим тоже
            self.v_hook_text.set(self.t("hook_default"))
        save_cfg(self.cfg)
        self.refresh_texts()
        self.log(self.t("log_lang"))

    # ---------- выбор языка ----------
    def _build_lang_button(self, parent):
        box = tk.Frame(parent, bg=PANEL, cursor="hand2", highlightthickness=1, highlightbackground=LINE)
        self.lang_flag = tk.Label(box, bg=PANEL, image=self.flags[self.cfg["lang"]])
        self.lang_flag.pack(side="left", padx=(10, 6), pady=7)
        self.lang_name = tk.Label(box, bg=PANEL, fg=FG, font=(UI_BOLD, 10))
        self.lang_name.pack(side="left")
        self.chev = tk.Canvas(box, width=22, height=22, bg=PANEL, highlightthickness=0)
        self.chev.pack(side="left", padx=(4, 8))
        self.chev_angle = 0.0
        self._draw_chevron()
        for w in (box, self.lang_flag, self.lang_name, self.chev):
            w.bind("<Button-1>", lambda e: self.toggle_lang_menu())
            w.bind("<Enter>", lambda e: self._lang_hover(True))
            w.bind("<Leave>", lambda e: self._lang_hover(False))
        self.lang_box = box
        self.lang_menu = None

    def _lang_hover(self, on):
        c = HOVER if on else PANEL
        for w in (self.lang_box, self.lang_flag, self.lang_name, self.chev):
            w.configure(bg=c)

    def _draw_chevron(self):
        """Рисует стрелку «>», повёрнутую на self.chev_angle градусов."""
        self.chev.delete("all")
        a = math.radians(self.chev_angle)
        pts = []
        for x, y in ((-3, -6), (3, 0), (-3, 6)):
            pts += [11 + x * math.cos(a) - y * math.sin(a), 11 + x * math.sin(a) + y * math.cos(a)]
        self.chev.create_line(*pts, fill=FG, width=2, capstyle="round", joinstyle="round")

    def _animate_chevron(self, target):
        step = 15 if target > self.chev_angle else -15
        if abs(target - self.chev_angle) <= abs(step):
            self.chev_angle = target
            self._draw_chevron()
            return
        self.chev_angle += step
        self._draw_chevron()
        self.root.after(12, lambda: self._animate_chevron(target))

    def toggle_lang_menu(self):
        if self.lang_menu:
            self.close_lang_menu()
            return
        self._animate_chevron(CHEVRON_OPEN_ANGLE)
        menu = tk.Frame(self.root, bg=PANEL, highlightthickness=1, highlightbackground=ACCENT)
        for code in ("en", "ru", "es"):
            row = tk.Frame(menu, bg=PANEL, cursor="hand2")
            row.pack(fill="x")
            fl = tk.Label(row, image=self.flags[code], bg=PANEL)
            fl.pack(side="left", padx=(10, 8), pady=6)
            nm = tk.Label(row, text=LANGS[code], bg=PANEL, fg=ACCENT if code == self.cfg["lang"] else FG,
                          font=(UI_BOLD, 10), anchor="w", width=10)
            nm.pack(side="left", padx=(0, 10))
            for w in (row, fl, nm):
                w.bind("<Button-1>", lambda e, c=code: self.set_lang(c))
                w.bind("<Enter>", lambda e, ws=(row, fl, nm): [x.configure(bg=HOVER) for x in ws])
                w.bind("<Leave>", lambda e, ws=(row, fl, nm): [x.configure(bg=PANEL) for x in ws])
        self.root.update_idletasks()
        x = self.lang_box.winfo_rootx() - self.root.winfo_rootx()
        y = self.lang_box.winfo_rooty() - self.root.winfo_rooty() + self.lang_box.winfo_height() + 4
        menu.place(x=x, y=y, width=max(self.lang_box.winfo_width(), 150))
        menu.lift()
        self.lang_menu = menu

    def close_lang_menu(self):
        if self.lang_menu:
            self.lang_menu.destroy()
            self.lang_menu = None
            self._animate_chevron(0)

    # ---------- виджеты ----------
    def show_tab(self, key):
        self.cur_tab = key
        for k, page in self.pages.items():
            page.pack_forget()
            self.tab_btns[k].configure(bg=PANEL if k == key else BG, fg=FG if k == key else MUTED)
            self.tab_bars[k].configure(bg=ACCENT if k == key and self.cfg["enhanced"] else BG)
        self.pages[key].pack(fill="both", expand=True, pady=(0, 8))

    def _btn(self, parent, text, cmd, color):
        if not self.cfg["enhanced"]:
            return tk.Button(parent, text=text, command=cmd, bg=color, fg=ACCENT_FG if color == ACCENT else FG,
                             activebackground=ACCENT, activeforeground=ACCENT_FG, relief="flat",
                             font=(UI_BOLD, 10), padx=10, pady=7, cursor="hand2", bd=0)
        acc = color == ACCENT
        hover = mix(ACCENT, ACCENT2, 0.45) if acc else mix(color, ACCENT, 0.22)
        b = tk.Button(parent, text=text, command=cmd, bg=color, fg=ACCENT_FG if acc else FG,
                      activebackground=ACCENT2, activeforeground=ACCENT_FG, relief="flat", font=(UI_BOLD, 10),
                      padx=10, pady=7, cursor="hand2", bd=0, highlightthickness=1,
                      highlightbackground=mix(ACCENT, ACCENT2, 0.5) if acc else LINE)
        b.base_bg, b.hov = color, False
        b.bind("<Enter>", lambda e: (setattr(b, "hov", True), b.configure(bg=hover)))
        b.bind("<Leave>", lambda e: (setattr(b, "hov", False), b.configure(bg=color)))
        b.bind("<ButtonPress-1>", lambda e: self._ripple(b, b.cget("highlightbackground"), 0), add="+")
        return b

    def _ripple(self, b, base, k):
        """Вспышка обводки кнопки при нажатии: белая → обычная."""
        try:
            b.configure(highlightbackground=mix("#ffffff", base, k / 8), highlightcolor=mix("#ffffff", base, k / 8))
        except tk.TclError:
            return
        if k < 8:
            self.root.after(30, lambda: self._ripple(b, base, k + 1))

    def _panel(self, parent, title_key, expand=False):
        if not self.cfg["enhanced"]:
            outer = tk.Frame(parent, bg=PANEL, highlightthickness=1, highlightbackground=LINE)  # обводка
            outer.pack(fill="both" if expand else "x", expand=expand, padx=14, pady=5)
            lbl = tk.Label(outer, bg=PANEL, fg=MUTED, font=(UI_BOLD, 8))
            lbl.pack(anchor="w", padx=10, pady=(8, 2))
            self.tr_widgets.append((lbl, title_key))
            lbl.configure(text=self.t(title_key).upper())
            inner = tk.Frame(outer, bg=PANEL)
            inner.pack(fill="both", expand=True, padx=10, pady=(0, 10))
            self._panel_titles.add(lbl)
            return inner
        outer = tk.Frame(parent, bg=PANEL, highlightthickness=1, highlightbackground=LINE)
        outer.pack(fill="both" if expand else "x", expand=expand, padx=14, pady=5)
        head = tk.Frame(outer, bg=PANEL)
        head.pack(fill="x", padx=10, pady=(8, 4))
        tk.Frame(head, width=3, height=11, bg=ACCENT).pack(side="left")
        tk.Frame(head, width=3, height=11, bg=ACCENT2).pack(side="left", padx=(2, 0))
        lbl = tk.Label(head, bg=PANEL, fg=mix(MUTED, ACCENT, 0.45), font=(UI_BOLD, 8))
        lbl.pack(side="left", padx=(7, 0))
        rule = tk.Canvas(head, height=5, bg=PANEL, highlightthickness=0)   # линия с бегущей «кометой»
        rule.pack(side="left", fill="x", expand=True, padx=(8, 0))
        self.fx_panels.append({"outer": outer, "rule": rule, "k": len(self.fx_panels)})
        self.tr_widgets.append((lbl, title_key))
        lbl.configure(text=self.t(title_key).upper())
        inner = tk.Frame(outer, bg=PANEL)
        inner.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self._panel_titles.add(lbl)
        return inner

    def _field(self, parent, key, var, row):
        self._tr(tk.Label(parent, bg=PANEL, fg=FG, font=FONT, justify="left"), key).grid(
            row=row, column=0, sticky="w", pady=2)
        tk.Entry(parent, textvariable=var, width=8, bg=BG, fg=FG, insertbackground=FG, relief="flat",
                 font=FONT, justify="center").grid(row=row, column=1, sticky="e", padx=(10, 0), pady=2)
        parent.grid_columnconfigure(0, weight=1)

    def _check(self, parent, key, var, row, cmd=None, wrap=400):
        self._tr(tk.Checkbutton(parent, variable=var, command=cmd, bg=PANEL, fg=FG, selectcolor=BG,
                                activebackground=PANEL, activeforeground=FG, font=FONT, anchor="w",
                                justify="left", wraplength=wrap), key).grid(
            row=row, column=0, columnspan=2, sticky="w")

    # ---------- горячие клавиши ----------
    def hot_pressed(self, action):
        vk = key_to_vk(self.cfg["hotkeys"][action])
        return vk is not None and pm.user32.GetAsyncKeyState(vk) & 1

    def reset_key_states(self):
        for a in HOTKEYS:
            self.hot_pressed(a)

    def capture_hotkey(self, action, ev):
        name = ev.keysym
        if name in ("Prior", "Next"):
            name = "PageUp" if name == "Prior" else "PageDown"
        if key_to_vk(name) is None:
            self.log(self.t("log_badkey", k=ev.keysym))
            return "break"
        for other, val in self.cfg["hotkeys"].items():
            if other != action and key_to_vk(val) == key_to_vk(name):
                self.log(self.t("log_keybusy", k=name, a=self.t("hk_" + other)))
                return "break"
        self.cfg["hotkeys"][action] = name
        e = self.hot_entries[action]
        e.delete(0, "end")
        e.insert(0, name)
        save_cfg(self.cfg)
        self.root.focus_set()
        self.reset_key_states()
        self.update_status()
        self.update_calib_label()
        self.log(self.t("log_keyset", a=self.t("hk_" + action), k=name))
        return "break"

    # ---------- логика UI ----------
    def log(self, msg):
        self.q.put(("log", time.strftime("[%H:%M:%S] ") + msg))

    def _append_log(self, line):
        self.log_lines = (self.log_lines + [line])[-400:]
        self.log_box.configure(state="normal")
        if self.cfg["enhanced"]:
            self.log_n = getattr(self, "log_n", 0) + 1
            tag = "new%d" % self.log_n
            self.log_box.insert("end", line + "\n", tag)
            self.log_box.tag_configure(tag, foreground=ACCENT2)
            self.log_fx.append((tag, getattr(self, "fx_t", 0)))
        else:
            self.log_box.insert("end", line + "\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def update_status(self):
        if not self.cfg["buttons"]:
            self.status.configure(text=self.t("status_calib"), fg=WARN)
        elif self.running:
            self.status.configure(text=self.t("status_run", n=self.bought), fg=GOOD)
        else:
            self.status.configure(text=self.t("status_pause"), fg=MUTED)
        h = self.cfg["hotkeys"]
        self.start_btn.configure(text=self.t("btn_pause" if self.running else "btn_start", k=h["start"]))
        self.check_btn.configure(text=self.t("btn_check", k=h["check"]))

    def update_calib_label(self):
        b = self.cfg["buttons"]
        k = self.cfg["hotkeys"]["calib"]
        if self.calib:
            txt = self.t("calib_progress", n=len(self.calib), next=len(self.calib) + 1, k=k)
        elif b:
            txt = self.t("calib_done") + "   ".join(f"{i + 1}) {x},{y}" for i, (x, y) in enumerate(b))
        else:
            txt = self.t("calib_help", k=k)
        self.cal_lbl.configure(text=txt)

    def apply_settings(self):
        try:
            self.cfg["scan_interval"] = max(1, float(self.v_interval.get()))
        except ValueError:
            pass
        try:
            self.cfg["clicks"] = max(1, int(self.v_clicks.get()))
        except ValueError:
            pass
        try:
            self.cfg["jump_interval"] = max(0, float(self.v_jump.get()))
        except ValueError:
            pass
        self.cfg["open_key"] = self.v_key.get().strip()[:1]
        self.cfg["webhook"] = self.v_hook.get().strip()
        self.cfg["webhook_text"] = self.v_hook_text.get()
        self.cfg["discord_id"] = self.v_id.get().strip()
        self.cfg["weather_ping"] = self.v_wping.get()
        self.cfg["weather_link"] = self.v_wlink.get().strip()
        for k, v in self.ev_vars.items():
            self.cfg[k] = v.get()
        save_cfg(self.cfg)

    def toggle(self):
        if not self.cfg["buttons"]:
            self.log(self.t("log_need_calib", k=self.cfg["hotkeys"]["calib"]))
            return
        self.running = not self.running
        self.next_scan = 0
        self.next_jump = time.time() + 1.5  # первый прыжок сразу после старта
        self.log(self.t("log_start" if self.running else "log_pause"))
        if self.running:
            if self.stock_due is None:
                self.stock_due = time.time() + STOCK_PERIOD_SEC
            self.warn_no_items()
        else:
            self.root.after(300, self.offer_update)   # вышло обновление, пока макро работал, — предлагаем на паузе
        self.update_status()

    def reset_calib(self):
        self.calib = []
        self.cfg["buttons"] = None
        self.running = False
        self.stock_sig = self.stock_pending = None
        save_cfg(self.cfg)
        self.update_calib_label()
        self.update_status()
        self.log(self.t("log_calib_reset"))

    def do_jump(self, why_key="why_afk"):
        why = self.t(why_key)
        pm.press_key(" ")
        self.log(self.t("log_jump", why=why))
        return True

    def test_jump(self):
        self.log(self.t("log_testjump"))

        def run():
            time.sleep(3)
            self.do_jump("why_test")
        threading.Thread(target=run, daemon=True).start()

    def check_now(self):
        if not self.cfg["buttons"]:
            self.log(self.t("log_need_calib", k=self.cfg["hotkeys"]["calib"]))
            return
        threading.Thread(target=self.scan, args=(False,), daemon=True).start()
        if self.cfg["weather_on"]:
            threading.Thread(target=self.report_weather, args=(False,), daemon=True).start()

    # ---------- погода ----------
    def save_weather(self):
        self.cfg["weather_on"] = [w for w, _ in pm.WEATHERS if self.weather_vars[w].get()]
        save_cfg(self.cfg)
        if self.cfg["weather_on"] and not self.cfg["webhook"] and not getattr(self, "_weather_hook_warned", False):
            self._weather_hook_warned = True
            self.log(self.t("log_weather_nohook"))

    def look_weather(self):
        """Смотрит на ряд иконок вверху экрана. Возвращает (найденные [(id, оценка)], все оценки, снимок, сдвиг)
        или None, если полоса с рядом иконок не помещается на экран."""
        b = self.cfg["buttons"]
        img, off = pm.grab_weather(b)
        if img is None:
            return None
        scores = pm.weather_scores(img, b, off)
        found = sorted(((w, v[0]) for w, v in scores.items() if v[0] >= pm.WEATHER_MIN_SCORE and v[1]),
                       key=lambda f: -f[1])
        return found, scores, img, off

    def check_weather_now(self):
        if not self.cfg["buttons"]:
            self.log(self.t("log_need_calib", k=self.cfg["hotkeys"]["calib"]))
            return
        threading.Thread(target=self.report_weather, args=(True,), daemon=True).start()

    def report_weather(self, show):
        """Пишет в лог, какую погоду макро видит прямо сейчас (ничего не отправляет). show — показать полосу,
        в которой он ищет, в превью на вкладке «Главное». Полоса сохраняется в debug_weather.png."""
        try:
            res = self.look_weather()
            if res is None:
                self.log(self.t("log_weather_noscreen"))
                return
            found, scores, img, off = res
            if found:
                self.log(self.t("log_weather_now", list=", ".join(
                    "%s (%d%%)" % (pm.WEATHER_NAMES[w], round(s * 100)) for w, s in found)))
            else:
                wid, v = max(scores.items(), key=lambda kv: kv[1][0])      # самое похожее место в полосе
                key = "log_weather_fake" if v[0] >= pm.WEATHER_MIN_SCORE else "log_weather_none"
                self.log(self.t(key, w=pm.WEATHER_NAMES[wid], p=round(v[0] * 100),
                                min=round(pm.WEATHER_MIN_SCORE * 100)))
            pic = img.copy()
            names = [w for w, _ in found]
            for wid, v in scores.items():     # зелёная рамка — погода; красная — похоже, но это не иконка погоды
                if v[2] is not None and (wid in names or v[0] >= pm.WEATHER_MIN_SCORE):
                    (x, y), half = v[2], int(v[3] / 2)
                    cv2.rectangle(pic, (x - off[0] - half, y - off[1] - half),
                                  (x - off[0] + half, y - off[1] + half),
                                  (0, 255, 0) if wid in names else (0, 0, 255), 2)
            cv2.imwrite(os.path.join(pm.HERE, "debug_weather.png"), pic)
            if show:
                self.q.put(("img", pic))
        except Exception as e:
            self.log(self.t("log_error", e=e))

    def weather_started(self, wid):
        name = pm.WEATHER_NAMES[wid]
        self.log(self.t("log_weather_start", w=name))
        if self.cfg["webhook"]:
            text = self.t("weather_msg", e=WEATHER_EMOJI.get(wid, ""), w=name).strip()
            if self.cfg["weather_link"]:
                text += "\n" + self.cfg["weather_link"]
            self.send_stock(text, ping=self.cfg["weather_ping"])

    def weather_loop(self):
        """Отдельный поток: раз в WEATHER_CHECK_SEC смотрит на ряд иконок и сообщает, когда началась отмеченная
        погода. Иконка должна быть видна WEATHER_HITS проверок подряд; пока погода идёт, второй раз не сообщаем."""
        hits = {}
        while not self.stop_evt.is_set():
            time.sleep(WEATHER_CHECK_SEC)
            on = list(self.cfg["weather_on"])
            if not (self.running and self.cfg["buttons"] and on):
                hits.clear()
                continue
            try:
                res = self.look_weather()
                if res is None:
                    continue
                seen = {w for w, _ in res[0]}
                now = time.time()
                for wid in on:
                    hits[wid] = hits.get(wid, 0) + 1 if wid in seen else 0
                    if hits[wid] >= WEATHER_HITS:
                        fresh = wid not in self.weather_active
                        self.weather_active[wid] = now
                        if fresh:
                            self.weather_started(wid)
                for wid in [w for w, t in self.weather_active.items() if now - t > WEATHER_GAP_SEC]:
                    del self.weather_active[wid]
                    self.log(self.t("log_weather_end", w=pm.WEATHER_NAMES[wid]))
            except Exception as e:
                self.log(self.t("log_error", e=e))
                time.sleep(2)

    # ---------- обновление ----------
    def update_loop(self):
        """Отдельный поток: сразу после запуска и потом раз в UPDATE_CHECK_SEC смотрит, не вышла ли новая версия.
        Нет интернета или файла с версией — молча пробуем в следующий раз."""
        self.stop_evt.wait(2)
        while not self.stop_evt.is_set():
            info, _err = pm.check_update()
            if info and info["version"] != (self.update_info or {}).get("version"):
                self.update_info = info
                self.log(self.t("log_upd_found", new=info["version"], old=pm.VERSION))
                if self.running and self.cfg["update_skipped"] != info["version"]:
                    self.log(self.t("log_upd_later"))
                self.q.put(("update", None))
            self.stop_evt.wait(UPDATE_CHECK_SEC)

    def offer_update(self):
        """Первое окно: «A New Update Is Available!» — Update / No, thanks. Пока макро работает, окно не открываем
        (оно забрало бы фокус у Roblox, и макро перестал бы кликать) — откроем, когда его поставят на паузу.
        Окно показывается один раз на версию: после отказа («Yes» во втором окне) о ней больше не спрашиваем."""
        info = self.update_info
        if (not info or self.cfg["update_skipped"] == info["version"] or self.running or self.update_busy
                or self.update_win is not None):
            return
        self._update_window(1)

    def _update_window(self, step, error=None):
        """Окно обновления. step 1: «вышло обновление» (Update / No, thanks.), step 2: «точно не хочешь?»
        (Yes — не обновлять, No — назад к первому окну). error — текст ошибки под заголовком первого окна."""
        self._close_update_window()
        info = self.update_info
        if not info:
            return
        win = tk.Toplevel(self.root, bg=BG)
        win.title("Merchant Macro")
        win.resizable(False, False)
        win.transient(self.root)
        win.attributes("-topmost", True)
        card = tk.Frame(win, bg=PANEL, highlightthickness=1, highlightbackground=ACCENT)
        card.pack(padx=12, pady=12)
        tk.Label(card, text=self.t("upd_title" if step == 1 else "upd_sure"), bg=PANEL, fg=FG, font=(UI_BOLD, 13),
                 wraplength=340, justify="center").pack(padx=24, pady=(18, 4))
        self.update_note = None
        if step == 1:
            self.update_note = tk.Label(card, text=error or self.t("upd_ver", new=info["version"], old=pm.VERSION),
                                        bg=PANEL, fg=BAD if error else MUTED, font=(UI_FONT, 9), wraplength=340,
                                        justify="center")
            self.update_note.pack(padx=24)
        row = tk.Frame(card, bg=PANEL)
        row.pack(padx=24, pady=(14, 18))
        if step == 1:
            b1 = self._btn(row, self.t("upd_yes"), self._update_go, ACCENT)
            b2 = self._btn(row, self.t("upd_no"), lambda: self._update_window(2), BG)
            win.protocol("WM_DELETE_WINDOW", lambda: self.update_busy or self._update_window(2))
        else:
            b1 = self._btn(row, self.t("upd_sure_yes"), self._update_decline, BG)
            b2 = self._btn(row, self.t("upd_sure_no"), lambda: self._update_window(1), BG)
            win.protocol("WM_DELETE_WINDOW", self._update_decline)
        for b in (b1, b2):
            b.configure(width=12)
        b1.pack(side="left", padx=(0, 8))
        b2.pack(side="left")
        self.update_btns = (b1, b2)
        self.update_win, self.update_step = win, step
        win.update_idletasks()                       # по центру окна макро
        x = self.root.winfo_rootx() + (self.root.winfo_width() - win.winfo_reqwidth()) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - win.winfo_reqheight()) // 3
        win.geometry("+%d+%d" % (max(0, x), max(0, y)))
        try:
            win.grab_set()                           # пока окно открыто, остальное окно макро не нажимается
        except tk.TclError:
            pass

    def _close_update_window(self):
        win, self.update_win, self.update_step = self.update_win, None, 0
        if win is not None:
            try:
                win.grab_release()
                win.destroy()
            except tk.TclError:
                pass

    def _update_decline(self):
        """«Yes» во втором окне: не обновляем и про эту версию больше не спрашиваем (запоминается в настройках,
        так что и после перезапуска макро). Выйдет версия новее — окно появится снова."""
        self._close_update_window()
        if self.update_info:
            self.cfg["update_skipped"] = self.update_info["version"]
            save_cfg(self.cfg)
            self.log(self.t("log_upd_skip", new=self.update_info["version"]))

    def _update_go(self):
        """«Update»: скачиваем обновление в фоне, окно остаётся с надписью «Downloading…»."""
        if self.update_busy or not self.update_info:
            return
        self.update_busy = True
        for b in self.update_btns:
            b.configure(state="disabled")
        if self.update_note is not None:
            self.update_note.configure(text=self.t("upd_working"), fg=MUTED)
        threading.Thread(target=self._do_update, args=(self.update_info,), daemon=True).start()

    def _do_update(self, info):
        try:
            pm.install_update(pm.download_update(info))
            self.log(self.t("log_upd_done", new=info["version"]))
            self.q.put(("restart", None))
        except Exception as e:
            self.q.put(("update_failed", str(e)))

    def restart(self):
        """Закрывает это окно и запускает макро заново — уже из обновлённых файлов."""
        self.stop_evt.set()
        try:
            self.root.destroy()
        except tk.TclError:
            pass
        pm.restart_macro()

    # ---------- Discord ----------
    def ping_prefix(self, ping):
        """«<@ID> » — пинг в Discord, если включён и ID указан."""
        uid = self.cfg["discord_id"]
        if not (ping and uid):
            return ""
        if not uid.isdigit():
            self.log(self.t("log_id_bad"))
            return ""
        return f"<@{uid}> "

    def send_stock(self, text, test=False, ping=False):
        url = self.cfg["webhook"]
        text = self.ping_prefix(ping) + text
        if not url:
            if test:
                self.log(self.t("log_hook_none"))
            return
        if not url.startswith(("https://discord.com/api/webhooks/", "https://discordapp.com/api/webhooks/",
                               "https://ptb.discord.com/api/webhooks/", "https://canary.discord.com/api/webhooks/")):
            self.log(self.t("log_hook_bad"))
            return
        img = pm.grab_screen(self.cfg["buttons"])

        def run():
            ok, msg = pm.send_discord(url, img, text)
            self.log(self.t("log_hook_ok") if ok else self.t("log_hook_err", m=msg))
        threading.Thread(target=run, daemon=True).start()

    def test_webhook(self):
        if not self.cfg["buttons"]:
            self.log(self.t("log_need_calib", k=self.cfg["hotkeys"]["calib"]))
            return
        self.log(self.t("log_hook_testing"))
        self.send_stock(self.t("hook_test_msg"), test=True)

    def stock_text(self, img, off):
        # Кадр, пойманный ровно в 59:59, бывает «сырым»: новые карточки ещё появляются (третья — последней).
        # Поэтому читаем сток заново, пока все карточки не узнаются уверенно два раза подряд (до ~2 сек).
        b = self.cfg["buttons"]
        region = pm.scan_region(b)
        stock, prev = pm.identify_stock(img, b, off), None
        for _ in range(7):
            time.sleep(0.3)
            img, off = pm.grab(region)
            stock = pm.identify_stock(img, b, off) or stock
            if stock == prev and pm.stock_is_sure(img, b, off):
                break
            prev = stock
        text = self.cfg["webhook_text"].strip()
        if stock:
            seen = ", ".join(self.t("stock_slot", n=s + 1, kind=self.kind_name(k)) for s, k in stock)
            text += "\n" + self.t("stock_potions", list=seen)
        else:
            text += "\n" + self.t("stock_none")
        return text

    def read_timer(self):
        """True — первая цифра минут «5», False — другая, None — таймер не виден."""
        img, _ = pm.grab(pm.timer_rect(self.cfg["buttons"]))
        return pm.timer_tens_is_five(img)

    def watch_timer(self):
        """Раз в секунду: если первая цифра минут сменилась с «0» на «5» (00:00 -> 59:59) — новый сток."""
        five = self.read_timer()
        if five is None:
            return  # торговец закрыт / таймер не виден
        now = time.time()
        # прыжок считается, только если «не 5» видели только что: после перерыва (RDP был свёрнут,
        # экран чёрный) старое значение ничего не значит
        jumped = self.timer_prev is False and five and now - self.timer_prev_t < 2.0
        self.timer_prev, self.timer_prev_t = five, now
        if jumped:
            self.refresh_seen_t = now
            self.log(self.t("log_timer_reset"))
            img, off = pm.grab(pm.scan_region(self.cfg["buttons"]))
            self.stock_refreshed(img, off)

    def check_stock(self, img, off):
        """Запасной способ: поменялись названия товаров (подтверждается второй проверкой подряд).
        Возвращает True, если окно торговца сейчас открыто."""
        if not pm.merchant_open(img, self.cfg["buttons"], off):
            return False  # торговец закрыт (или поверх него другое окно — инвентарь)
        sig = pm.stock_signature(img, self.cfg["buttons"], off)
        with self.stock_lock:
            self._check_stock_sig(sig, img, off)
        return True

    def _check_stock_sig(self, sig, img, off):
        if self.stock_sig is None:
            self.stock_sig = sig
            self.log(self.t("log_stock_saved"))
        elif not pm.stock_changed(self.stock_sig, sig):
            self.stock_pending = None
        elif self.stock_pending is None or pm.stock_changed(self.stock_pending, sig):
            self.stock_pending = sig  # ждём подтверждения следующей проверкой
        else:
            self.stock_sig, self.stock_pending = sig, None
            # настоящее обновление бывает только при таймере 59:59–50:00 (первая цифра минут «5»);
            # иначе это экран «ожил» после сворачивания RDP — просто запоминаем сток без скрина
            if self.read_timer():
                self.stock_refreshed(img, off)

    def stock_refreshed(self, img, off):
        """Замечено обновление стока (таймер перескочил на 59:xx или сменились названия). Правило — у STOCK_PERIOD_SEC."""
        now = time.time()
        early = None
        with self.stock_lock:
            b = self.cfg["buttons"]
            if pm.merchant_open(img, b, off):
                self.stock_sig, self.stock_pending = pm.stock_signature(img, b, off), None
            if now - self.stock_refresh_t < STOCK_SAME_SEC:
                return                      # то же самое обновление, замеченное вторым способом
            self.stock_refresh_t = now
            self.bought_stock = None        # новый сток — сделка этого часа ещё впереди
            left = (self.stock_due or now) - now
            if self.stock_synced and left > STOCK_EARLY_SEC:
                early = int(left // 60)     # до конца часа далеко: скрин этого часа уже был
            else:
                self.stock_due, self.stock_synced = now + STOCK_PERIOD_SEC, True
        if early is not None:
            self.log(self.t("log_stock_early", m=early))
            return
        self.log(self.t("log_stock_new"))
        if self.cfg["webhook_on"] and self.cfg["webhook"]:
            self.send_stock(self.stock_text(img, off), ping=self.cfg["ping_stock"])

    def stock_hourly(self, img, off, is_open):
        """Сток раз в час, даже если его обновление не замечено (окно торговца было закрыто, таймер не прочитался).
        is_open — открыто ли сейчас окно торговца (из check_stock)."""
        now = time.time()
        with self.stock_lock:
            if self.stock_due is None or now < self.stock_due + STOCK_LATE_SEC:
                return
            if not is_open:
                return                      # стока не видно — пришлём, как только окно торговца откроется
            while self.stock_due + STOCK_LATE_SEC <= now:
                self.stock_due += STOCK_PERIOD_SEC
            self.stock_refresh_t = now
            self.bought_stock = None
        self.log(self.t("log_stock_hour"))
        if self.cfg["webhook_on"] and self.cfg["webhook"]:
            self.send_stock(self.stock_text(img, off), ping=self.cfg["ping_stock"])

    def show_preview_with_timer(self, res):
        """Превью для «Проверить сейчас»: окно торговца целиком + где ищем/нашли таймер."""
        b = self.cfg["buttons"]
        sx0, sy0, sx1, sy1, _ = pm.scan_region(b)
        tx0, ty0, tx1, ty1, _ = pm.timer_rect(b)
        img, off = pm.grab((min(sx0, tx0), ty0, max(sx1, tx1), sy1, 0))
        band = img[ty0 - off[1]:ty1 - off[1], tx0 - off[0]:tx1 - off[0]]
        row = pm.find_timer_row(band)
        img = img.copy()
        cv2.rectangle(img, (tx0 - off[0], ty0 - off[1]), (tx1 - off[0] - 1, ty1 - off[1] - 1), (0, 200, 255), 2)
        if row:
            cv2.rectangle(img, (tx0 - off[0], ty0 - off[1] + row[0] - 2),
                          (tx1 - off[0] - 1, ty0 - off[1] + row[1] + 2), (0, 255, 0), 2)
        self.show_preview(img, res, off)

    def show_preview(self, img, res, off):
        img = img.copy()
        for b in self.cfg["buttons"]:
            cv2.circle(img, (b[0] - off[0], b[1] - off[1]), 8, (0, 0, 255), 2)
        if res:
            cv2.circle(img, (res[1][0] - off[0], res[1][1] - off[1]), 22, (0, 255, 0), 3)
        cv2.imwrite(os.path.join(pm.HERE, "debug.png"), img)
        self.q.put(("img", img))

    def _preview_resized(self, ev):
        if abs(ev.width - self.pv_width) > 4:
            self.pv_width = ev.width
            if self._raw_preview is not None:
                self.root.after_idle(self._render_preview)

    def _render_preview(self):
        """Вписывает последнюю картинку в ширину панели (но не больше PREVIEW_W x PREVIEW_H)."""
        img = self._raw_preview
        h, w = img.shape[:2]
        scale = min(max(50, self.pv_width) / w, PREVIEW_W / w, PREVIEW_H / h)
        img = cv2.resize(img, (max(1, int(w * scale)), max(1, int(h * scale))), interpolation=cv2.INTER_AREA)
        ok, png = cv2.imencode(".png", img)
        if ok:
            self._img = tk.PhotoImage(data=base64.b64encode(png.tobytes()))
            self.preview.configure(image=self._img, text="")

    def poll(self):
        # горячие клавиши
        if self.hot_pressed("exit"):
            return self.quit()
        if self.hot_pressed("start"):
            self.toggle()
        if self.hot_pressed("check"):
            self.check_now()
        if self.hot_pressed("calib"):
            pt = wintypes.POINT()
            pm.user32.GetCursorPos(ctypes.byref(pt))
            self.calib.append((pt.x, pt.y))
            self.log(self.t("log_calib_point", n=len(self.calib), x=pt.x, y=pt.y))
            if len(self.calib) == 3:
                self.cfg["buttons"] = sorted(self.calib)
                self.calib = []
                self.stock_sig = self.stock_pending = None
                save_cfg(self.cfg)
                self.log(self.t("log_calib_saved"))
                self.update_status()
            self.update_calib_label()
        # сообщения из фонового потока
        while not self.q.empty():
            kind, data = self.q.get()
            if kind == "log":
                self._append_log(data)
            elif kind == "img":
                self._raw_preview = data
                self._render_preview()
            elif kind == "status":
                self.update_status()
            elif kind == "update":
                self.offer_update()
            elif kind == "update_failed":
                self.update_busy = False
                self._update_window(1, error=self.t("upd_failed", e=data))
            elif kind == "restart":
                return self.restart()
        self.root.after(50, self.poll)

    # ---------- фоновый цикл ----------
    def scan(self, do_buy):
        with self.scan_lock:
            self._scan(do_buy)

    def _scan(self, do_buy):
        try:
            buttons = self.cfg["buttons"]
            if self.close_reward_popup(do_buy):
                return
            if do_buy and self.cfg["open_key"]:
                pm.press_key(self.cfg["open_key"])
                time.sleep(1.0)
            region = pm.scan_region(buttons)
            wait = getattr(self, "refresh_seen_t", 0) + REFRESH_SETTLE_SEC - time.time()
            if do_buy and 0 < wait <= REFRESH_SETTLE_SEC:
                time.sleep(wait)            # сток только что обновился — карточки ещё меняются
            img, off = pm.grab(region)
            if do_buy:
                is_open = self.check_stock(img, off)
                self.stock_hourly(img, off, is_open)
            else:
                five = self.read_timer()
                self.log(self.t("log_timer_none" if five is None else
                                "log_timer_five" if five else "log_timer_other"))
            best = self.read_best(buttons, region, img, off)
            res = None
            if best and best[0] is not None:  # на превью обводим иконку выбранного товара
                bx, by = buttons[best[0]]
                sp = pm.scan_region(buttons)[4]
                res = (best[0], (int(bx - sp * 0.29), int(by - sp * 0.56)))
            self.show_preview_with_timer(res)  # превью всегда целиком: карточки + таймер с рамками
            if not best:
                self.log(self.t("log_no_potion"))
                return
            slot, pos, kind, all_kinds = best
            seen = ", ".join(self.t("slot_kind", n=s + 1, kind=self.kind_name(k)) for s, k in all_kinds)
            if slot is None:
                if kind == pm.UNSURE:
                    self.log(self.t("log_unsure", seen=seen))
                elif kind == pm.TOO_SMALL:
                    self.log(self.t("log_too_small"))
                else:
                    self.log(self.t("log_seen_none", seen=seen))
                return
            if not do_buy:
                self.log(self.t("log_seen_test", seen=seen, n=slot + 1, kind=self.kind_name(kind)))
                return
            names = tuple(k for _, k in all_kinds)
            if names == self.bought_stock and time.time() - self.bought_at < BOUGHT_HOLD_SEC:
                if not self.bought_logged:  # сделка в этом часу уже удалась — карточки висят до нового стока
                    self.bought_logged = True
                    self.log(self.t("log_already"))
                return
            self.bought_logged = False
            self.log(self.t("log_buying", seen=seen, n=slot + 1, kind=self.kind_name(kind)))
            if self._best_frame is not None:    # кадр, по которому принято решение, — чтобы потом разобраться, если купит не то
                cv2.imwrite(os.path.join(pm.HERE, "last_buy.png"), self._best_frame)
            rect = pm.result_rect(buttons, slot)
            base_img, _ = pm.grab(rect)
            baseline = pm.result_colors(base_img)
            watch = pm.purchase_result(base_img) is None  # SUCCESS/FAILED уже висит — это старое, не шлём
            clicks = 0
            for n in range(self.cfg["clicks"]):
                # Перед КАЖДЫМ кликом смотрим на карточку ещё раз. Сток мог смениться (в 59:59 карточки меняются
                # за секунду-две, и клик попал бы уже по новому товару), а окно торговца — закрыться другим окном.
                g, o = pm.grab(region)
                if not pm.card_shows(g, buttons, slot, kind, o):
                    self.log(self.t("log_buy_changed"))
                    break
                pm.click(*pos)
                clicks += 1
                time.sleep(0.5)
                if watch and pm.purchase_result(pm.grab(rect)[0], baseline):
                    break  # SUCCESS!/FAILED уже появилось — больше не кликаем
            if not clicks:
                return
            self.bought += 1
            self.log(self.t("log_clicked", c=clicks))
            self.q.put(("status", None))
            if watch and self.watch_result(rect, baseline, slot, kind) == "success":
                self.bought_stock, self.bought_at = names, time.time()
        except Exception as e:
            self.log(self.t("log_error", e=e))

    def read_best(self, buttons, region, img, off, tries=6):
        """Смотрим сток несколько кадров подряд и выбираем товар, только когда все три карточки узнаны
        и два кадра совпали. Пока окно торговца открывается, название в карточке может ещё не прорисоваться —
        тогда раньше казалось, что первой карточки нет, и покупался товар ниже по списку."""
        order, on = self.cfg["items_order"], set(self.cfg["items_on"])
        prev, best = None, None
        for n in range(tries):
            if n:
                time.sleep(0.35)
                img, off = pm.grab(region)
            best = pm.find_best_item(img, buttons, order, on, off)
            self._best_frame = img
            if not best or best[2] == pm.TOO_SMALL:
                return best          # окно торговца не открыто / окно Roblox слишком маленькое
            now = (best[3], best[0], best[2])
            if now == prev and best[2] != pm.UNSURE:
                return best          # два кадра подряд одинаковые — решение надёжное
            prev = now
        return best                  # так и не уверены — find_best_item вернёт UNSURE, и мы ничего не купим

    def close_reward_popup(self, do_buy):
        """После катсцены мифика/годли висит окно «CLICK ANYWHERE TO CLOSE» — закрываем его одним кликом.
        True — окно было (торговца в этот раз не трогаем: он откроется сам после закрытия)."""
        b = self.cfg["buttons"]
        img, off = pm.grab(pm.close_popup_region(b))
        pos, _ = pm.find_close_popup(img, b, off)
        prev, self._popup_prev = getattr(self, "_popup_prev", None), pos
        if pos is None:
            return False
        if do_buy and (prev is None or abs(prev[0] - pos[0]) > 20 or abs(prev[1] - pos[1]) > 20):
            return False  # кликаем, только когда надпись на том же месте две проверки подряд (0.5 сек)
        if not do_buy:
            self.log(self.t("log_popup_test"))
            return False
        self.log(self.t("log_popup"))
        pm.click(*pos)
        time.sleep(1.5)
        return True

    def warn_no_items(self):
        if not self.cfg["items_on"]:
            self.log(self.t("log_items_empty"))

    def watch_result(self, rect, baseline, slot, kind, timeout=8.0):
        """Ждёт после кликов надпись SUCCESS! / FAILED на карточке и шлёт скрин в Discord."""
        buttons = self.cfg["buttons"]
        region = pm.scan_region(buttons)
        end = time.time() + timeout
        gone = False
        while time.time() < end and not self.stop_evt.is_set():
            img, _ = pm.grab(rect)
            res = pm.purchase_result(img, baseline)
            if res:
                # SUCCESS!/FAILED пишется на карточке торговца, и название товара при этом остаётся на месте. Если
                # карточки с этим товаром на экране сейчас нет (поверх торговца открыли инвентарь, сток сменился),
                # цвет на месте кнопки сменился не из-за покупки. Смотрим дважды: надпись должна устоять.
                time.sleep(0.3)  # даём надписи дорисоваться
                g, o = pm.grab(region)
                if pm.card_shows(g, buttons, slot, kind, o) and pm.purchase_result(pm.grab(rect)[0], baseline) == res:
                    ok = res == "success"
                    self.log(self.t("log_buy_success" if ok else "log_buy_fail"))
                    if self.cfg["hook_success" if ok else "hook_fail"] and self.cfg["webhook"]:
                        self.send_stock(self.t("buy_success" if ok else "buy_fail", n=slot + 1,
                                               kind=self.kind_name(kind)),
                                        ping=self.cfg["ping_success" if ok else "ping_fail"])
                    return res
                gone = True
            time.sleep(0.15)
        self.log(self.t("log_buy_gone" if gone else "log_buy_unknown"))
        return None

    def loop(self):
        self.next_scan = 0
        self.next_jump = 0
        while not self.stop_evt.is_set():
            time.sleep(0.2)
            jump = self.cfg["jump_interval"]
            if self.running and jump > 0 and time.time() >= self.next_jump:
                self.do_jump()
                self.next_jump = time.time() + jump
            if self.running and self.cfg["buttons"] and time.time() >= self.next_scan:
                self.next_scan = time.time() + self.cfg["scan_interval"]
                self.scan(True)

    def popup_loop(self):
        """Отдельный поток: раз в 0.5 сек ищет окно «CLICK ANYWHERE TO CLOSE» и закрывает его."""
        while not self.stop_evt.is_set():
            time.sleep(POPUP_CHECK_SEC)
            if not (self.running and self.cfg["buttons"]):
                continue
            if not self.scan_lock.acquire(blocking=False):
                continue  # сейчас идёт проверка/покупка у торговца — не мешаем ей кликами
            try:
                self.close_reward_popup(True)
            except Exception as e:
                self.log(self.t("log_error", e=e))
                time.sleep(2)
            finally:
                self.scan_lock.release()

    def timer_loop(self):
        """Отдельный поток: смотрит на таймер каждые 0.1 сек, чтобы поймать 59:59 даже во время покупки."""
        while not self.stop_evt.is_set():
            time.sleep(TIMER_CHECK_SEC)
            if not (self.running and self.cfg["buttons"]):
                self.timer_prev = None
                continue
            try:
                self.watch_timer()
            except Exception as e:
                self.log(self.t("log_error", e=e))
                time.sleep(2)

    def quit(self):
        self.stop_evt.set()
        self.root.destroy()


def _scaled_png(b64, width=None, height=None):
    """Картинка из base64, уменьшенная до нужной ширины/высоты (PNG в base64 для tk.PhotoImage)."""
    img = cv2.imdecode(np.frombuffer(base64.b64decode(b64), np.uint8), cv2.IMREAD_UNCHANGED)
    h, w = img.shape[:2]
    k = (width / w) if width else (height / h)
    img = cv2.resize(img, (max(1, int(w * k)), max(1, int(h * k))), interpolation=cv2.INTER_AREA)
    return base64.b64encode(cv2.imencode(".png", img)[1].tobytes())


# Скрин для вкладки «Благодарности» и эмодзи рядом с текстом
CREDITS_B64 = "iVBORw0KGgoAAAANSUhEUgAAA00AAACHCAIAAABF+iU0AAAQAElEQVR4AexdBWAURxeeWT2/Sy5ukODu7k5LoS2UUnehbtSpt/ylpUZL3VvaUqFCcXd3h5AQ9+TcVuZ/exdCgCAt2naWd3Mzb968efPtZfe7N3cHYzLZTiwxMUlUKAIUAYoARYAiQBGgCFAE/nEIMIgeFAGKAEWAIkAROIwArVEEKAL/HgQoz/v3nEu6EooARYAiQBGgCFAEKAK1EaA8rzYatP53EaDjKAIUAYoARYAiQBG48BCgPO/COyc0IooARYAiQBGgCPzTEaDxXxgIUJ53YZwHGgVFgCJAEaAIUAQoAhSBM40A5XlnGlHqjyJAEfi7CNBxFAGKAEWAInBmEaA878ziSb1RBCgCFAGKAEWAIkARuFAQ+KfzvAsFRxoHRYAiQBGgCFAEKAIUgQsNAcrzLrQzQuOhCFAEKAIUgdNBgI6lCFAEDiNAed5hLGiNIkARoAhQBCgCFAGKwL8JAcrz/k1nk67l7yJAx1EEKAIUAYoAReDfiADlef/Gs0rXRBGgCFAEKAIUAYrA6SDwbxlLed6/5UzSdVAEKAIUAYoARYAiQBE4EgHK847Eg7YoAhQBisDfRYCOowhQBCgCFxoClOddaGeExkMRoAhQBCgCFAGKAEXgzCBwcp636+XCiEQZVSpnGgEKKUWAIkARoAhQBCgCFIGzhcDJed6Z4ZPUC0WAIkARoAhQBCgCJ0eAWlAEziQClOedSTSpL4oARYAiQBGgCFAEKAIXDgKU510454JGQhH4uwjQcRQBigBFgCJAEagLAcrz6kKF6igCFAGKAEWAIkARoAj8cxE4FDnleYeQuACe+w4Z8dBzr7/z3bwPZm977fetj3w0a/g9TzftM8SQWP8CiI6GQBH4tyEgCKLRZLZYbFZr1D9RIHKIH1bxbzsxdD0UAYrAmUOA8rwzh+VpeLr06ts++HnpveMn9Rh8WUx8MpH8yFelx1JqakqHXn3bXTza3mO4mNLwNGagQykCFIHDCGCMDUaTXm/gWA7qhzv+UTWIHOKHVcBaoH76sVMPFAGKwL8PAcrzzvM5bdCk+Yvvfjdo9G1+JJR7AvlFpXv27MretcWVt8dbsAcHHEaRi4+xJaUkmdOb6Ru11lut5zliOj1F4J+PgN5g5Dn+n7+O6hXAWmBF1Q36RBGgCFAEaiFAeV4tMM55tV2nbk9P+iQqKc3p9VV5/eUOV0lJSc6BvXu2rMvcumbPhmUbViw6sHe3z+VgVdmsE1LS6o+4/sZmLZr/pUgtgqlvavdHOtzxeu/xk/o8M6nvM890f3BU42FxRvtf8lOXMdWdAQREjtdzujPgiLo4NQRgoxOI0fFsCUKKqh5PoPd4A8+vHlYE6zq/MZzK7E+Mf3HRii233XnfCYxPxeYEw+vsOhWfEBXEBpZ1erjAlRA2BA9LuEDihEggHojq1OMBYxgCA099CLU8FQSYUzGiNmcDgfRGjW9+eLw7EPAEfUFF8vn9bpcLq5JRYA0cwSEPKwc4IlWWFObnZAXcTr+rymwQG6bXf/DRcfXqp51KSALLX9ZgyLNdHrokfWCcIabIU7KuaEuOs4BHXLfkdo91vuuGFqMMvP4oV7AB1Da++Qt9H5o0+OlrWl+q58SIgcByo1sOm3TxU88MuK+hvV5EeTZKBuO+zTq/fs2jT4y4PdkWd7wpmqZkvHzV/a9f/0j/ll1Y5my9kgWW7Zne4alB90wa/iTILZ1GRxvOWEqVZdhhGQNe6fHESz0eva75SD1bDXVkySxmBqT0mtT92Yfa3BGtO2OTRpyfwdKiMw5t0fupi++aNPpxkBu6XWrWmY71b9Ebh7bp9dSlYydd+9ik6x69odcIs854rBmDcZt6TcaNuGnS9Y+CPH/FPcPb9zWKR7xKBY4f1rbPU8PHvj7m0UljHp905SEJB/D6FY/d3feaeMtx38bwgnDsvBGNSkgwGHI4XQ6H0+FyOZzOKocmUHE4nA6HKxgMgk3E+EIreeG464qE+sT4l5as2vrsi69GmrSkCJwdBKjXCwuBs3V3vLBWeUFGc8PdD3GiYDAbo6KjTSa9Wc+aeAQML9piiI+JsZgtUTabzQJZPJZBMs8Qv88dCnhsZpNOb7zuhpvRyQ6baL6r5Y09k7rkugvf2/L5kytefXPTJz/um/Hu5s+fXTVpwpr3tpftbR3f/KZWo83CEXfl5jENr219mVEwIITbJ7a8uEl/Fmuvkw4prbuktUEIWUXzFS0vtunNUD8b0iKlEdzFMWJizFG9mndEdR1w4x/WvpdOFDHDDG7bI8WeUJfV6eqAh41oOfiy1oOj9RGahZsnNBrRbCDPsqfrOjw+w5rWN7VbuIrbxrTsldIlXK8uUkxJg9J6I4ySTQlt7C2rtRfYU7PEBk8MHTuwWfdoYxgijFqnNh3dcYjAHQFRs+SMJy65Y2CL7tEmC6wIIdy6XtPR3Y420wvidX1GXN93RIItFoUPk97Qp3nnBy++MTkqLqxALMNc1n5gv2ZdYUYMr0yMEAgKH+EKxkxGTNodva4Cg7D26IJljoitplslqiwr0bFxo6669pqbbrnqupuuvuHW62/W5Kobb732ltuvuPZ6qz0hKClgWTPqwqkcb10XToQ0kgsKgcuvuOqn3+c9/tTzF1RUNJgzjoB2/z7jTqnDkyLQs/9gzAklpSW+gNdsNSYn2JvVT0i1682sLBKZIWpIVtxB+UB2XnbWQRIK1UtMiIuy2M1GgUWKrNiiYzt37X6CWSAzNKbRZanmpHk5S6Zs/fKgK/+oO1Ol3/HNzl9mHViUYUsbktGn5g4Be4h96nXBCIedE0RIp6Q2KdYknmWbxzRCsGsFglCMMSoj6qyk9IAfdG3QBnKKCCYj4cnCoRxVRJutdkuUpiSIw2z9mCStfqYfzeMbdKnXBkDQRHOuAWIQdQzQC615uo8kYxyugRqRaJ2ttsckYzwsDWAAiTfE1O66QOpm0Ti8VT+B5bWTBVFCWOEzVj8mOcoYPjugQcisMw5v20/gw2ZwTkE0Y1I/NjnKFF5y2AxOep8WnVrXaxzuDKug0BySKKN5VOchxnBWT8eJ9WISD52RwzODrTaw+olYdeYEa92gwUSa1ZEP+AORZCUuKbV++26ZQuI21b6Dic+yNWTrt7I1alUU32qvvWVuQmtz+75CXGogpID9kQ4Q3DUfeOTx62667cT6iNn9Dz9+2agxtS279eh974Pj7rrvoabNW9To4xOTRlx+xdh7HwR7cH73/Q+Pueb6evXTawxqV+pcV22DV19+pm/3Ni8++0RtJa3/ZxGw22Pt9jh4q/yfReA/snDK887PiW7asm1VRRnsyO7ctnnxgtk7t61zFuxWKzJ9BZmwU+utrJJUvCenYHtmwa7defn7cuvFxGYkxjVJTTAxiFNDOg516VR3ogshIA64W2KnRrb0NcWbFuatVIiC6jrgRrU0b8220t0dE1unmBMjJnF6e4olCWEcaUKFY9le9ToaeUOsyY5ADQJ9GDWMqQfPZ1yAH6Taq4NBGOeUF9Y5hVlvDNOLcCdG8ba67+jh7r9ZQBazfUqLMBIY4YgTeMIFzpKQIkfap1kedBXItc5OjvuIxRp4w2n6P9vDDTq9STSGwdGQ0aaDZ4Q4lhMYTmuGHwZRb6rZogVAQbQxmGPY2mZRJkunhofSlmE/2mitAg+cFpvYKOHQDwyBBxCtG4U9oeoDDLUaPGFNH35oipM9FFUNhpTk+g0S23WriGm8tsi7usCz3slucvPFEsuz8D6I3eZmNntFsX7zlHbdDEkZvqCiqOrJHB+3H8JPTEpu0+64f8UwsnnL1pdedkV6RgMR8tYYFIjn+YTEpKHDRrRq005r0wdFgCJAETgZAszJDC7Q/n90WA0aNYO3USaDXs+zXmd51v7t2zeucBYflJylxOdk5ZD2Sw8sJwGjw4JeZ06OTUiIju7drXOHdi2izTqbWYiJMTZuUq9160M3xSPhiNJZeyR2LPdXLshbFiF56ZbU+9rePKnPMxN7PXVRer+GUfVf7fNkU3tDRVWW5q2F0c1jqn+0JdYYI0B6Rsu4gLo6WZIelRptsPEMeyhfouljjDaRgwxN2OzMFXaz1SDoIv5CkpRfURypn7hkmPBt8MRGf7HXIOgTrQm1BzkDrt92zJ29Zwmpwad291+v57oL/jgwL6RI4HBR3sp1RZvBR5OojHHtx07q+exF9fpBMyId49qAZmKPp29pfpVdfzgHFuk9X2W5q3Lp/vXhVwWk3UC0F8axwZS7K5fuWV+tB+g0Q3iAVOsiTwm2GKuh+sMAZc7KV3//ZPy0dzZl7w47hUwqapJYD2MsE9kb8Nbk8yo9zjUHtqzJ2gJlpccVdgWeCbAwfygQbp688Pv9qWlpCW26ORKa7/QJPqDxBgsxRoUYUSU4VkSdo1BbCxIxYgUxvlHz1A7dDIlpHp8fncYhCHyz5i0EUajTR0pava7deuoNekmSd+/a+cPUr7758rNtWzaHQiGdTtehU2dI9dU5kCopAhQBikBtBCjPq43GOap37tzdarYwssyqIUGVDIwcY9HHRNvMZqsoiAzDCHDwAi+wUtDL4VBSvF3gCcsrerOABEVCgYDs9cvueg2S64y4ia2BVbRsKtvuCGq3vdYxze5uc2OiKX5r6a7NZTu6J3W8ovEwVVW9IS8ML/dWVvgr06wpQpi0WXUWhDDCGEUOeMYIlF1T22vfCYXmIT3PCCyu/pxTvNl+S+fREy95fNKlT04c/vjothfV/vResjX+iSF3Trz8sVbJjWG0ThCbJzWMMWv7erHm6MeG3j5h1CMtkxtBF0i8ObZmdoDiso6DXr/20UnXPfbU5Xf2bNIOdnXBBuRwAq86pOon6NIJwrB2fZ8fec+kax4DGXfxLR3TW9QMxBj3btzx9dGPPXHRnQ3j0qCpE8TL2g58feTjLw9/sHHcoYwRQrAEi5aFwggDqSBTN/3+8oIpKw5ujCTz9Lx4S8crJ1381D1dr28QnXZ31+teH/rUpKFP39B2pE1nhjBAks3xT/S4Z9Kg8X3SusJEoEkyxT/T44FJ/cf3SdU0QO9WFWx4Yc0bz69+Y3b2YiDlRs4wImNIgjEOjDXBWlHzAMCbRzfulaR9jM8imIZnDHy+28NA3yPfoR7WYADsaUaModK3Xvenetw3aeB4CODFPuNGNx9WE1jEBkoLbLw2HfB8/wdgIa9f/OQ93a9vYE+NhAq9IFBPi0q6petoOK2TLnvylUseGd3u8MlViLpwz6onf3v9xT/f+2HdTLAHrLTyyAfkvRbuXP3ktDde/HXKD6tnhW1gYSBH2NU+p8t2byx3OQKh0PLdG0Iy0C4Mo+xmm8Bx0HT4PQjjyOCssryfN8wFmbltiTvgCSuhC1f4qsrdVeHmyQu319emU5dgQsN9AT5IWL01yhiTIOhEjtWmwQjHinhYAm5nxSYWsbwQU79RYqsuVR7fyV0fxyIYDMqyEhMb26FTZdXfJAAAEABJREFU1zpNmjVraTKbwGbLpg3zZv9ZUlxcWVG+eOG8VSuWez3erAOZJUVHZH/rdHKU8rY771u0YssT4188Sl/TbNGyzetvfTB/6foV63YuXb3tp9/nXXfjEdvQ0Pzxt7lLVm0Fg4XLN370+XdduvaoGd6hU5df/1z87bQ/ajRQgelgUpga6nUKeAA/i1dsBp8wNQQA+cs6LWuUV1170zc//B4JA8qvvvt1yEWXIIRqDE7FZ+3FwuwQg8lc/Zdb46d2BRYya8GqG2+58/ufZwE4y9fu+HPu8ltuvycuPv6Fl1+HyCF+8PPmu5/UT29Qe+CpgDbxjXcfeWz8nEVrwAnMMmDwxeChdoQw428zF4Mr0J+iwPAXJ7w5a8FqCBUEKuOf/5/BYITh70z5DCa66daxgsBfMmIU1EFqThwMhLMQWdGx88KpnL1wzc233fXeh1/BmQXPX3zzM/g8qcDU9z30+O+zloBPGDV38VqYBeY66UBqcJoIMKc5/sIczosGS1RaXHKrxHqdkup3OY9SJz4pqfUrK6r279l9cO9uxefISLS3aVxfL7CBQKCyqqqktARGQfqCQYTHiknHJMVbzRZeNGIJ+z2Sq9xZXlBWciDnoE+qI52AEU63pIXk0O6q/eDHzJuG1utbEXC8tfHjb3b/8sOeP77Y+YNNtHhlnzPMAmUkeSUvC8PAGqF4Y4yWPoGkS7iJtMwI1Eib+Ga8lufTOqENepNo4BgWY9wxtdW4Prc3j2/IYgiZsAzuUq/NI31vS41KAkuBYy9u0SfGGMUyTPeM9mad6ZZuI2/pMeq+vtfHW+zNEzPiLNECy13eYVC0yQr2Op4HVgUVEI5h6sUkYAxVEm20XNZ54FXdh+l5Edo1NhCJ1jz0lBqd8OSIO/o172zSGcJ6lGCNuarLsBt6jIwMtOpMfZp0xgjHmGxj+1x9WZsB9/a5rmeDDjCLjte1Tz380SijCFvDnLZgQvIdJXtLs0gNLAg1iW3QPE5LgqZHp97V5boMWxrW5iOt45vd0eEaYFQ8yw7K6BVj0HJv3VI6mHgj9DexN7CKZgj2oox+aWaNprewN365++MvdB93ScYAjLBKlIAcAgMw1krAX6uFH4fqBd6SVHPSo+3v6pPSzSRobsHSKpj6pXV7oMOt0Tor5FlvaDXqkob9oR4eiQyC2CW57WM97moWq8UcUaZaEh/pcUef9C4mUXMCs0Pi9q6u1/dO74wxBhuMce/0Tvf3uqF5fAM4rYA5eO5Sv81D/W5OtR3OdEqK4gp4q1+N1UFWP4GTGtHM/GAWAD8aqhB0TV+4EqhJvxGkO/TVUY5l4ZWj2RMUZYClCYSQKo8z7CQ87JAfSAemREWigtlJZslBT8gXsThpqRLkkEhQRnoWJ1gMjVLi61v4+gacqkNwFAZQoR85JdTCQnRKsModrAqoQYaFaaD374nH4yktKWJZtknTZvGJ2l/KUX7i4uMBf+B2G9avrt21dfOGTz96b9nihbWVZ6TerXuvFyZM6tCp297duz77+L3ZM3/T6/S33H7vvQ88GvEPFWga9IZFC2Z/+dmHW7dsaty42eNPvwQDIwZ/o7xs1JjnXn4d/OzcsRV8rlm1Arak+/QddAJXjz35/Nh7HoqKti9dvODjD95et2ZFckrqfQ8+3qffgMioU/EJMcNiO3XpnpebM/XrT+fOmZGcnHrpZaM5rvq9a8TVUaVOZxhzzY1+v+/Lzz5YOH8Wx/PXXH/z62992L5jl4XzZ4Of3NyDnTp3e2jcUzUDTxG0Zs1bXzz88u3btnzx6QfLlix0VFV06NTlmRf+17FTV1DC6Zj5x/RQKHjrHfc9/Oj4GucnqLRp1+G5lyb27juguKjg268++fXnHxxVlYOHXvL40xrL//rLj19+/onffvkhFJIWLZgLdZApk98Ahx1OYV5AadToa+qnZ8yb88d333y2desmGHhSeWL8SzAqGAzAWmBU1oH9gP+jTz5XP/0IWnxSP9TgryLwb+N5GLO2mPTYxFYmayLHGzAwj78Kydm39wVCWdnZlRVlAkMapyV3bN4oNdYa8DrLy0sCAV9JcUl5RXlxUZHb5WTUkFkH6T2FYUKEC7oC5a5AhU/1egJur+TTW8N3oSMDhoSHTTR7FX+ExqWZk+IMsZtKt5X5KyOGZb4qR9DtCLiCqhTRIAQ3dRB06MAI4+o6PIMgzDIshkpEoC9SwSjVmjiy5VAcwRmUCB6a6EXdZa0GArWKMdjr2TVCA4NkVeFZNspoQwgbdXpIz5R7HAgOjKwGc317ClShgrSZoIq0ilbXHCIoEGpdr0nbjGYIjnATniN6FH6yGcxX9xxm1Bm0ljYQaQdUMG6amHFxmz4swwCBVuCuXj0c9WjYMcEai8IDEEJOvxtj3Dq5ybj+t97WbTRowoJToxJeHPrQxGGP39P9+mRLPCjtBps2CGog4A1Ea2Mo4kwxSZYESH8mW4F2YOgHkgQ5QahUC0YcwyaZ44AZd0xoAzMihFvYmwIX9CvBj3Z8/fnu71cUrqsMhsFB2lEZcKwp3jT9wOyJG6dsK98FmTy9oNc6Ig9tEnjgWEN0miXFrotOC5NICCbSj6CGscDyVzS/KFpvQwgBE726zQjtmw3aOFAgMInIwIY94s1A9xEQ2Uta9D/cgcEUwWEUDUNb9BE4Fuq1JNwbLpDmCB330PyAHcgRJuVuB5wdTYVR/xZdm6c0iLfZL2rbi2VgIqy51AZq/dnlBTUcy+n3aCqEmiY0YNnIBQ0DId9VfIDAU6TvZGVQJr9vOVhRXt7apA5OxDfXZ+5OR/dmoFvrayM/y0HvHEBTsslnmdKM3UWL9+SuzCzZXQLzQmCawd977Nq5IxAIWCzW1q2P/rAdbNrqdDpwW1VVFQqGoHIO5Lobb7dHx0z77ot7x94IbOPVl5995YWngBz07jewdZt2ffoNGHrxiLLSoscfuffFZ5/49KN3H77v9h+++zIqKur6m++EVM3fiBBGQTJJr9ODn3vH3gQ+n3nyoRfGP+pwOE7gbfnShXNm/XHvnTc+9/QjX3/xyWMP3zN31h8ms6VDR+2r66fo8/IrxsTExC2YN+uW66/44L23YLEQQE5ONsNEXkJ1z8/z3KYN62BqwOf58Y8BWWEZ1my2TnjxafAAfp558sHCgjwgLsD2wMWpg2Y2W378/utHHxwLlO7Vl5/ZuH7t8EtHxcbFAyEDnGG61/73/E3XjjqQubd7rz6nkgPbunkj8OAP33sTFvjR+++8+frLcDZLS4ubt2zVrHlL8D9n1owIzj6fB+ogq1cuhZhPZV6W5YEggsPIqt+eNAEGnlhGj7mue8/ee3bvgFcXrAWwuuu26wB/wOrm2+4+8Vjae5oInOg1fZquz/1wncEak9jCYDq053XuIzi1GWfOmbt2/bq4GHvvHt3aNW9s4Qlk9eSgX1UUhmVlRT6Qmbljx87CggKRx7ExZgYFZcWjwnat4nYFK4srD7qCRQabEpdqOHZCFnE8Fjwhr6xqX7+IMwCJIfmeohpL2LFViBSQg2r4GwACI1oEqyPoCimwO4bKfBXh3En1bZTAnVKrwiN8C4bniCOCPAGfopLeDToJLAdDoHvqxt8fnzFx0X5IP4Adgc3cKL3VZrTouHAGDqGDFQWwOjAOi1YUOcucATfSzFGaXfv6BYR3OFUDTlWSVZIbkiXNJjx167QmgpbzCzeggLFQhrubpTSA7KDmF5Qgmh5a4EVrtE1tBtvEroB3Z8HesHl1d8103qBvU/6uaIP18laDEiyAW8TgcMkyTHp0yiXNBwgcH2uMPuwE3INobZgLgR/YNLSKZiNngOlhfJXfEVRr3a01Y6RjdRzLGnntdg5mBk5nELR6SJF2Vez/LWvO5rLtMDYim8u3/3zgz1VF68v8FRzijJrnSI9WVgUccw8uKfWW76/MPujMLfGVL81bU+6r2lGyd/qeOfMOLCv1lEeWCRv6TWIyYEyz2EZxRnskZGgG5ZAvGNCaCOkFHYDAs2zXem0xxtAbFgLrUtTqbx7EmaN1nBZtuCtShFcVLiLt45aaDTxAjjDJLSvMLsnTVATpRfGWfiMfHX5LRlwqgKMJQVUeB8QJBtlleXuKsqBCiHqgNBcqRkHfErb+q12S3IrCnIoC0J+ipMRF472r965bcSC3sCqoZvs0JAQGCVir+BXkU4jbL5Xl5/r8QcKJSnEW2jgrOcZyiv7rNNu5fWtuzkGEcHpGg4yGjVFdhywF61KfeV3/gUPSGzTMz8/95stPa7yvXrX8fy89/cL4x7Zt3QwsymA0L1+6CBJvNQZAILKzD9RPz+javWeN8tQrMCopOeVg9oGjJl23dsUJnEBUr778DIyqsQE2rKpEEAXQnIpPIDrpDRqXl5f++vMPMCQi4HDFssWhkBRp1llKkgxmPp/2iRcwKC0plmQpLzcbQoImSG5OTnFRod5gsMfEQPPUQSsoyAMwYUhEIMIWrdpWlMMMhUMvHh6R3n37Fxbk22xRzWp9IztiX2c5ZfKkH777qqYLTlzA7+dY3mA01iiPqpz6vOvWrqhZ9VFO6mx27Kx92mTB3JmlJdqGVcTmlx+nlpWVRKhnRHNhlP+2KP49PA9j1myrxx9Kcvi9lRUle4tzNxQeXHsepc7Xy97MPY0aN+jQvm3D9FQey57KEsnrlINBRSEMx2KGcTgckGwPeD0Ci0SWREUZWE5mGElR/T7JKWO32UZS0iyJScf5c8VIYHmMMKo+aipa2ywaLbzFHfLCPhq0k80Jdr0t25FHgNIhpGolRtV3d5zvKslxwP0SI4ThnyYofGAEm2IMZuz6aKQZY9BCEijWbNcSXQiaWEVAJFVQhlvQj4pcpdpTTRsjb8hX4a6KKHS8dpkuczuQ5hAMMZCmz5b88v78H6bMneoPVd/wLAYjz3AB6RBtgqnAFmlPsGmLtAqGIrM099lf3n11xsdlmn+MgL6IumiTFZa5YPfq3Moa4otR9XRozp7lJa5ymBQiRxhGgMATDtcxNBDUDhmH66j6wGhD4fYJS6dMWvnJN1t/eXf9lyWe8pAqyxrVjgysNqx+OqwDd0xYiTmGEzAfrlcX2gYuWIZFq1erEey5ryveEm6F+xCK0tli9NFf7vzxo61THUG3oipLc1evyFubaksa2XTo4Aa9LTozgqm0MdgsaC+bVCuwaowwAsmqyHt58bsvLHpnTa7m1h3wVHgdQONiw1k9MEAIzdq97Pk5kycu+KjMUwXN/MqSgByASi0BXyhijE58aIbwADnCLihJv6xZAFm9I5xoVvDAoCx0lIENjIHyi2W/PP/ru89On7yvGKgSSoqKj4NoMXSC4L2l2f6/wpA4josxCFzu9ux1SzbvyynwqdtcyC1rJA9gA7JHgn5/cQ68okW9gcnZqtu/MopHHMvBZKcj27dt8XrceoO+Tdv2dfrheLFO/RlXJial6ERdZUW57xCJiUyxft1q4PjFs5YAABAASURBVAdQj0+IV1UZrktQry25OQdhIAyvrTzFOoyCsS6X86hJTzq8XYdOz7746s9/zF+wbMPytTsinzOLjDoVn4lJyUajKeD3R5YWGXg2yr8NWiTCpOS0p56dMP75V2sE6DjDcLYo+6lEazAYr7rmxo8+/27WgtWLwx9/rH+yHdIzMm+dscXGJQLgRUU1F17NaveuHeVlpXAuYF6tTR9nBwHm7Lg9D16t9jT+EMmrKsusKtsf9DtU7UZ7HoI58ZSt2jRu275JXIKFqIFgwBPy+hiFyJIkq7KiqgzP6vSiiRejeL1db0iOs9ssRo5DRgFbjHxUlD4pPiYlLiEhys7JR9CCyKQKkiU1pGNFntU2lfI9RQSprezNWKw1WYbtmdxZz4sVAW0bV8+JfdK6lPnKd5drH+YDDyXeMgR3N43tQYtISnB94VZNoymrn6EDWoWuEkgR6SEdpRkTjPDARj3G9b21TXJTzY6QbQV7yz1VASmcJQonWiAqq84MqRfNACEDrwdyI0K2D3pBNL+oyFkKbsNVIsmyN6h9xMob9IeUUFiJfAG/TBSnzx1pQiSahB/uALzPBkcEPOwtzPYF/UAadubvh2a1cfgpIIVKXLDMcAMGhuMnRPUGtLkqvc5v1/+2twSGA7Os9gYeCCHOgHNL4c7pO+ZAflElGhuMuChwlMzYs6DS7yx2l20t3lPu1ZiQL+T3aUwIPKB4Y6xFNGOMo4BvwRhNh5xBt8AIZtEMijAgYW24cbgAXVjiDTGHlQgtL1z3za6fy7W9eOjWRneIb/VY57v6pGpf72AxM7zhoMuaDLUKEedIxwmwhLAHIqla4jakQN4CgNLGOgLOgBxSVGXWnkWfrvtx0rJPStzlKiEKpHjBfRifMnc5IFDld32+5qcPV3z37YbfQ7KWMA77jBRgqnkLN8L1cK2OIuywxrS2QYmj4s0ZX36//M+c0iIF3iZAn+YJHkSW5c0Hd4MiIiohnqCvhsw1jEvDuNqlPxjYVrAnYnaKJYMRz3M2XuGL9+evW7xlX3aBV9nvIZUSUhRV9roDFcVEVQS9Ae1fa8jfbiV+2LaGUdX+j3jCQjixVKPDGCKraR1Ryc/N2bdvD0yRkJhktVlr+kpLigJBePkhe0zMUd5qbP6zlVtuv3viG1P69h8KvGHFsiWzZ/4+b86ME+fh/nFYBYMh2N7Zt3d3z84tjpL+PdvCBvdJVwSU7p33P7v7/nHJKWn79uxctHDuT9O+yc/LOfHA05/3xP5p73lB4F/C83jRULNdW1WW6fdWnBc0T3FSUQh6gyV+qcobdDlcTpYXVZUlBIdk2eFxAodQVNUgiDEWa4zVZoT8AcfCTRqDESIcw+h5vUkwGVhjUbbG1Y6aNChL5f4qE2+KEm3QlevJ2+/I7pTQdmzr665oNOyh9rc1jKpf6q3smtShb1r3se1uyLDWm31giQM2T8EaIYffBbd8dOjOpBCyv+JgqYYnRhhVi3Y/JZkVBwNKoCzSpXUgH1A6rYKL3WXTt83/Y/s8RVXKvQ64S6PwcU3n4Q8MvEkAzqGZoas6D3vh0vuTo+K1FkZa4g2hgsqSUlf16YP92Ss6D+2Y0WJUlyFWQzVlKXKUhSRJJTVeEQwvcWhQ5Go/theOEuPODVon2mIhw9cytQkKL0dWgDVqKajOGa07pbdG1QcO92KMmYua94H9SlBnVxR8smraF+t+guVDEyGcVZkzfs4bL82f8u3G38s82lxl3kqEUeQAPhchT5FmpPRJ/nxXIQobGQXjuC5jn+/5UPeUTggOjPxSoNBbHFJhv9wJijqlPFiNA/TWM6UmGeP1nA7qIDH66CRT/M/7/vx+z28aWdMigQceUL9nnMFu5PVN7eHvW2A0L2vpxFXv5zmLEQYDGIpKYQ8X9tCrChDC8A+kXVKLixr37V6vw+N977qt85VP9L0r2RIfkAJF7lLo1cwQHtFqYNf0tsNb9n984B1je15za7fRIscjhGx68+gOF70w/P5beoQ/zohBhwRWuKnXyJEdB5l1Jq0NZgbz6M5DXhh57y19RiEtErDDAs/f1H/kyC4DzXotxRixhJO7MWv3u3O+feaHd9ZlbkdgqD3wrvwDkESM2BxVGgRd4/jwTwdrxmhvaVaZu/Iom5M2gbQJHG9mQmJ5duG6Rdv2ZR90BbM9pNjhDjgriCILOj3Zu9pYsteseHmWA/ujfPr9ftAYDYb0jOovj0MzPjHJFqUROJ8X3oSA4mjZsW1LVWWFIPCpqeElhPtDwRDs2cFrPCoqqkOnrmFdddGmXcfb7ry3d78B1e0z9FRUmB8IBqLtMZAEqu3ykhEjLwv/nnNJcQlkkhISqz9rW2OTVq8+DIThNZpTr8AoGGuxWI+a9AQe0urVGzh4mKKok9/633VjRjw/ftyEF58uLIAXc/WgU/FZVFjg9Xp0en2Lltp/8FM98iw8/W3Q8nKzIMKoKHuHTtp2598I7aJhIxo0bLppw9orLxvy4L23vfTcE++88Sq8WTqxq9Of93j+y0qLAPDERNhGOGwC28QxsXGwUjgjh7W0dqYR+JfwPP2hbIffW3mBkzw4g+6qChlXFFUcqHSXugPegMr6ZSaoIrfPk1NQUFpRAQkJCTKRcFnVGfySWuXwsLxOVhhEBBZDbk/P8TpO0O3YWvebs32ObJZh2sW2xAgD7ft+7+/bynalW9O6JLYr8ZZP2fzVrOwFRk5/SYP+QTn45vqPt5cdTn5UBRwl7jKglRAniDPgqvBVbSncFaZ2WgFKkNyqwnxnkaQo6/K2EqRGOsq9Vd9s/HXS4k/n7F5e5CqRw5/lKnKUag5hTEQ0egYPkMigsJYgWZEzwx+0AkDWHtgW1oIBSY6Ou6r7xc2S0yHvBsqQLK3fv50Q4vK6A7U25srD9/WDZYW55bAvQMA41mx75OKbHxh6Q4zJGlnOroLM/MpiyCb2bNgeDMBbWMA4HAxCsebojmmtwkqtANoarDWFpqr1cPrdNU4AJQisVqdWVYi6Km+DrGrJM2izmDEKBqhoQtD+quwyX5iLVE+OZFUJEcixaf2RR6m/HMhipB5riH643Z0vdX2sTUxzI2e4sdkVA9J6jW1z/ahGw+AshyMBR7CWiPmhEnQIcTj8/QRgDWF1siUBnvdXZuU6CrWBBGGM+zfoNrLFEAAHuvSCDli1Fv/BTRAVaECi9JYrWg/t3SDMUxFgFSVyAs+yo9oN7VK/jVHUw9kCM82h9oQgcdu9QftRHbT/I04z6zSkS8M2Rp1BOxcELOChRWvVm7o3bjeq8yCeY0ELAjZXdB38zBVjX7n6wc4NW4UdkjJX5Z+bFyvwRwEWx4hZb7LDWQY9uCRow8EdSvi1B4q/JAxGAsebGFksO5C/dsHu/dkHKj2VvqAqKxxRcOZ6Q+EOk+znAU5ch+PCgjzIKun0um49erYO78NmNGw8YOAQk8mqKGpxMZD+OkZVVVbu3bNLkmSDUc+Gc/ARox3bt3ncbtC0a99p8EWXAAMD6TdgcPeevYwmY0aDhsAgI5ZnpFy0YG72gcyUlLTrb7qtxiHkhMZcc+Ntd9zbq0//1SuXej0uqNTmRtdcfwvwvIPZWWtWaZ+oAxoBf5vAWWFgxAkYN2t++G8qoqwpYVRhQT4YHzVp02Yta2yOqsTGJej1BpezatOGNZEu4IgtW7XheS7SPBWfsF2YfWBfTEzc5VdcFRkF5VF+QHP6ciqg1TlLbk7O7l3bo+124Nm1DZ5+bsI3P/x+KuTPaotiGJy5f2/Nnvhlo8bYY07y4fXTn7d2tLXra9eshNfGwCHD4uLja/RDLh5ht8ft2rEdzkiNklbOOALMGfd4XhzqDNo7Zpja56nZj4PWBSoH9xRyfKAQdohKsqu8jlJXRaXfU1xZnl9cdLAgt8Lt8ElBh89T5nCUVXl278+btWD55m17Kyq8VVU+l9PjcDgqqipy8vJWLYMd1TrWeMB5sNRX3i6mVZJR+4tyhzxf7/553LKXHl328je7f4HmjvJ9Ty2fOG7xy+9v/hqYX20Xfjm4qXgH3Pkjyhyn9kZ5XcGWUsjbwb0NRLufk7mZy/xhDrSrJHP+PrjEax1pUYnXd7x8XL/bbuo8CsRuigInnpBv3u4VJHy7hibSDHE15dDqmg6U67O351cCRdOaK/ZtWp2pfVAMYYwwaOCBoQJOZm5aml9VCqoqr6ukKsyTMII93IKwErZ3f1k7t8rrBmMEY8EOBCoY51UW/bF5ERAFq94MgjB0aJJZllvudWg1eGAUHaELUEeoyluV54CQcI1xWF1dFHpKIghAG3ZgoTxWsh35szOXVOtx9TM8lfkr/zywAIIBFl7uj8yO3ZLXE9Q2jsEgIoD5ooKVkXpN2SSqgURCFX5taxiUkDmDMhwhTIC3lu0s91V6Jf+eisyIfnBGn0e63ZlkTkSAg6ZC6VFpwGa8If+0nTO02WFcWI+gAoLQ/vKD2RXa9yGyK/N/3jobYA/3YwQecLiK0Mqsze6gD2OGYzmkKeEBgsJ1pB3QwkgURIwZEK6GwVQ7CXdDoZlWm4WrqF5sYtcmbYBoYsQgODDKqyj5ZNFPlV4XtOoUFsMdrdo4uyI3Oxx8nZYnVTIYqB5nE7C+ZF/+ppUHMrOcfolVglzBbl32eisj85BRPxT2Ud62bdlUkJ+jqsRqtfUbMOiBRx4ffunlsXHanTU/L2/DutVH2dc0N6xbc2w+A7Z0169bDVuTwGCaNW9x/U23grRu204QBFBuXL+u5K//fl7NjHVWvv3qk6qqqjHX3Pzeh1/dfNtdT4x/8b0PvwTmN+P3n5cvXbR61fI///glLi5h4hvvPfviq7fded+b735y+533uZyub774yOfzgs+tmzcePHggITHlhVcmRTy8Ound6Gg7rvnzR0hVVJZlmjZvCQYxsTHg0x/wX3XNTTAX+ATPUImLTyTkqE8FgHtNNq5fW1iQl5CY/NSzE8ADBPn1D7+lZzQEoqx1IwSRnIrPX3+eVl5eOnDwxZ9/8/Nd9z702JPPfzn1lybNWtb4iXg7zXL1KYBWe4ra9S8/+yg7K7P/wIsgwjvvfuDhR8d/O23GkIuGwwLLSotrW0bqtYGFrOe+vfDmITR02KUAEQAFqN5x14OKfMQ7ycrKMkWRuvfoc+8Dj4IZnCxw9VfnhSF1iqLIcN4bNmoCpxXo/vSffli6eAEw+Pc+/ArQBsw/+PTby0aOyc3J+uLT9yMeai8hoqHlGUGAOSNezrsT9tB+lhR0n/dgTiWArWv28waluCpvT+7uXTl7Nu7ZsmPfzsLSEobnZXjXwzIOtyuvuOhAbtHerOKD+ZUrV27dum3fnl1Z+/Zm5+UVFJUWzP5j1fEmckuehXnL9Lzu6iaXReuqGfDxjI/VbyrevqV4J0Sxq2z/lqKdYOAIuL/Y9FNuVRFcrkvd5R+unbqvLBv0IEBW5u9fOXn5l7tKMhVIomgMjpS6K37ZOqehthZGAAAQAElEQVQ8/IF9sNleuO+j5T8UO4GCE0VRlu1f99wfk3/dNN8b0GiNPxSYsXnRb5sWasPBGiHwOX39/A8Wfr+3MAvskZYCUnfnZ02e9e3KvZshMLDyh4Lzt68KBINgsHD72qrq/wgBFVSVvjHz88U713n82o0HLIsdZT+s+fODRVMdkIFDqMRdsTl3FywkEApOXTPj42U/vL3oyxWZGwhRIUW3MnMjDIlISFHm7F7qDLiIqu4o2h9SqjNzkd4Sd/n8zOUEqZDF3FKooRTR1y4JIcty136w4evw11wg64k8Qe/inNXvbPisMlC9Xbu6cKNT++aEvKJwrVfWAKnxQBBZWrD6sz3fF/s1agsxZzlzFuevgki+3Tv9z6z5lUFwAokxBCBkO3I/2/79r/vmKkQFmZE5/7c9c5yB6j+HSr9jec7acl+VQhTIMkayj7CEt1d99ueeRbBwbVKCKr3O37bP/WL9jxEKC/FvyNv++uKP1+duVVQFzgNRSXZF/gfLpy7dvxZ6wc+CPSsKqkrgHIWluoh4K6gsnbV1KdiALNi5CpphPSwLYg4LFNpOfemszUtDUvUdqLCydFfuAc0SoVJn5Q8rZ30wf2qlB1Ya0dVRlrgqVmdpbwyKHGW/bJofPOSqDtOwCiIPP9ddMBhxHGc364SiXYXb15Rl7mTyduqy1kTpWGCr0Fv3sLB2zqwZG9avcTodiqKtTVWJ1+PdvnXLrD+nh4LVHzANGx5d7NyxDdjbUdrtWzf/9uvP2VkHgsGg9oeFEOQLcw7mwCzQdZQxNE+8LjA4sQApeebJhzauX92kWfNb77j3omGX+QP+j95/+6P334kMhMr7707yeNxAPm66dWybtu337ds98ZVnYGDEAMrJb74KCKSl1QcPAwZdtGnDWmBdUi16MXPGrwezD3Tp2mP4paOjomN++2XaC+MfBT9ABcBnrz4Ddu3c/vv0HyA1CN7qlPfffWPzxnVNmmhBwhQ7t2355MPJsnwY3lPxCTE/99S49WtXpabVu/aG2y4admlVVeXnH78XCmkf7ahz3r+nPBXQ6vQMKD0//tG1q1ckp6Red+PtkHqMtscsmDcTzhFk3Y4dchSwwKu++vwjWZKGDR950613QSbv/cmTDmTuqz0QbObPmak3GK669qYhQ4dHuv7qvJFRx5YL58/avm1zo8bNrhhzbVKy9ptZLz//5NSvPxMEcdiIkddcf2tGg0aA/+v/ewFmjAyvvYSIhpZnBIF/Cc+DhEEEDhXuRpHahV2uWZDlcvgEAw4xvqpAWWbB/pzCvP3ZWZVul8Vua9C4UYOmTaLjYiC3oHKMpKIql7+0xON2ElUyBkN8brZjyWztxna8VW4p370kf3WCIe7htne2j2vFhr+EUWOMMQb+N6LhwEsaDIR6jT5SgZTet9t+fXT+hM83/wj1iLLMWzl5zRfjZk94bfnHBypyI8pICXeXXEfh5+t+evzPieP+eHXc76++tujjbYV7QV9jkFmWM2nBZ+N+mfj4r6//sXWRL+RfeWDTc3+8O+7Hic/89s7SfeuVI08cjD1QkvfJ4p8f//6Ncd++/ui3kz5b/EtexRHvYvfkZ43/YfLj3765am81+YtMFwiFZm5e8vz0KeO+ew1k0qzPN2TvDMnV6QGY6JeN88b9NHH8729vztulEgKE77etCx6d/tpLs6bkOY6YApovzZ3y6IyJy7LWQ0gR/5ESmsuy1z0669VXl35Q5AYKG1EfXYLZgarcKRu+enThhHELX35+xVszDywMyNpH7COmee7Cl9a8/fjyCasL6/itUeBEuyv3T9r84biVL4K8v/2rMr/2ob2QIsH5nbB28rilL4HA8ClbvtpdnqkSjU2CZ+CCKwo2vLTinXELXh43/+UJK977fe/8V1e8//j8V7eX7AWDiASk4JKsNS8tfnfcrAkgExZPWZFT/R9+RAygLHVXTts86/EZr8GZffT3iVOWfXugPA/WBV0gB8ry3lr4xbifJwKk1fLjRDitIG/N+yKvshpPOJtvzflynHZGXh839XU4p9Xyzetvzfwqr7zaDBw6vO7PF08f9/Xr4755/bU/PtuQdfjcQW+dAud05tYlMOMb8z4vcZbXaVNbCfa1m8fWIWHHMqzdZDAU7mbW/yFmAskTQAP6Y41ra4DMrV6x7MtPP3rv7dfeeWPiu2+9BtXFC+eCvsbs159/gK5vv/y0RgMVeA/30fuTQf/Bu2/t2XX4bQMk7f749ecP33t78psTw71v/vbLDzkHq99lwcDactJ1ffrRu/17tn315Wdrj6pd37lj66MP3TWoT6eenVv06dZ69KWDf/ju8A9zgOVP06ZeNerivt3bgMGAXh3uvOUa2I8DfY0czD7w8H239+vZDgzAz3PjHwWiM7hvZ5g6YgNT3HjN5b26tBw5vD/k/0AJHsBPzZDHHr4bhgzp16VmCNjUFvDw4L231djDFH/+MR2mqL2uU/EJfmoWC94ghp+mfTu0f9fafmrPC3pAr3ZUQLhh3gfuubW2GTRBCV01yp9OCNrG9Wsvv6TfdWNG1NjXVABMQAOgALhALh7Y7cVnn6j9uyQ1llCB5RwF7LdffXrZsH4wEE7l1VdcDIQbYoO5YEawj8hr/3seThOcLEDgiXH3RZQnnhcQABwAjYjx8Uogo/fffQtMDZDOnzszYvbJh5MhJFBCVLAuwB/CjnRBCfWaJUCTyplCgDlTjqifv4rAnJ928Do2KtYYFW9ITo+JijebbQaDWWe0GGIS7E2aN2rZtllG07SkjDiL3SjoRJ3e6vexlRWyx4Xn/3Y47VTnvApRZuUs/O3AHJ7jr2ly2cReTz/b9aGbmo++qumIxzrd/WqvJ5/qdl/v1K5JpniRFer0QJUUgX8rAlLocO7nBGtkWcZuNSXarVFmA9RPYHmBdJ3iui6QaGkYFAGKwNlB4GivlOcdjcg5axfnun75ZB3HKrFxhtR60U1apHTo2qxFm3rRcQIj+qLjuPTG8c3a1G/RLqNBy5SYVLPKBxk9qnBVzflpUXlR9cezThAtpHZWFK17ce2bvx+Ym+MqMPKGlrHNOsa3settJb6yhQdXTlz3/ifbvqudWzqBN9pFEfjXIBAKBWvvJB53XYRAtptlGAZj2LM+rtmF0QErgnVdGLHQKCgCFIELCAHK887nycjZX/nTRxvdFX6DjpgtTFySMTHZbI3mBDFkjeLssTp7nNFkEfRmrDMRwaDIkm/3qh2VxScneTWr8kr+5YXr3t3y2ePLXxm39MVxS196fNmENzd8Mjt7MWzF1uy+1djTCkXgv4CA3+cFYvSvWSmsBVb095dDR1IEKAL/XgQozzvP57Yk3/PFG2vWLMzRcfq4WHtSUnx6elrjxg2SkhLs9ii7zWI16G06g4U35m7JXzB1SVVJ5OuZ5zlsOj1F4B+NALzD8Xk9fr9PVmSo/0PXApFD/LAKWAvU/6GroGFTBCgCZxUByvPOKryn6nz53P2vPfn7b9+s3rO9IOBVeF4gCBl0em+F58C2rLVztvz68bwda4/4qtSpuj47dtQrReBfgABsdHo9bpfL4XRW/RMFIof4YRX/gnNBl0ARoAicJQQozztLwP4dt1vXH/jpiyVvPDf1mfunvPLoRy+Nm/LF5B/XLNiUm1n4d9zRMRQBigBFgCJAEThXCNB5LkwEKM+7MM8LjYoiQBGgCFAEKAIUAYrA6SJAed7pIkjHUwQoAn8XATqOIkARoAhQBM4uApTnnV18qXeKAEWAIkARoAhQBCgC5wuBfxrPOw5OhQfXRuQ4/VRNEaAIUAQoAhQBigBF4D+HwL+E5/3nzhtdMEWAIkARoAhEEKAlRYAicHwEKM87Pja0hyJAEaAIUAQoAhQBisA/GQHK8/7JZ4/G/ncRoOMoAhQBigBFgCLwX0CA8rz/wlmma6QIUAQoAhQBigBF4EQI/Fv7KM/7t55Zui6KAEXgn4IADh8Mw2CG5Xl9FGdNZgzRiOH+KQugcVIEKAIXLAL/PJ6nQ2xHZL8lps0r9t4fVjT7qbT1bLnLIrbH0qrOy3M6LCjs8HNl23c9rZ7FbW9gG3RUo3Xkn7fGC/blQgOjCFAEaiFwWlWMEcOLojU2ul7zJp0H9Rp+wyW3Pnb3/z546+sf3/p86jOvv5fQoBXwPkQPigBFgCJwGgj8YzhQPBHHhFLeFnvOdHZ7q6z5bZkJvXaxTf3RcVy8FcUKSjSy24ndJnCW+EBUG6f1olD83XL6G1VN5xZ1nFzZ5Fo1JUEVTgMoOpQiQBGgCJwZBDDL8DqDNbFh50tuePjFtyZN+eTNKVNe/d8LY+8e27ZrL68xZm+Ab9muQ/uBI1hjFMJnZlLqhSJAEfhvIvAP4Hk9cfxLvpY/uDrf60/rUCiJvgCr41SCkSQzHMZWloiE9QT18Qm2S7oJzeNU5GCQRy6uDOaWM74AI6vtfKax+fHT8lq+5M7orsaezzNN56YIUAT+qwhgjFmON5htSQ3aDLzyzv+9+8n7r71w/fD+ttjY1fnuT1btn7pm309L1y9ct62yylEekJt26mpv0Y2wIjq1g7cZYka1q//yiJNK8riBtv5NED0oAhSB/wACFzTP6y3HTPG0faG4WU8+mYmN4uPtKsOoGMtmndrAHLIQ1aQztG2q79ZajjZLxRVVC9f6srIIFyJqCKsSi1QGKYghhGGAFhKO6W9r/E7SiI/VXr2lmP/AyaVLpAicHwT0ekNUdExcQmJ8QnKNxCUkx8QlOr1SUbm33KVUuNUKd6jCHSxzeosqSgvKSvJLSp3eYExsAlgmJCaD1Iw975W4hERYEazrbwKqMTzBGJXQuG2PkTfd/9LESc8/fn+Ptk2B+QVUZNAJTROsg1qktU21N01LtOgFVZGLKhwpCXHteg8UY9MJZk9l3rjbupvapZ6KJW8zAM8DQfS4EBCgMVAEziYCFyjPa2qMfVPo+j9/y9aSkec5gRDi9nvkII6LVXizQlilxCXIDK7w+xZudf+xXMk+qBQV4nIP45FUGSu8KPMCMVgUgygxEp9kYe080SPF6/ftzGlaZXjZ2fJNf9tGxHg2sT0/vpOatB6/IOuZBVlQOdsR6AzGBz6c/u66okE33num5rLFJT705ZyXF+yt16JdnT4Zlk1r3v7yx157YvqGV1cW/W9l0YSVRU/+vvmK8e/Ua9UJeuscdcEqE5u0fnxe1hPzsqByYQapN1nun/Lj5FV5bftdfNIIgbjYouwWa5QgiBgdcXkhKlFkhePZbt06PvHE/c8//9jzzz//7LPPPPjgNZdeKg4ditPTMYZ3ZopKVFVWVFlWFVVFF8aBEQMrgnXB6mCN6C8dGLOiMa5Zl2G3PvzsSxMevPvWzm2a63Q6lSCeQSKDogVsQPLBMmcgJDdPiYkyCAxRnV6/judi4xMade2HdOaTTmhun8rbDOivHMb2p0QK/4pLaksRoAhccAgccSG+QKK7NpTxUbBbVGqhJgAAEABJREFUFyYlZI8hMTGGpCjJpeJSSSwIkaqQ3mI0WkwcwixieI7lQirjDjGqqnBINXCs3ipy0QwWBJueNYmEYI5gOa9CrfDzPhm7PIYogUeKEgp0dBo/K2l6nTfuvKw6vnHr+2dlPbywaOyPW2zJ6cfGkNC49SNzssbNyUpo0vrY3pNoCCInsTiT3QQmAzmhy+TGLV6dt/PZn1bE18s4gSFQiqufeSe1SZtfJz2Vs3PzUZYY44Ydez46bcXdn8zscun11vhkmDYyu8me0G7olbd/8Md9Xy9Jadb2qIGR5uVPT35uWdGzy4pumjxdNBgjytplr5vGPbWk6MklRbd/sdRgja7pEvTGK16d+vD8vBaDr6hRnsEKLAEWcgKHLMcNe2jC88sK+978MIAgGoy3vjv9peVFL6/Q5JUVRSBAdies0FgvEN++12m0u+/1905cVfRaWF5fVQQyaXURyBuri0DufV8DwRob/+zvG95eUxSRd9YUvbO2aHJY3l1bBAy+Va/Bfo9r6suPVJUUXDf+rfSWdZPvmuCttmhR1NU0IxVYYDAkeXwBjy/IMEyz5oYrroi++uq4G24Yev3114wePahPH0P37nxKKixOcntdLo/T5XY6Xc6qKmfEw4VTwupgjX8lHsxwenvjjt2uvrvP8JHxqakelfFKCtA7kSFBSc6q9C3JLF2VVaoXWKuBX78vb19ecSgYdHr8PCZ2myWjWUtDXD0VtiROOKuYHnPC/jo6eZsBBNGDIkAR+FcjwFxQq7Mx4qve9mO9TXSFklTgYKqcPGaIUTQ3rc+aeAJ7FwSHAqGQL8giRvGGEIE7CMIMgxiEkSQTr5BqNbZM4RPNiqwqfgX4DsY8JxoZRkcIT3jkLS2WxRBiJUXyEVW605/yuqtlNBLPAw4YYYyMMfGdrxzLsNyxAUAvAptjO06qwSe1OJMGkThP7LFxu65mW3R8vQZxaQ1PYNllxDWNOvXatXL+tiUzjzLTuM69z94x+afopPpluZnfP3/Xyxc3f7JH4lM9NXlxcMOpT91cvG9HbL2Gd340s9WASzE+AgXRYLTFp4AOtMktOsamN0NHHnqztVH3gaADA9FkYYXDLwlbYlpSi44cx9Xr0BsMzrhgDOf5RF51ZlvDzn0wxg3a9xT0Bs0UhuDIM4LBOFKPlAiBBoWPsOJQ7XDjkCb8rBXhLs0Jrh5auw4GFUV5Mz9+3WCxjHl0gskaBZo6Ra83AA06tkuSlUAw5PQEXN6Q3qAzGDYR8hwhz+p0OywWbLPZYmJiY2LsdrsoiIEqV35JeU5xWU5eUU7mwZxjvZ13DawRVnqqYXC8IaVpw/4jjWkNN+aUzjtQsSDLsa/c5wopOQ7/kgPlc3cXeoJymt1c5nCv2pNT7vToRFEKhTAikqzajHqdTrDHJ8mEOZUZg9nlFdM3n4qcijdqQxGgCPyDEDheqKd07Tje4DOrb85Ef8j06htMYDEk4ZDRqmcwQt5AYP9B3+6DbLTe0CbR3DReVSXV5ws53AxSGIEwBoxFTFiWlY06v07aU+BZv00tKeN5zApEu2sZ9Pr0FN4eRcxGhTBEYIkcYHQKI6pAE7GEuntjP8dDmyu2M7uck3sjYROCmg+9OqlFh3DjiELjsH8vMxfxfISzs9mA6UBOOMO+zWvcjsqirL0F+3cdzzA2Nb3fNWNlSVr07RQpEKhtBiTvsodf6X31WFmWf57w8FvX9d06/zevs6rGJujz7lo25/3bh85651mIZfRz72d06FXTCxVOEPU2O0AKvSzPZ3Tqi448Yuo3iWvQgsCBkN5iNUYf/r6Ooyi3cOcGRZYzV8w5ctAZap3sLAfcjsx1SyG03Svnhfw+WOxn944c3zMR5OmeiU8D2Q3L+7dfDLk3n8eVtXElRLbkm/ce654YkUe7JYKM65Y4flCT/RuWQ++uVQvBlbOs5MVLOz7YJfHBrokPdNHk/i6JIJ89cRtR1LK8rJrztX35/IM7NqU1b9t+4HAYXqfoIhz0yL5QSIK3Zh06d3zvvVe/+vK9Dz54bdSooRiHvN7iyspJPt90m61+t25f9uv3yd13j5w40TThFfmuseq11yjduio8p6AL8qhzpcdGSuAiZE9N6zUssVlrt8tZXFF1oNSVXeHeXupdmFX5x46CDTllOp5nGLw1p2R3QXkwJLMsI4oCgxHHMiVuX7LdCrQvMa2eyvDH+j9WIzn87k15J5VAVsWxY6mGIkAR+FcicKHwvG5i2hfmy9JKeIVRFD3xG3EwoHCigRH1SLTyUWaB07kPlDn372dkN1NWqvNV6VQXljyKGpJ5Bkx5u5W3WQliGERQUJXdEpJCSFJlp8+xK9NfUoplDyvLOKCocojA9lGI5WSODSEl5LFz6mTboM7SuaV6GKmK7HeWczzf8+bHBf3RO4lH5VT+wusPa/z2L9ifpilGJ52vYN/OJwa3ePmqvpXF+eg4R4choywx8ZmbVubt2XqUSZuBl3a57AYgMR/fM3L9n9+rSt23f9Cv/vnT+R9NYBhm0NgnjbUyTyzwPJNFVeTNf06FeBt17aczWmrP0qBrf5bjDqxZ4Ckv5kS90XZ4Fyzk9/78xLVvDErdt3xW7SFnrI5Pgp8iyzPfeur53kmrfvgQ2F6d88Jyhtz5pM5o/v31x3J3Hb3lHRmCMe522fWQMV0/a9qyHz46nqvohJQR9zwly8Gvnr2v5nwB+Otm/4IR6jp8jN50BHQR51DyQh1cpNLpbteu1UUXJbVvv7VV61UtW65PSMjBOEhIMBjc6vP9qihL7PYmiYndW7e+olevYR06mps2YzIaoNg4hBnwelj69B3w7bTff/ljXm356dfZH3769fBL695Sjwz54ZeZV11742FHCB2lh16wqe0W6t//PPPlV99s3KRZ7YGRep0rjXTVlEDy2OikxC5D67ftGgwGgn4/ZAEZBgeDwcyi8tX78nPLquAUlDg923OLy11eBsPWA8diTGTZajHrdaIkywaDPi05KT45FV7ANZ7PXIV6oghQBP79CBx5HT1P6+0cjH4N9ZScbpZTGBMrmkTBwqmMzBoYBtJ1nCpJfnd5JVKDiuqXOEUyiircURhMsKKLs5jibJDbkxVJJQrmGIJYghiGYYnCwG1Js0IKBh3SEngIsYhV4VqKECaaIISIoDMmpjZ8x9mls//kn3eGAWdGCIKFLfvoJa+zMqVNt2aDRh3lFpJPiMC/o9Sn0Px7o07BcZ0mkTjr7Dp1JVCHZt36gf3uFfOlI5N5tvikwbc+Al2/v/nUwe3rocKwbJtBlz/5++b/rSx6cWF2z6vGWmITHvh26Q2vf8sKwppfPtuzcn5Sk7YZnfqAcURMUbE6s1UOBfavWeQqK45r2CqmfuNIF5SwaZvRqa+qkh3zf6kqygXQdZZzR/oBQAJBnIZgjLuOuglSmJtm/7jjmC3vGsepzdsNvu2RivyceZ++IUtyjb52heO5i+4YF5OSMeezt3OO5It71i33OB31m7er17zuT0BixKBjjiqns33HqE6dHAzzZSDwriR9rKprIJ8Hhm631+lc5fVOVdV1LCuZzb3s9mttti56vUkQGI6DZYHVSQReDLFxCaOvumbIRZecxPQvdgsC36x5y/sffuJYqofrWimqfWCGscUndBrcoGs/WYHXXcBohEUJCF5kqgLEnahwecKBQMDj9cHrTeDYiKiKbDTorRYLpPEQZiv9UsP6ac2bNbHHxtd2f87ruFnL3peMfKxz95E1U9uiEvoMvOmSkY+CfsBFY+ult8G4jhcA2IO+XkbbQRffA5Zg33vAzXEJGQhhdOQBp7JDl0uHj3p80MV36/WWIztpiyJAEfibCNT9Z/k3nf2tYc0l88RgM50gBzxVsuLnRI4gJeD3MToU9LiDlY6Qy4VZojNFiWKUKERhmWcZrBiNAXucbI0O+AN+jwcLTNDnC7jdqqJixLOsDq4hihJECMO1A+pEISSkNZAgI5UnCINPBFQQgb2Cd+e7521QvGUvueOaKXp0bg64ymFUlr1n448fwIQ9bng46sgvZOCwARTQGxFYS8NuA29874+nFxc8s6zoqYV5V0/8JrYWX4mYodpjEIJRfW64/+UVRePn7G3Q6fAnzGLrNRj99NuvLMubuKpowrK8WyZ9E59+mPpEXJls0SMfmfDqkgNvril6c1XBfR//kdGmU6SrpozEmZDe+K63vn1vTcGUdUXjpy1p0rknxrjGJq1Z67eXZ4FApUZZuxKVlJqQ0VgOBnJ2bqqth3rLXkPtKel71y7ZHmYwkHW7fNyrV7/wvjUmwV1RAsm2i+599tJH/hedlOZzVsrBINDErfOnw9wNu/TFGJ7BB9KZbZyoC7idRXu35G5dwwt84+7ap/G0PoQSmrRJaNy6Mnd/3vZ1ktcNAFpikyJdUEKq9Zq3pz+2uKjLNdr3G0DTZsQNjywqum3qGmtC9TcWMcZdrr3/4UVFN3+53BybiA4d9rQGFz/+9iPz8x5fXDRuft7o/31Tm19GrDCGCSNVrYTz1fP6+59bVvT4rL0ZHavP18jxk19YXgSlZnHMI65+4x5j7gx4XSu+/xA4xDH9moLX6Qbe9CAv6pdN+7iyKE9T1fVo2K5754tGl+ZkrpnxPQEGWsvGUVpYfGA3xvik38aoNQgpilNVf1SUn0Kh4lDIHQy6FMUPb64kiezfj/PyfD7fOpfrEVneghALqW2b7VWOy8CYAxt0BDAockiS9NO0qaNGDAa5bsyl0777xuf1Go2m3n0HRAz+dun3+ye/ORHcgjxw9+3r1q5SFSU+Pv4ve8ZIFc3x7ftndO6rEhT0+w2QlzPo4X0nxgjeX7IYcQzDs8BlWYFnRZ7TROBhrxauyHa7Hcx5njMb9QadCJX69erbY+P+9rpOc6CoM7bvfElSaguiHs6jx8Slde11lSAY9u1etWPrfEWWWrUb0qR5j7rmwk1b9GzVdpDf7wLL3TuWCYK+Y9dRqfVaHmWcnNI8PvHoS9BRNrRJEaAI/FUE4KryV4ecSfsoJDzrzCCeALyvR4yisqq3wh3y+DCnEiXEMijo9DKcoioBKeBAio+VA3zIh53uoIJwRn1zu5ZwU1R8EmI5jkOcwGDYF8EcCamYZRidjogEmxEWGcRh3ixwgo6NMvBRdtAo4J9jOJ3ICmyI+GSTn7CyqDLPuFKiVLjHoLN+kOoZts+cWrx3izE6vtORX8jQbrK1MnOi0QIsYcz/vklp1QkzDPQyHNew68DbP56T1rpzta/I0yHP0AJgBt81fuAdT3odlV+Pu/bA+mWgBGnR5+IHvl7S/uIxLMuBKzBr0n3gw98s7nHFLRhjMACxxiXe8+HvPa64WdAZIOUAk2a07nTfB7/1Hn3YBsygq0GbLg9/OqNFjwGI0V5RSelN7p88rVXvwVrvqT2i45NFvcntqHCWFdUeIRqMrftdAlNsmDVNCuf5YA+304jrKgty3ry294QRbdGiw0MAABAASURBVF8Z3mr6/x5q2nMonNzSg/siY4v37/S6HNEJacKhT4yJBhNC2FtVHvJ5dyz6DRxmdOoLaTwUPhr3GIwR3rt8trusyOeqBJ39WPaMwsQDSoR2zvsxa9V8a2K9Tlfdy7DaqyW2YYuOV95DFHXZJy+7Dy2hca+Lb/x0SYuhYwBeGAdlRteBt362uMPlRwNYc8bAZsCd4/vf9qTHUTn10WuzNlSfLzhH4KFOwRh3HHGt0Ra9Ze4vJdl767QBZXqrzs26DwACt3XRDGjWKcAFe4+5DU708p++cFWUHWUT8HmL87JBmdKkFQt/b1A7BWEYyFq5AwE3xxGeRxFhGBQKoRUryMKFZNu2QFlZdl7epNLSWW63xtl8PgZOtSShE6w6MjMwsx9/+CYrKxOaQI8aNjpjLCE/P2fmjN8cjiqGYRKTksH/qQvh9LYWPRt0G8SJOr8POKgRDgYhlsEcg3kW85zG7YDX6QReJwiiyIuiIAo8cHSLxWSxmAWBB4YXZTHxnPbqKi8vd1YUn3oAZ9BSr7f07n+jwWjbs2MJQWqN5/oZ7aG+Yc2v+3avPHhg8+rlP3jcFcmpzXR6+EODnsNitkSl1mtVVpqzatl3YHlg39q1K39U5EB6w/Y8L9bYmcxRjZv39PuqfN7Dn7ut6aWVCxoBGtyFjQBcfM5ngI/7WsSrVsTp4X0+K/BYr1MVIodk2RVSXJLk8vEcIxoEDmNOgDsDi4ICI1qQ0cTqRRQIBEurgr4g5jDLII7heV5kjZwMGTt4y0wYWc/KOkVlZCxi1sCBW9VLzA1aYn0UzKIyalAOCVFWfVwU0cmY8xPEcWxMss/ypK8ROgcHrp7D76pa8+3bhKgtLjriCxkYDDDC1VbaE8dxjqKD3z8yZkL/lJf7JE4e3T5v21pOp+91w0Nwh9YsIg9cPQqUwx6cANuarpLCLx++MnfHhkh/UpOWo556i+W5VT998uzABk/0SHx2QINFX74NOA67d3xq83YRs2Y9BsbVb3hg08pnL271cLfEx/qmz/xggkpUgzWa5diIjVZi1KLnwE3zfn1iUPN7Oyc+NrDZvo0rwdWga+7UGYyaQc0D19SOrsRDKhGjqsLcgNdTu88UFRNbr4G7sjQvvIcItK/z8GsRIrOmvFh6cD9YEkL2rJxfdnAfwOUqLQQNSNDrkgJeW1KaYKi+69hTIUWEQA+Jh4Jdm8rzMuMbtohN1/5LAKMtun77XrIsZa5eAGPLczSyaLBEc+LhmxDoNTkUvxwILP7gOW9FSatLrktt253luE5X3y+aLdtnfZu9ZiEKH3GNWg55TAN50y+fvH1xg4n9Et+6uMHqbzWQ+48dn9i0GmTNFh8+X0MfmNDtqrHO0sKpj1yZv7P6fIENrA7DU10SlZjaqt9wVZa3LfwN0KjLBEGEnYdfjRlm+5KZ7mMIXM2QlEYtm3bp664o3bmqehU1XZFKeZjnWWzRvCBGNCctzUbrju3spk2K202A2wWDKMLhgPDFxeHycm7ePGH6dPWnnzb+8MOM77//4Ycffl68uHzNGvVAJlIU5qT+jzJo37Hzh5998+Ovs+++/6Gjus5Nk7CipWH71kOuMFqsPq/HaNCbTCYGIwZr35jlMAbqJvJA73i9KADJi1A9KBmMGUSirFaDTicKvNVkACVGWJbVtSuWVBbmoPNxSJIfONzKJVP9fnfN/CzLi6LR53V6PdWcLBjw+rzAiTmMjj5lwHT37Fy+b9dyVVFQ+Aj43X6/CzxwXPWrCN6uN2neGy7gu3cslSTYhwnb0YIiQBE4Ewgc/Td5Jnyeqo/rAmn97A3YuGjWbtWZjJaE2KBMeDtsYzAi3EZ4uBhySkANVUmST5HgytIiEbdOZlqm4dRY0W6UKsrcuXlw/0MIS5DSU1U1GJLcIVXFCi/IqiJoP57HKEFVkVXgeWCGEXFl5QeKS3FA4kSBMSBPqdPvlBERYSKCiGBmGY7tJ8beEDq89YbO0gHzHUrjZK9duGPeTxzH96r1hQwtmQE2h2YHjvLz+Fs/uWVA1oZlqqJdMV2lRSu+eUdVSUz9RjqT9ZAhsCAEjgWD8dJHJ3W89HpIfX358FVF+3ZGDDCkf4ZdozNati+cMeu9F0N+H+iDft+Cz9/YMHMaJ+h7XXk70AJQGsAnQfvWL/dUlkMT0mkLv35vwhXd5372hlzr010Q59o/p/385niPU7voQyJtzheTiUqiktJEYzXNguEgYKlFBrW6BHoVGc4FxH64G1JuotHsLC0KuBygtcYlxTdoVlmYmxP+oB5oQORQ0OuoABzcVVqcoAEX4A2oD1GrMxDRKemgcZUVw3q9VeXZG5YzLNes3wgwTmjcxl6vUcn+7UAWoRlwOyFI3mhmGB6a1RI5EeC3uo0cBdlLP3oJY6bv3S+2GXFTo96XVORkrv32bVWRwQRAbn3RNZCC3bt4xpIPq0GGqVd+9cb22dNYUd9p1O0QAFiCQGAEIUFvHDZuUrsR2vmaOu6q4v3V5wsMQCI2UDlWGnbuY45JKDqwsyTruMk8e0p6o859Ad69qxcd66FG037wZSzPH9i6vqqkoEZZu1KSmwVNa3yScChRCs0Ti1EfvXy5fsYf3I4dzP79zL59eN8+nJ+PBQENGcKkp8fs3Nl45symf/6Z+tNP+7/88tNPP31twYK8hQvkbdtZjhVO7Fyv11951fUZGQ3BDJJemfv3NW7SzGaLZlm2cZPmoIwIvAUcPebaX2p9geP+hx+HsZHeOsuUlHrDhl9ms0XJspwdzhfWaXaUkiAc37j1yOtvbdeqacDvE3jOZrOxLGYwYjBmMWEZDPk8gWOgS+Q5EKgIEC7GoaDfajVbzCadwBtEAVgggxmCUFFR4calC5AqofNxwPsfj7uSkOq/o0gIiiI5ncUGo9VoiopoYG/XYIzy+ZyS5GcYpn3n4cMueyQlrQX0ynIw9+C2qsrDeXrMsAzDAZ9TVO2PBWySwzu2udlbKsuP+4kCMKNCEaAI/A0EzhvPa6gabw3U91bBuzoWLueyO+jLqxRUllRKOEBMDe1smiUUlDkdxyAGSzKqqnTvyAzszw0WlIa8AdkfhNBFPc/xLNyCGYFViRwK+BFBGIvIalQFRSp3IbeCFQzXqIArIEuqrChqYTnrczDAk1SCtP1eVvHLagiccYgl/koXqxNCPt+tVfaGsg6d1QPequPqCRRZ3jDtA5+rMrVtt+aDR0W0GCOE4R+qOYI+N3CFmiZUfM4KVQpgqNUWjDhBd9XLn7ceMoooyow3nyzL2V/TrzNZUlu2B+dbF/wG89boob557nRCSFqLdgardvmOfNdy4E0PDLr5gdi0dI7noLeiKA/KmlFQAVclOZkynCNohMXndsjHRoXCazk6VlRzgB9neTEwzhoNVCwxCbxOLwV8Spg/CTo9L4rO0sKjcICxMGOEC8IoYLGi3ugqK4SB0GQ5TmeywsyggSbEv2fFHKDD6e17GaNiGnUfxGB8YO1iYNLQ6ykvgUCt8cmC0QjNasGgQ+EHqjn2Lfl939IZ9vQmfe55CbYYV3x6eMdWNFkSm2sg71l8NMg7F0wH46Tm7fRWDWTwhsPn64qXPm81SDtfc95+srzW+QIDELCB8liBpTXs1Ad6c3ds8ANDPdYirElp0spgtZXnZcG+bVhRR2EwW9Nbd8QI7V2/FF4MdVggpIbPAvzFYgb+ZOo0OVqZW1BQ5VDWrTNNnGh98UXrCy+YXniB//BDVFiITCZx1KiL3n779SlT3nv33Slvv/3qs89ec911plGjmMaNmSibqV5KytHuEKpN2r6d9vuYa643GI1er2f5Uo3C7tu72+GoVBRl397j/oLPsT4jGmB+wP8idPCd9z/p3KU7w7IF+blLFi6IGJy0VBih1/Ax11zUt0ViFI+RPToaMna8hhdmMWIZhmMZXhMWSo5lOVbTsCwjhYKgiYmKMhl0Is8CzwNjhDHBaPmCueW5++DKhi6kI3v/hoDf3bHr5Y2b9ajfoF23XlcJonHPzmXAC08WJm7QqKPJbC8pygwFtTeZkR1br6csc+8aAm9oTjae9lMEKAJ/CQHmL1mfQeOxTGtBFEVF8bk9XJINrmKsRa/wCJsYmVUrs0v9hU4FLoaJVhxjlA0iYQXi5zh4h4yMWGdkGJa4fGqRA7n9DFYZHY90PAFGp6qwOyKYdLyOZzBhZIJlQhRVIrLCqCpGrCpjIiFGUQMhrLCcwCEiMzyjBuANKyQAkRqQJU8IEXS7Mwmd1YMc4b384N61370Lus5X3m1N0D7dT6BBIJAjzAzWqLbDrrnuzR8f/n3H+KVFt348lxX0YHiEEYEbBNZbbEQlmGUveehlW8Lh+yUv6oy2mFDQ7yg5+idO/MDPQgGjzW6K1j70vWf1oq2L/uRF/UV3PvHktFWvL8978scV7QaOgJvfUdMdHSV0HxM56E4iBFljEsRjE0UE1eG/li8GyI7O4K2qdFeURNT21AxYfnHmrqDPCxoObkHWaHDjc2oZR9AU791atHebvV6jRl0HpHfoJQX9mavngR7EU1EsB/06s9VQ66dVUOQAF5FKuFRkefVXr/mdWqIxc8Xs7DWH9zo5Uae3xcgBv+sYkANhkA1RdmMYZM0TuMXa+VKJdr6G3P+yLf7w+dIMAACwidSOLE3RsanNOxCCsjauOrLncAtj3Kz7AMCwKHOH9xACh7sP1WJT0xPTm8jBQP6e7Yd0Rz8D1KBSFJmo8PcC1ZMLQXjE8KEPPjTu1lufvvHG8Tfd9OyQISOMRvPUqSg3lzEYdiUn/5CU9G1i4tcpKT+3aFE+cOANzZolde7CNmkSdJ/aR7Xy8/I+/ei9ubP/hGg2bVg39tbrr7z8ovcnvwXNiEiS9NO0qaPCX92IlJPfnOj3+yO9xytDIWnb1s0fTnknP/9U90wVhm/Xtl2cWRdj4PU8awjvwAocvEAZjsHA6niWFTi46rA8KMMkj2NZoipIVWKjoy0mAxiIvGYA7z0gsKLCwvULZ8q+w3umoLwQxB/w5OfuEAR9k+Y9W7UdbDJHl5VkuZ1lEJuqqpvWzZj52xv5uTuhWVs4jm/Rpn+Dxl3Ky3IO7FsLXXAxgR1bUdTt3LYoFAqAhgpFgCJwZhFgzqy7U/Q2QEjr7UvkyxQsYynBpu/WFCuy3mpTPEHFEeRFHkiCzGEcYyTRFtZs5ixGRkFYUQiv8nrC+L2qPyBajZzZgIKS4g0QBSOVx4hhgNxJSrDQiSWe0Rng3TBiiFPxOfxuOSBhkVV5TmEZouMwy2MJy24PUoJEDjIwJ2JYQSCszIgsQly3kLWvr9ZmKDrTBz7a4c6500r2brEl1et4xe1wb8ZggBE+ZIUx7jJm7EN/7LrksTdS23QDOrJ11vf7wnmpGptqW6yNKtq7dcqN/bI3LrenZAy9+1m41VT3hp9wuDy20PRYGw5dAY/r22fHvnvniM3zf/d5nKCJS2tw4ysfjX7sVY75UiojAAAQAElEQVTnoFktGFUPQLUOXIeuLtURQ7QgMa6lQq7yYjnk5w0GltVmDAX8UjAYlZgqGs01ZslN2yQ3buVzlktB7T4BTtoOHoWIumtZ9c/dCQaTLSkNHFfmZ0dG+d3O/asXwK207+1PRKc2yN22tjz8sTzolQLaFLygE/W18nnQAYLhcVgwxq2G36C3ar/Akta+V0xG08N9kdqR9hEdgHC0GoMOwfn6+OZ+B+F8pWYMPPZ8hW2qPdR6ikpINUbHAESOYwhljZXeZIlJa4AxKty/+wT5kti0DE7UuRwVjkPfI6nxUFOJT8uAurPk6HwqKI8nPI86dzGNHBl9xRX2yy+Pv+qqQVdcMbJz517FxVGS1BahoKL8IUnfSdJURflJr9+QkmKy2bgGDVByStAR3qw/ynMNabtuzKW7d+2AXp1eV1lZCZXTFGB+wP8iRBDKq68Y9sIzj+/bu/svuMWsVWThdcUxiMVE4FlR4ESeA/YWFobnNIbH8+ES6iwL1vC6NRn0UVaLwPMcp9lgjIEfy7K8dtlSR8EB4Pl/IYZzYYpbtxvauFnvzH3rZv325p/TXwdiFxuf0bnHaEHQHW/+uIQGfQfdXi+9/YF9a9et+jnC6pLDO7Z5B3eUl/6NHdvjTUX1FAGKwGEEmMPVc1i7XmgiyUFi1GGLlcGKc+MOVg259xcJkM5ArMgLjMCxAoMDcmhXGS4KihYTG6vTmTnBGyRFLjakyD4JCRxnM6k8j1RFqfKoTj8mGHMMwyFej/WxZs4sqrzqMciZXLmMiIEIerOOE1kE12CeZTgWLqZwAcUIrqgwMUbwplqC+6CKCEZw58XkKp92C0dn6SAIgdRy7ndWLfvkf0RR24y4KbVtdwK95LBJ/fa9+t/5DLCQn5+5ZeLg+h/fMnDGxIeXff0WJGDAENU+CII7x59vPFGavXfO+y/63K4W/YZ3GH5NxAS6vI5yTtAfmzTSm22soPNWVrgrSyPGqqIc3Lb+m2fGjh/U9KmBTWZ/9CpRSftBl8WFv8EQsYnEGakfLmtFXqOs2zLcXZKt7UxFJaXpjKaworpwV5Z5nc7oxHomu5ZihB3bkgO7IfJ2Q0aFTx+yp6Rf+sj/EGZgRQyrndM2g0c17ztsx5KZudvWRbzojBZeZ5QCAc+hdYH+wLolwBhM9gSEceaqwz/aF/C6Qn4vZjnRXOvsR5ZzJNBp7Xu1u/RWb3nJwfWLRZOl5+3PCIeoIZwUv6OcFfSWYzJzOpONEXS+ygrvoWAAFjgps996oix774IPX/S7Xc36Dm97SfX5glBBwObIyUGnSWxGE2DAHshlwnazpqjjAdABgOChGECuo79aVa9Fe0RQZWFu0HvEV2Gqu8NPManp8OxyVEqhU/+wvE+Wf5Kkp2V5nKI8pdfvaNas+7Bh40aPbtmkyb16/cWyrA8G3ZLkCYUqfL61bvcbkpTLcTLHEVWVYbrjCdCy2TNneDwuuz1m+IjDv+t2PPtzoIeLiaQSFiMeIxZjgYWrGSfwHFzPeJYJC+agwrDahYphJCnkcbtAE2Wz6kQB3qZyQPwYJnyuSXlZ6YbFs+XASfKO6JwfJnN0fEJGRVn2/j0rFUUiRC3M35O5Z5UtKjEmrn5d4eBGTbt17DoSjFct/Wb3jmWqooAZbC2AXpEDXq8jrX6rtPqtU+q14AU9ywlJqU3jExsyDANmVCgCFIHTQeA8/BV1la0ppW41FPCmGo1dGzK+EMkL4BirPiGWj7YixHor/IqfICxKrFDFyA7ZESJBfUISY7NKZkMQM0pA5RAreUMhuKTaLZhnGDmEQyGsYqIgIqmST/YcLA1WumSRZDEOD49EVmQRCnn9iFEZjFQ/UUNEhX+YEEwQgoEEMUgJKNrUKoKDsKiBxdoCHUE7QH/GBCMEgo44cres2j73B57ne940jhN1YFBjktCkNcMy+1fO3rt8TuQqCSN1RjPDwT0FqrUEw/2aqKq2jKJ9OxZ8/ArGqN9NDwMlAqOAx5W3YxNo2gy8jOU40EQE6u2GjMQY5+7e7Avv7ol6Q8/RN+tMloiB3+Na++cPjrJCoMgsA3BG1AhDiCDVrUNPGOFD1ZpnTaM9ahSHK5UlBUG/x2yzW2MTD2sR8jkrizJ3Gqy2jLZdQR/0eZf98BEi6kV3jx8/Y/uTv21+5PsVzrKivSvnxqU3vmbCF3d/Nm/kU28X7d8+573nFLmaJYgGo6jTEVWWZQmcRKT84L7SzO0QTsDlgKxnRAllyOtxFeeCPjolHZrVgsPLwdUteDJExfS950XMMmu+fXP+G49U5mbW79i71fDroQsk6HEV7dJAbtr/aJBbDBrJYFy4Z7M/DDIYA4BwxuCEQb14345Fn2jnq++ND9cOAGyg91iJiktGGFCqzmUeawAaozVKNJpgsxW2jKFZp8DZt8YA5UVAGY/H4XQGY0KY5+Xv3a4cwrZOb0cqCSE+VXWrqlOWi12udwKB3+z2+gMGvJGY2M9iucZqfVAUE1hWYFmEMeSwgGUqoRCBP2im1svsSJ/VrZXLF2/dvBkazVq0HDj4Yqic5+/bqnKVLwBnE04xxoTnWJ5l4frEswwHwuAIvQMDANntcqhS0GYypsTHJkaZk0yCHrq1M629zhRF2bByWcmBXQQuarCwC0kEEagY53ZVqOGLTCS0UMiHMTZbDv+HgRE9lKn1WjZq2rOiLGv5oq8dVYd/IIbBLMtygmho0bp/mw4XgbRsM8hgsPK82LxVvybNe7AsD8OpUAQoAqeDwHngeRf743U6HeIJZvTOnHK92Sg4fLzfKeXleUsqMEYcZlAI+Yi0PlQ433vAr+NxWci7KzdYVqn4nAQDB5RVOURkGXZEWEHADMfxDAv7vAQxDIN1rIpRUFZcRNqDPFsCFXqdziboYalEUWAUUqEfEUxUlhCWIBCiIllFQPkYDBdovd2AsQptJ2di4aJ9OgCfYCypo09V5LXfveetKOF1BoTgdoBqrFRZIgQlNmkblay9Y4Ybc8tBI0e/8gXLcjU2KHIc2d4695fsLavN9vguo27GGMNdd8PM73weV6v+wy+691lBDxMhoHQDbnmk48VjZElaNf1LRZZ5URwz/p3LH55w7XOT7Ulp4Jhh2WbdBthiEn1Op7/2hhpMBwIWtYUcjry2+nj1qsK84qx9QG3rQVaplpEUDG5fMgt8dR5+jdGqfXFh94p5nz44piRrryHKbrDYln//wTdP3DzrvReKM3fXa93ZlpS2/Lspn9832lVaVOPGGB3HQgrN7fQd+kIudAW8rs/HDnupT+Ibw5uV1/reg6rKIb8PFqS3aNOB5WEBbbgBMLa77NaY+k0Ktq7ePf8XT1nRmq8nEZV0uuo+UCIELyWybfZ3AberSZ/hfcZWgwxQd7/hkVZDxkiStOn3L+Fcg6UmR2K1Y94vuVtWG+3xnUZq50sz0BxGno8uLXFJAE7I5zvs7WgTpDfb4EWiylIovK99TL+m4AXRFBUNNSngU47D4WxxSQkNmhFCsndo1AqMT0XgRRsKKYGA7PeDhFyuHS7X75I0125PF8Vonm+g08Gt/XqME0MhtqpKzclRqqrIvn1MQZ4hJroO0nDUpOvXrfZ6PUajqVOXbtBV5/dtQX+OhKhBSbu8sJgwhPAMwzGYBcGIZRBcW+BPOhjwu5xVqhSMtpiS42MbJMU2TbBl2HQWgQF+R7TNBAQvsML8/A1L5sp+N7yY0CkfvE2vy4g5BbGfsss6DKWQD15NsfH1BEF3qBtHRScD7XM5D9O4SJdOb2rcrFso5NmxdZEsH5EG9vtd82e9P+OXiTUy54+3nY7igN+9YNYHyxZ+JUlH2Ecc0pIicIYR+Le7A/JzTpeYQHQ95fiAQ2VYXVyLpoGc8kClD8dzSsgXlCoVA8OwLKcyrlBoRXn+1+U7d+s90UYjDihcYxuTamBFhZFCWJEQURRP0J9b5s8vR0GG4UTM84hol1RO5Bg95zArq4XKqa5cB8fHq2ZRZhQOKZKs+IJE0rYMkElUDJwCF2NGRoqMZAWrwP0gi8dgGRO4YjFyWYXMuHlwe1YwwnV7rSrIXvnNm9CHwQAjDLWwZK1f4nNWRqVk3D111filRU8tyrt8/JTM1QuAr9TYhA0RjKmtCfq8q3/6FO4W7S8aExfeby3cu2P6hIcURe45+vYXFx6YuKoIyoE3PUiIOuvd5w9uXYcQAoK1ftY0KeRv3mvI09PXvrmm6I2V+WOeegOzzLIfP62o/R8qwGQgMKa2YIiidjtcx+GyrsLvce1evRh6mvUcxOtqbh6gQLtWzivO3pvarG3Xy2+ElwchJHPDireu6/tkj8Rn+qfPfv/loNddnpf97o39x/dMfGVok7mg8bm1kYce9pR0ANNZUgBQHNId91kOBv2uSojUDBTqKCvQhjXJrTp3vOoeWZJWfDEx5Ne+6pG5fOb+ZX8abNG9bn+aC8dfun/H3Nc1kDuOuv3BWQceX1L00KwDPW7QQF7y/vP52zWQw84QIHXIMYIDglzz86dwvtoOHRMbPl+ghPhr24DmsGAEvYebddZOxabOgbWUTTv3MlltB3dtztm1pZb6JFX428o5iDZvQhvWo40b0MaN/szMNS4X3MLXqGoFIayixAYCbRwOy/79eO1atHwZ2r4db9+uKymxxtZ8VeX4kyxfuigvNwf6GzZqAsm8fafxfVtwcvrCM3A6MI8RvDB8bkfI75ODASUUlENBeHNVVVGO5FB8dFRKfFx6QkyLRFvDaL2JZx0htcinBFWkEgLvJqBYNufPgj3biBL6SyGJ6TEJt3Q/qdhH1vr5xr80QdjY7arKy9lutsT16Ht9g0ad6jdo17PfdfUy2hUX7ispzmKO/F0Vi0X7zI0U8ttjUtPqt66R1HotRO3dbNgjLSgCFIGzhgBz1jzX7bgfiScqZjkWJxiDBoJDAaWsKFBeGVAZIvJwyccCcgd8O5myWaHMPWqVRRV5Z0ggKoJsgC8QQIwqCnAtBA+8wEL0jHZRRFJIkQIKIRiulEpALpa884NFXwdz9uFQuhCbKBmQTCSeqLyKMGFgmIyF+DhksmDCsyGN3kXC1e6XDPaVeoiiMLJS38AOj040yjAg0n9GS8jiQPB1udy14Lf8bWsJ9ILNIYOy7L3f3Ds8c/VCoKDQU5q199uHR8//4MWA1w3NQ1bh51qjwm2UtWFF/u7NOpOly2U3YIxBuXPprHeu77th1jTgvjCRIsu7Vy1487p+K37+HO4xYACye+WCCVd0W/LdR363C4XnOLhj47tjL1/07fs1NmAGwyO9UD8sx8QAXXVbQkdYNsz9xVVe0rB9j9SmbcKK6sJTWT7nw//Bqofc8fjF9z7Lh1lUdd8xT8Yo+7EGeksUTA33WgQvpGOGHKsoP7gPlmuNSxH0xureyHJAixB463PX8xzHb/3jy8JDdA0AXP31Gz5HZXrXQS0GXxkZtW/5rK9u7bt9zmGQM1cv+OyWfht+wePMqQAAEABJREFUPQwyWEJsYcdQrZaDG1cU7N4smiwdL60+X8fagCnGmOFYAB96oXk8YTjupDYE/jBw2NVxvOhNls4XjSIIrZkxDUh5nVYEqcfqgyH2p5/Zp55mHnqYefgR5qmn8MyZAZ9vi9sNJHgjIW6HY8+6dS9t3Hjgq6/kV17BH36Ev/+eKyuOsphiBOGIbbulSxZeN+bSq0YN+2HqV7UnGv/Ew6NGDL71his3bVgHMrbW922PN+QoPTgEt+Ac9LU9H69e50qrjVW4ECHMsE0bNbAYDTwDbx0VNRQIeT1GgUuOs6cmxKbFRTWNtzSw6fQs4wiqBV65zK94JFUlCP6yQpK0dcPGbcvnhbyOE5/Z6hnPwxPZvWP5pvUzYOZmrfq2ajvYaLTu271i68ZZqhJ+Fw0dhwQ2eRmWs1jjYVu2trRqN9ho0lLIhwzpM0WAInBWEDg7DOb4oXZymxmCcUgJlZdVrlpljYa/c5l4/YzVJCZFM1iWbUzAgBCHLJxOZFirIPhJKOTz+DMLQ1V+ZDASgxEBUcQMz3Ph2woD2TvWwKqwCcuQoIj3mwO/8UVf+4u2SqGG+ugmsl4XUOHqyQZVJqTCdRRJCCuYBIJYDiGkEBYTjDDHIIwYjuENPGYx5hlMVIOjvJPKdcZWdKaPkn3bJl+cAQKVY30Hva6pD1w2sV/ipKEZxXu31RhU5GVNe+K6Cf2SX+mT+NFNfbM3rnCXFU8e3fGdKzq6D30Mv3DvtpcHZbw8MAMqNQMDXteHdwyDdNcfbz4FUET0ZTkHfn7lwaf7pD7RI/Gp3qlfjLu+5JjP6bvKSmZMfv7pQU0e7pb4UNfEd2675MDmw79xFfB53xk78v4uifO/fi/iM1Lm7t72QK+M8cM7Osuqf+gENA/2ynioV0bunsPLiRjXlOV52Yu/+5Dj+f7X3XMUV9u1Yt7UZ8cCl+o95o5x36/octn11tgEjHHNWKM1qlX/4be8Ne2JP7Y37Tm0Rh+pLPzk1ed7J3790JWQXIloTlyu/u69V/smTn1wZMiv5eqg/O6hka/3S1z7vbZMv6tq6l0XvTEgccmUZ2vABIcVB/d+OLLFmwMSt/7xNTQjUpF7YPbEB98YnPoanM1BqT8/eX35Qe3/24j0Qlm0d9trQzImDs6ACjQjAufrs7HDXuydOOut6vP16yv3P9crcfrL90cMIiXM/uPz9zzdM/GTe0cGfVqoEf1R5Y4lsx7tnvhUv4z844Mf9HnevfPSB7omfvvCEVPUuGrVa1D9lu1zd23ZtEC7u9foa1ekkFS7Gak3qFcvMbae3aZJlCU1GNA7HMjhCFVW5ufnv1dc/GtVVXFFRWVlpVRVhWTJEGdPAyJkNNh4jot4uADLOlcKcRKVVFaUl/nlkoBaPzkpPTEuJTY6OSYauF395PgkWFusrWGMOd0qGnkGcnjA8ErDDE8GiqeNJ86qyqVzZ/3+5ZTyvP1EVUB3OhLMLi/+fFXBpAUV0zefjh8YW1meP+u3t9atmg71sJDCvN2L533y5/TXZ/wyce6f7+3bvUqWJehS1SN+VyU/dxcYHCvgDXyCfW2RpCBs18Jmrt/vqq2ndYoAReBvI8D87ZF/Y6BImPYhM89wAqQFnFWM36FrE6/qRUVVRaveEGXEjEpYpI8zNo1JasRHWTEfy+kDejUgyJhRkMIwSOANIqdnJR+QvyBmGczwBGOVUYgY8htCO3Tur7xZ37nyDqiyhTO005uSNSOMGMSCbxW4HNShQULFJdjlQCikCIhghtFuKgzEpRIFASoYYYZhlJClIjCGTcHoNA86/JQQWPvHd/vXL2/eY1DrvsNqDyCEbFs04+0bB+Tt3mKLT7780dee/G3zhBWF/1tZNCEsT83cddWLH2d06u1zVKqwU1h7MK2fNgL2xNRhdzzqc7mmvf6Ux1n9G4THeg34fccqo6KsFrPVZLSajVaLyUIIv2c3+vVXddq0wLffrvrmm19++mne0qXe1avVgnz4O+OsZguY6UQRY2ge6++C0NS50nBkpLQgX1KIRWDTbLr0aH1GlL5+tD7ZZoizGBtA3SoaeFwVVPLccqlf9kpqNcNDsCkR3LJu7beTX5v56Vs5W1cpwTrARH/x8GzOC2SVSw6fe1MecL6/OJqaUwQoAv8GBIDRnLtlpIV0KqPwmEO+IBdSWVfQm5XDsqKKeV+h05tTgXwMKvbrVQarqhtJgsolB/UiYnG0KOvgiWN9Kvb6WR4jVsUcZngOE4aEgAEit15aI5Z+Lh/4LVCeSxSOKO10lpaq3gjcjscqR2QWqSxDGAy8UKN7CuzyEkRgPGIYVg0Bl2AUGYcCQRXJCEYpLG+IwViXopqiiB7R4+wjABuC37/0QN7erZePm1CvxdEfIYJ045Q7Lply27B1v3/jKC2IsAAoFVmuyDuw+pdPP7pj2MTL2uxcrP1e7tkP9r8yA+zYXjv+jaj45G9ffujE38Dw+33BY77qwTLwHorhWHhLxrCs9ie2cSOaMoW89RZ6803XxImL3377p99+882erWRlIVXBLKdZIvgTRRfoAWuEldYZHI/knVs37czMLiwrd1RW+J2VAVeV6nNbGaWemRcYpsSnMbxyv+KTgeEheGMJfoKBwK7Nm755d9KP77y4Y+mfzuIcJRQgkT7oPg2RHP6a0bXrNUpaOa8I0MkpAucCgXPK84wKq+hYwQSsy49gZkn1ZJVgxLKCnnix7COcUY8UFHAHQt4gkaUojk/QmwSGFc16zLCmWJs5PgrDVgZQMsjhyUooFFTVEGGYUo4sUCs/9eXOD5Q5VIUlTBzDdxRsySEjE8JIUbULqrY/S1iR5YywMwu3ERJmfAioHmEkgmQGczqzFWGMMCEqIkD+zNYCK94iOQ2yiOhxThBwlBa9ddPQ8QOb5OysY6dJVZTcXZumv/bYq5d3hO3mJ3skgjzTJ/XNq3v++dYzebs2gcE5CfM/NAmQ78n3XHl/99Qti6t/d/oEi3c6KoPHUD2gLCAYIZZlGzfIaN+6XetmHVo26dCqafuWTZq3bNKkbYt27Vt16NCmHfSyDItPMMH57oLVwRqPFwWD1P3rFr315hszl6/7Y+Xmn5dv+nnZpunLQTbO27Rrd3FFVUAOKEQ5xOHgLUph7sEZ333x3dsvb5r9Y0XuPi2NB1ef401wfL1c5Tu209RO+591QM/bDDV1RA+KAEXgv4QAsK1zt1w5hBW9Luj0qmKQwLUcuBvLiHqR4XWmKJvOZGQIz+kEeEOvQGJNVmJYvV2vg0unLEFujcHwT2AVoHcBGegagxFBwYAulCv6ZkrF37gK1wcDHsSrmGEQ00KMbi2bbCGeUVgkE2CHOHxtZXgGswgxiGhLxxjIngI5vRABI4UYo6MNFj0GSBjGpyorAkV/SBXTg96QGg06KhSB84zABT89IcRRVeFyVsF7MAJZ8Qs+4FMMENYCK4J1wepgjScYpQRc2RuWbly2yOV2e3x+t89X6XLnl5Zv25e1dddep8sdGQtXI0dlxeLZMz5/7bkl0z4pz9ou+T3obzG8iMPAwYpIpXZpapeaPG5g4q3doaytj9Qlhw8kUqclRYAi8G9FQCM7525tQYWJtcksUk16wgLbQgyD5KDECIIQZcCqovj8shwCDoYZNcSoNoKR3xdy+YLOIAphf1W5r6JEwUhWmZBPkUNSUK/u1Ll+CGT9UJW7R5ZVVYBMHoPVWIbpqIvKUEVBkomkEBV2YRFQPR4xqlcOOWBnViGCghhgeSxSBawyQP5YAwlUVvIMw0BqT8eUSf6lBGfLKcn6dt359HOHEp2JIvAPRwC2Nasqy0uLi0qKC/4dAmuBFcG6Tn5mCMJBV+76RXvXr4YdBwSsEC5AqhKSpJLS8qzs7EDAX1VRsWTWjA9feOK3914p2LZa8jqJqu1TnNz58S0CWeWORXuP7edtBjE9Bh1zAMOrmP4Xfh/nGAdUQRGgCFwYCJwsinPK86wYl3i8xCjwUdGI0z5apwZk4pdUWQr6fbISVHFIZWQiSUowKLFMDM+wJIRUhcPaJ+xU2Rd0O2R/AIVg3wO7LcIGvfRVoHCaVJqJZUIYgSAgjxxSW4vGdthkkbGkU0BYI89wkP0jSMJYxQynEDao8IoiEIVnCeGRrP18A8PKfmeZt8yFVJiT8DqurWAfLqReERKG+arfhZ8MT9pPEaAI/OcRIET1VmWunb/ol6lr5/y+e8Xi7C3r8/fsyNm7a/OqFT9/9fln/xv/y7uvZG9eKnmqVEUGLnhGIAOeVzF9MwhUTioFkxYANTwj81InFAGKwIWMwDnlecmC9UBunoqQwAkEM9on4oDnefw46EeqpIuPYqItiMeyNwg7sqLCpCCTyLE6iyiymMWQ4xNYieFDMquoLguzxOT5PJQ/X6kq4VSZBfoGb4hVhqhxROzIxdULGnGIyAIBhwzLYNiLxQS2cFUDK+lxkMcViuwjRBIJw0iYIKQgCbZniSoLSOEI9pMErO8bdHX2Zab69yb7XRfyWaSxUQQoAhcUAhipjK8ykLWxeOPCPUt/2/zn1HXTP1/zyydLpr638JvJe1fPC7lKkSIjuNKd0bjdm/JATkrywOCMTkudUQQoAhcuAueU56Xp7AWqQyGy7PIjmQC1gn1bVlbZQBBJMmPQiQlRLMtxwOlYJEo4UTIRLxA4hAMyCskcEllR9BulopZ4+5XR629OKLkmJXZk46Re9a2t4uVkg8+MGFZpxUe1UezmIMuoiPcjFqZyhdSQonJYMqByM94kKn/I7oWBMocic5LKEZkhCASr2lVXFrAiAqfEeh82u4jBJzOywvMsogdFgCJAEfgrCMDbS5YhsBkhMIqAJFENiiTIEwkjeGf5VxxRW4oARYAi8HcROKc8rz7hc9QqN/H5i51AqhhBI08YYQ72ZzHxFVQopR7OixQFh1jQ4TjeoHikgCMgeTwqZN9Yxp+iy+0sbLzVuPx+y/5HMtjx3VKe6pb+ZLf6T3ZPe7pbypMdm1/fpGeLxHSO52UJCZgIfNDAea18ZTS3x+yfg8q/8hV86Cv4zlvi1KYVGYlRGSTrEXA7uCjzCPKFegT5PaCZkAnkdQojMCYD4c4pUH/3bJ69cdQzRYAiQBGgCFAEKAL/PATOKX0BXpeleL2iikWkqiqn4wAwbQOXMBi2UMs9crGLeBRVQQoviJi1GvSCRQ9EjCCsCExVdHBfZ27zrWnLL41e1jC02ezKi1crmwi+HlZ8aaJ4a+OkBzr0ubRV5wRrFAKSJwWj2fI4Jr+FYWcf6/zu7I+NvZ9GV32llK4MVMbxlq66ZLtgwDpB4jmVhTfYmEUgjDWxPlZEwqGQiBWWSLzsJcHSM/GbpbBYKhQBigBFgCJAEfhXIEAX8c9A4JzyvFlyWS4hHm+QQyT8I1kYQzYPOBxs5QYVrKhIQCFOhe1TEXFmomMIFg0iw7GyUVdW37rrIvOaq6OXDjQvtgYK3D4jQkYshVjFz5IitIIAABAASURBVCplxJ8VcmE/ycjnokuI1xQsaqVmDrVuvCFl+T1Jy++L2XB3bMED6ezTbeKva9UgJXaIIaG+qme1fVrECQIbRIyMILUX0iE/45N5VMXJ+9mKTKmsRHF5AgFJhqD+GWeURkkRoAhQBCgCFAGKAEUggsA55Xm/ugqqEJ/jcyFZYbQfTiUI5ucQwars1/5jRMbAsjEia2CNDBeFRCUUCvlDIY7kRcvLWirbrkvZ0tVcYlJVt4/PdSZ41TgVWVVecborCvNtVa6Wezwxhai0WfSmm+JWPBI353bz7Jtt8y/VbehBCvvoPSPio6/JaNQ5YVRyox6qxRJCRPtxFlXlmZCRleN1FUblIHLsyN2TFaosC2lfyMV6LPCMGXMCMFBED4oAReD0EKCjKQIUAYoAReDcIgA869xNWIEkL0bbWV/QJBAGKXKQIJUQWYV0WUjGQPhkRQnIHIvNEqrPiTIvuwR5r8H/k/fgDLbiQCrrEmU9Qg1QlKGADa4qQZuqqv7c49+SHyejhg6P1V1W1IlfOjb2h7Gxv10aNbuRspar3Is9JWzQyYWK3H7eKzfNc/YUo+wmvaQnipV3cWhPwLdadqwMFuVK3hBROYboEWtTxfrEVF+xJBitosw4iUZDzx1SdCaKAEWAIkARoAhQBCgCp40Ac9oe/oIDjkcBpOyVfX4dL8uK5A8Qon30DhGCWcSbOCLLrKRgvyp65DRWhwLKduL8IrAfEoEbtxWs+3y1Y1EO3uXR71Lw0oqCd9ZlTdvpq5Ds9gRdQmJJnHlNS928fvyiLsraFGmvQZF0oje/rLzM5UB8cUFIV6lPKMVN8mXW6dzOVsxmy7+Wsr6Td2/w5SkEG1VdtGpMZKwpSEzBQgzmbSYDF1CxT2YUtYQP/YV1UlOKAEWAIkARoAhQBCgCFwAC55rnEUTyQi43llVFJTK0EFQYHos2QZVUBmODWYckwrKsgLgqv7TAlb/EVVKAFcaiUwLK/i837nlp2a5JS8rmbAs5fMbU6Ph+jZkmMX4DG7CbqxIsRUZSykpurMoIWQUhRjAx64p1azzSDtj+1btKmGWZzs8O7P+sdO90d84Wb7nOwDQW2baM0JKxJAoGkedZFeOgimUk+2QVEeKTkaLs0wcugJNFQ6AIUAQoAhQBRCGgCFAETh0B5tRNT9+SEzA4qSJysd+DWaw1MAGup3KqzCAJNm1lEvKEMI+JJEsKUUyCX0Z+wqgsr29ojbu2sbF/Eo4WfekG5oaWljvai53shmSGYf0xRIlTsYgwMDMVIRACM2GcmJScHrKFvt7BLjhIMssPrM1fkF2ywFlaHPS30JsuiUq6WExoy+qtxM8H3XxQ4rWdZISxFlrQGYTgEIN98dxmvQ/8UaEIUAQoAhQBigBFgCLwD0LgnPI8UcQEkyDCByWFVRQeEnqySnjs0ys7/c4cQZU5NugPYSVEJBdSHSYdbiJEi4QBNshhKS41qsnIFm3v7d3kgd7pN3WJGdRESDbBAoyENSucjvAs4jnCWxQuWRZiQxyvIJ2eT01PNdjMjDvIbCtzbszFTk8HQ9QdukbX4ITuQXNMiGM4Hqsc7CjjkAqZPEYlwBbDp5CwHBvi8R6zvJ8JhDW0OC4CQy8ePm/Jum+n/XFci/PZQeemCFAEKAIUAYrAfxEBoEnnbtmQJtOJKETQ3pBH1imEgfybyJvNFaL8h1j6k1CyXu+qMqoBIyPpOZUQo0/KEIw2rCMS8u91V0w74PrjoGNNSWhlOfo1X5hdblktSb+Wl36WWfjh7oIPdhVO2VU6eYfz7R3SW7u8b+0ofntrzrubDk7brhRKhqAJ5xJLfuASNuE2e6PebEyaR9T7jKzfrDI6JItGiwWzjBpJBUI+EFBhSVAIZOrZ7wJVComoQHsm5bobb/vup5mLV2xesW7n8rU7Zi1Y9dqbU1q0bHMm5/hbvm6+7a5Fyzf99Pu8Dp26/C0HdBBFgCJAEaAIUAQuZAT+K7Ex53ihBj0TwOoB2es0G7yMiPQ6GbP5rLpWDCwx+L8Vy6cKzsX6YG4UF4zWQaItWuXTeYsos77t3u2T1u97fcuON9ZlTlyfM3Gj86PMTpn1rheGNtxodX9+0L4IXeTrXH+jueKjfcVTdhRN2VE4ZXvu+1vzvttVMj+3ZHnBwQWZ9fPkIbK9tYs3BgKyKORhe0ARcUhgMa8Gwju9h/AgCpFZkhsl/ca5Dqj4jKNkMBjffPeTO+9+MD4hIScne8G82atXLg0Ggt169Hlj8ke33H73GZ+ROqQIUAQoAhQBigBF4L+GwCFec67WbdRj3mj0WYyVfCyKthMD8QXchcGgmxOdHL9DUOcJvp9Q5Te47De+ah/v0+l1bfWxiQoruOTQXp+8N+jPdHsPVILIuZ5UJuayTkMev+6B5+94ctxV99w28KruKe2sbj3JC6D8ICoMyoXBUKXkrfS7C5zeg2Wiwx3tk3QuL0ahTCG00SA69QIjs0hBsiIToHMgLCY8YS1CpZ79QyFFckqQ85xxeMbe81CHjl1yDmaPe3DsTdeOfH78uMcevufyS/p98+UnDMOMvuqGy0aNOeOTnrrDLz79oH+v9qMvHbxx/dpTH0UtKQL/cgTo8igCFAGKwD8NgXPN81gOG4yMV+Qr2The4pBLln1or6QQzMuYCTGcg8eZvLKa9/3Gur5ifUtYZ5JVf2f9pqPi6qdgRqfKnCqxRMZIJkTCWLFazW3atrps1KUpySm//vTb3FnzvW4fQ1iMMSTogLoRjBGGZTIYMVVKwMcFCaNUmvFiwbdPR7w6MAsSoqgqQTAAYVFnwAxxGPg5Ia5YzkhmzV7sRmf6aNOug6KoSxbN27xxfW3fH3/wzi8/Tg0FA0ajqbae1ikCFAGKAEWAIkARoAj8VQSAAP3VIadrrxNIiMPFOBTiGaBqldFCJiMpGNgYgQ1SwsCGKfJxTDGH1gnBPwXHPC2xF7BbLQPiGzYWLTxSWaRiogYZNQDGWJWwvG33jimffPTFN1O379nrCQZlBkVEweAPgWsOoYZCdHd7eoxoVFjddhXvwLKXZ1QOEVYhvKJNzSKCiUQCLj2/qkpgQ1168fUKhY2ns+DjjWVZVlGk4qKCYw0+ev+dSy/uO/Xrz47tohqKAEWAIkARoAhQBCgCp47AeeB5PKP4Od9CafdiodJtZXP1UqmoylogRGFUhCWEVQLMC+n8iC9l2L1EXqd6V5DKQlFpGJXY3ZwSS1iRqDoV8SpSFHn1qlXvvP3WrJmzysrLCdGSctr6CcIgiMA2LMexNpOlnjWmIRMXbYzxJEev18mlLFFUROAfRjAKKkSbFnlEoUSpH0Ua9DMGo/1bNwvFmrcz/XC7XaKoO5VvObwz5bN5S9YNG37ZfQ89/sfspcvX7gCBCjQNBmPtuKB5590P/vT7vKWrt61Yt3PJqq1ffffrJSNG1ba57c77Fq3Y8sT4F0H//c+zwBK8zV289rmXJsLwGsuhdX159qprbvzxt7ngtsb5kIsuqRlSU+nStcdHn38X+XIJlFBv16FTTS+tUAQoAhSB/zgCdPkUgXOJgEavzuV8kbmI6t4plvzOlGyyhraxviodUhiNlhEsIwx7sgyHTGYh3qyPYziTn2VKhdAe0buXc1fwclNL0qWWpmlIzwVlxe1fvnDR5DfeWrlkmc/h5BRVUImgIhCOIJYgkeMtFmtMdJTBZi4S5GyCSzC/Wi3fJjrdHGycKkQhkMFD2qatKkTr/DZhMe/NFJ31dFUJ/j0zhH2RgM94uWrFUlmS+g0YOvn9z09KgzhOuPGWsaNGX+P1ehfOn7Nr5zajyXTlVddPeO2dGnLWomWb9z/++robb4uOtmfu37t44byiwoL66Q0efvTp62+6/aj423fo/NCjT+l0+pXLl2zZtB5jPHDwsMeffvEos9pNcHLHXQ/ExsQdyNwHzvPzcuvVz3hw3PjLjvwcodVqe+7l19MzGu7YvmXZkoUOh6N5i9bjHn8OIqntjdYpAhQBigBFgCJAETgHCDDnYI5jp8BqMMAG83lpsSrsUGXIu2GCWZVnVaQqek5OjLa1aTCkf5MnetpGNfek2Xw6XsXEzyqlbKiYIQ1tKdcmNG+umlfMmPfO62+uW7nO7wpqCTkmRDSaqEKGTuA5q9Vut8cabSbRoCM8ruSVjZxrnxDcQnxlGCtYQBizIZ6VdZyMGDVYxclLeel3XWg2W1LBuVZzJcv0Z/6TeRE0vvnyk48/eMfjdrXv2OXt9z6bPmPRhNcmDxoyLNJ7VCkIvMVq++TDyVdfcfHz48fdecs14x9/sKy0tF2HzmPveShi7PV6oLJ188b777rl1htGP/PkQ2C8aMFsjuf7DRgCXbUlPiFp9crl1155yVOP3X/fXTd/8N6bMLx1m/YnyC927tId6OAXn70fcX7dmOHff/s5+Eyrlw5ljdiiokuLix6693ZwC84fuu+2g9kHklNSLxkxssaGVv46AnQERYAiQBGgCFAE/g4CzN8ZdCbGsLIHqUKRKpeREIsDDIaMXkBUbGa2dWqjHvVubcHcaSoZhu132Ds92rHhkA42Wz2kRnlZfT4WSlWLoBp0Mlt0oHjLpn1+P0KEwwirmMiYEJEzRJtj4uwxVrteZ2B4FjHQiSSWZAqu7dgrE2wkPIuRwiFFYBDWMYSRdfxq1vUnrsgU5WxRWq53fhxbeiYWelwfP3z31ZWXD/1wylvZB/ZbbdbefQc899JrsxasfvKZl+Pi42sPk2V59szfp9b6xN7qVct/m/69qihduvVIq1cPjIFO3XTdqHvH3rhzx1ZoRmT50kUej9tmi27TrkNEEymzMvdNePFpn88bac6dNaOivNxoMsbGxkU0x5ZANCVZKi05vIv90fvv3HnLmMlvvlrbuKK87KP3366JAaKCOsdxqWlptc1onSJAEaAIUAQoAhSB00DgVIcyp2p4pu2wKjHYrzIeDwu8i8OMInA6i7Fx/d7to8fFVI1yrmuYtdFWsD3V7epJEu5IaHpDIz3k53ALI9PQo3J7QlXbAyVFfockKWZ9dFx0/WhDgp2PqmdMamZt3NLQrj3u1hl3aoISTCowOpVBhMHExQTWSpUMEk2EQTjowG6XjpUZnc/CrbVJMzhPpij7+KBbp/zJZecg35le9NH+gGl9+9WnwM8G9OrwwjOPbVi3Wq/TDRt++WtvflB7o1NVidejpetqj1+/dnV5RVlUtB02Rmvra9edTkcwEIQ8HDCt2nqXywlT12igToha06yzUpCfp9Ppb7n97tFjrqvZLM7NyTnKGGglcNCjlNDU6QxQUqEIUAQoAhQBigBF4FwiwJzLyY6ay6UUBoRKiVc4IohyWqy1a8sRrfTjfPt75W6PKbEh2QoZN6xUGXzlUY4iOS83b/u+4p07StZtd20oUopUNcQQzmxISo7tVM82oKv5sistV95mHn4n2/VOtd7tAf4Of/A6mWkiE0GVGQT5QpklUgW3pEIIAAALmklEQVTrLdE4jcoi2UecbpV1c2SzzfM7LstmUZAhEhcIMS6P6jwq2rPdnD935oP33vbs04+UlpQ0aNj4plvvPPGMu3ftCAYCPMcnJqXUWLbr0OnZF1+dNn32/KXrl67e9s6Uz2Pjjpuiqxl1KhXIJu7ZvSMxKfWBR56ctWDV9BmLXnjlDZjuVMZSG4oAReCCQIAGQRGgCPz3EDifPA/QLpSLraoSi1LSmJblgYrCpoVZDXOr9CUx2E8Q8SKjVbEk+W0oS96fVWy6vB7fEztJTjBY1k20PpjWsoPF5g1WHSzdGihe0cW370qpaKgrt7cnrwcqaxEqTa0sauWTW2GcwgejjCGLJWSwhkSbVGH1qQbRzpmbkkY2SSxJCC20+HOiETIpRoMcw6lC0IHO0wE7rXNm/S5JcsNGTf9SCJBje3HCm2+9++mgIZfYoqJLiov27tm5ZNF8l8v1l/wczxi2X++4+erxTzywbMnC0pKiaLt9wKChb7z90e1j7z/eEKqnCFAEKAIUAYoAReD8InCeeZ5K1GAoqJPrH8jdkF+6pihvJ0sMCjGUYb6QIQmETXLI8sLc8rk5Tbo37/Rg76bDmzWKsbQWrHGSvsrlrJJcSAnEh6qGckp/JpjiK43HDht2iX4np/gYNaSTSLLCxSJGZBnM6rEpg7O3UOMy2JiGMfrOzVGSqieLLey+mHokqaU+vonJ3kj1QVAn2cQ8/XPWq0//Fsf5f2xV9ZRmb9a8pajTSbJUVJgP8dx4yx29+gxwVFVOfOW5If26XDdmBNCyX3/5HnJ+0Pu35aiBSxcvfOqx+6+8fOiVlw+eM+sPzLCDL7oEIjnKjDYpAhQBigBFgCJAEbgQEDjPPA8g8KvObO8fxcGDbrcnf3eujIgeCSl+fdxOf/DdbZtv/HPXvQsqvthV9MOugklLgt+s6x0w9LTGBTBfjpkKohgIM9gQO4KxxXsCnKJwDMKqKnmCqqRijFhJTZF0lqAg+9iQZFa4VIWvH2KS/XKcTa5nNklr9cG1elMZlxhkUgMosSwvO+T3oLN83HP/uBcnvPXok3X/2khUVBTHsW734Twcw2CjyXRUUJ26dIuxx1ZVVuzauQ26GjVpzvPcmtXL//zjF2hGxGy2gDJSP80SWGmvPv1rnMDm8uyZvwGt5FjeYDTW6GmFIkARoAhQBP7dCNDV/bMQYC6EcFldwBLvZ9WAsqPKtLiEfWdHwbWzHKNm2CZsGboBjZHrNS0Wgn/m+Kblts/BQ2OiC6Si75zb5juzXEEvh4iRIRYU4KQAAoYXCCmKghmCiEoYwqgkLsRbFB7LAlENBFhkQEY+zihZ4pnQNn3lGhtxsnoSEFQ/48tdo/jLzgEgmzasBX7WoGHjR598HvhT7RlHj7mu/6CLZUlatWJpjZ7juIuGXXrjLYc/sdete6/LRl7NsOza1SsjX4ZwObUPFJpMlppR4Pnm2+62RcGGdI3ub1batOvw3EsTn3p2AoRX4yIjo5HZYvb7fWWlh7+EW9NLKxQBigBFgCJAEaAInHcELgieByjodCgpSq9mhtbfurDspS0NFpQ/506ezDR6UI69TTY+qE8YpBj6BcUrQ2m4jN3n9vOYdDLEttXbgyhQIHsrMWZFgSMKUiSkBAkTUvkQEQOIDxgJSVF4q8roQ6riIsEqghwByVG1XSpfq0iFss7lYwNOlzt3nuQrhEjOgaxetfytSS8XFuS1adt+8geffzl1+vMvT5rw2uRp02ff++Bjer1+4YI533z5SU0koZDkcjqAtIEBmH30+XcvT3w7Ni5u88Z1H055K2K2Yd0ql8vVs3e/b6fNAG9gA545jgdCGTE4nXLr5o1bt2yCwO554NEa/3ff9wjLsEsXz4sQzdPxT8f+2xGg66MIUAQoAhSB84PAhcLzYPUCjxOsHOciZqfQm0nqGoyuVybYHby9HHfyGh+wNLzFmJoWDAqqt43BOi6q5VhrSkdR4BmpVAmUemUVmTjRLqo2NmTGCq/yhDAqwVCI0bLFSESkqHIwFAz6PSGfU/Zky85yKagEVMWbL3uWqHIlxHDOZPnSRffdddOM33+uqqqsn95g4OCLYFc02h6zf9/uV18e/8oLTx0Vyfy5s2Cf1Ggyg1nzFq29Hs+PP3zz1GMP+A79Bt6ff0x/f/KkosKC1LR6AwYNTU1LX7p4/qMP3QXk7yhXf68JIU169cWcg1nJySkQbZOmLcrKSz/7ZMpH77/z9xzSURQBigBFgCJAEaAInG0ELiCeB0tlGRQfhYxWpSuKsgYkXiGcSngF6VU2gTEkekTBi+r7DUOUuLYuMckpN+P5JjpTSSh0kAuEWOTHUoVFcthIiQ7vJNJBHVcQa5mh93xWlbW5pCgQDCqKP6h4PIyvig9UcSEgftizDQfWIjUIs59jKS0pmfjKc1eMGNS3e5uenVv06tJyUJ9Ot904Zs6sGcdGQggB40sG9wQzkBEX9Xn3rYk1JC9i/+cfv1x9xcV9urUGg4sHdnvx2ScgZXjtlZdcfkm/jevXRmw+/ejd/j3bPnDPrZFmTXndmBGD+3aumRoq0ARljQFUwP+N11zer2c7iBZivvKyId9+9SnoI1LnEOh69eVnwf7YGaGLCkWAIkARoAhQBCgCZxWBC4vnRZYaMKvv2bI3Gj06HosI8Yhwksp7ZE5SMKcwDDa6RV4WCcOn8ubmgslJAnsYb2m0sDvZ8HuiMj1Z/drsmejPfTtU9lpl/uTy/WtCzny/N7+0QAp6dEaGszIkilGFClZaiZTMyKS0pAhQBCgCFIELGgEaHEWAIvDXEWD++pBzMSIL+Z4w5D1my98qBlXEIFXGIS8RJcIRlsgI+xEjCUGc4ubaKWIcJkWKbxtHFlv5WdHidDu3omFsboN6CyTXXGd+LpKCHMYEhXzBysIc1VFoVAp593rRuR4rh7/Tei5WReegCFAEKAIUAYoARYAicA4RuEB5XgSBpQbXnQlZj8XnrjC7kUAIp1E+zBCkUwlHkKLystRQNNY3xu0k8s+kbC3vdQqsg8NVHDbE2k1xcaqoQwrHyyxHCI+CMWy5IbDfXbFd8lVEpqDlvxsBujqKAEWAIkARoAj8lxG4oHle5MSs0rmfsuZdGZX5vrF0E+9DKsIhhEKqoqouA1Ni5vyszqWzZFn4cj1WMGZVBMJgJiE+PsEeE8XgOFFuGMPWS9VzsYKPlyJuaUkRoAhQBCgCFAGKwH8Ngf/aev8BPC9ySkpY6Ud91UPWvCGxex+2535kK5trds2UKj4s2r9ZcdhiLRazKCoqUiVOCvF+t+otlzzFBp3HnkT0cZzfgPyMGnH1zyofuOfW/j3bfvrRu/+ssGm0FAGKAEWAIkARoAicdwT+MTyvBqkAJhtEz3fmiom24g9tFbnxWLTLcuigo2Bz1cG1vqz1wbwtwcJdwdIDfmdBKORWEKkZSysUAYoAReCvI0BHUAQoAhSBfyoC/zye909FmsZNEaAIUAQoAhQBigBF4NwiQHne2cGbeqUIUAQoAhQBigBFgCJwvhGgPO98nwE6P0WAIkARoAj8FxCga6QInA8EKM87H6jTOSkCFAGKAEWAIkARoAicfQQozzv7GNMZKAJ/FwE6jiJAEaAIUAQoAqeDwMl5XvPxSRGp8jJUKAIUAYoARYAiQBGgCFAEzhcCf3Xek/O802GRdCxFgCJAEaAIUAQoAhQBisD5QoDyvPOFPJ2XIkARoAicGwToLBQBisB/FwHK8/67556unCJAEaAIUAQoAhSBfzcClOf9u8/v310dHUcRoAhQBCgCFAGKwD8fAcrz/vnnkK6AIkARoAhQBCgCZxsB6v+fiQDlef/M80ajpghQBCgCFAGKAEWAInAyBCjPOxlCtJ8iQBH4uwjQcRQBigBFgCJwfhGgPO/84k9npwhQBCgCFAGKAEWAInC2ELjQeN7ZWif1SxGgCFAEKAIUAYoAReC/hsD/AQAA//8mVhM7AAAABklEQVQDAP9K/oqSOMOEAAAAAElFTkSuQmCC"
EMOJI_B64 = "iVBORw0KGgoAAAANSUhEUgAAAG4AAABQCAYAAAD4K0AmAAAgAElEQVR4Ae3Bd5xnZX33/9f7us453zZ9zszsfrfAIl26CioqiCKKEls0GrH3Fls0MeG2a6IxUW9bokajImJB1FiwK6Ag4E0TpMnswi67O7PTZ77tnOv6/HYW/f0ev8fj/mvFZcmD51N53uR+9z3K8yb3u+9Rnje5332P8rzJ/e57lOdN9ncSeAdewsnIEnASIvL/cUQzimCUUQSDEMGM/5GU5032NxJ4B5VE9NdShhvu+k1jOurodZGBpMW6YdFIA1nqkAnnjFAarV5k10rkrnaVW+9K+f0uOtPLsbbYCrR7UEYw438E5XmT/YEknAwv0V/3HL/R2+mHlRxzYI3xgZK+rEWSlvhaQhFKzCJJ6sHYzYgxgkBmKGaE0tMqPdNLJbdtLbnkxgqX3O7/Y2qxfEUZjRiFmWHcNynPm9ybBKRpwlAte8v6Pr3t9EPTxhOPFxNDs2T9wmopyeAA1qgRan34+hiJT3BOKPGYGQLMImaRotulaPdw7WVYmcNas6jXwxZTlhdr/OJGx/duKPjtNB9a6NkbV9pdzAzjvkV53uTeIKCaOB446hYPq7v+PptjsG6MDCcc+EDPSU88kur4OK4+jKiBVYAEfAkYZpFVkkACDIslyDBAAsmwMkC3S5ia4sZLr+XaK+fYOgXtnrHQyZjRCL+bCx/atth9YzTjvkJ53mRfcxL9mefxYz0bS2c49WGjrD+8Hz9WY/TAjVTHc3zmsFDgfAUpg+AAEVPDMDDDMCQhdpMRY0CAsxTFBJNH8pBEymIaqFAudpi9fTO2c4ZdN+7iFz9Z4M4lz68r66+/ZcfyMcG4T1CeN9mXvBMND4+rt+yhR3Z5+GkDjDYr1A8YIxnPUXUAlKCih3yGRYe8AwzhCd5hAosBsZuEQ0DEYkQSEY/HwAKGw8whFZgFCAV0upQLC/S27KTYDlf+eic//G2H39jBO27ZPre2CMb+TnneZF/JvDh6Xc0ekfdYXyzw+GcP07epJKuOMRtGuGvW0e1WKYoOee5YN9Gg2ihJGx7nPYaIXqyyGJBAgBB7xACCKANFYoioSOksiB3bYXrnImWvIM0c4+MJ+VCbdHmazo42v/jZDDf/vsbmZB0/uWX+rxbaxVejsd9SnjfZFyqpOO2IfnvdwwPXXXsnjzk1Z+KEIZZiwhVXdvjBlfP85jZPKKoUMTLQ6HDag2uccdoERxzVoD7kwAckQwiLgT8SYpVZAAwUMTJarSrbbo9c/LNtXHTJHNunU6qpp9srObC5wuMe0c8jTxqiOVgyd9sOvvuNRY477gFcfmeXj/2884K5Fft8NPZLyvMmf27VRLzg5Ib99cmLjOQJv7lphtP+Yh3bd/TxiS9u4fLJfh7/gjey6dgTmVgzTgyBnTt2cOl3LuS6H36JFz6jxlOfljMwYqR0AYMYkcAAcTeLASEMR7czwi8uafHPH93KmsMfxaOf+hIOOnwTlUpKe6XH5PU3cNGXP4Hmr+OtrzmUYw5d4rpf3cbEYD9pkvGra+Hd33Lv274Q/zEa+x3leZM/p8SJl59SsVed2qK6cYHGA8awZJjbf1/y9o9tpX/TM3nuK99MfWId192yletu2Eq7s8wDj1zLQ456ILdc92vO/9jf8fijd/CKZ1XxfcuIAGZARDJWCUE0zBx0hvjpFQP825eWOeO5b+Vhj3sak3fNcdXVN9Judzj4oHWcfPwRqNfiO9/5Oj/9yrt4/yuGOOG4QZJai4Wtd9HZUvDb6/r5u/9OP7ltpnxVNPYryvMmfy5ZIl58iuyVpy9Qn1ih/5B+VKnTXh7nU1+c42etx/DCN/0LqSVc+KVLuOaWnXSGG5Te6KzM8cCRfl71oiezuP33nPdPz+H9rxzgsKOmcMkyFhzyHaCLzDBLIXiwGrNzG3nuu3fxyLPfz1EPfjQXfe8yfvTzG/BrJyi9J13qcFA94aXPPYPG2iF+9M0vsPCDt/HuN4wweuASwbrM3rmA29XPFdfU+cevu3/ZPhffEs3YXyjPm/w5VBLx9BMH7c2PvYuh5iL1gytY3SM3xOab+njLx+Y5450Xka8/jM99/OM85tgTePjDH8I3r9vChb+bZGE+km6e4kGHj/LsZ5zG7Zd/jTt/+nd84K1rSdK78PI418HUBTNkGRZSsGG+fGGDK9vP4GHPeAO33XYHv/zxTzjw2OO4fHmRWVclmxdu6zR9vTnOeduzCb2CC977al756Os56eHL+GyR2BWLt7cp7+rnit/18+ZvhJfNLMdPm7FfUJ43uaelHk5+wKD909NajA1vpXGw8BMJ5lJie4BLLsn45vancNKL3sbtN23l+st+xPvf8CLGBge4c3GJJ7/wzbT6JqjoAJwtcvaLnsBYX8F573gK556TsmZiO6kCUg9UIgSkWKzSbvXx8nN6nPTSb6Dxw/jWlz7HO1/zXNavG+GXt27hta8/h0q+iaGxI1ie7/CI49fxxGecwk0X/5zk1y/jjS/y1PqmkBPlsqd3M5TzI3z1qgof/HF43uxy+UX2A8rzJvckJzhyjfvdh87qHX7kASXl8DK1w0SoFTirU84O8vXviduP/AQTDz6FC//9W4zVe7z3TX/NeF+V6R0zPPzk09hFysGPPJt2p8dDH/sQTnzEEfz0P1/HOaf+hmOOnYNyAUdEYg9ZgqnK7GyF576jwRPP+SF3zrb53c9+zKff8VpGa2JqaoYTTnoU04ttxo97Ao3mCSS2zGv+1wuJ04v89qOn8r7XRUaa2yFGME9xqyOZqTC1OMoHfyLOv7ynbsG9Tnne5J7UX4X3n+XsiYfOkg0laEOGW9siZG3UyygXxvns13rMnPI1GusO5gsf+DzDFXj33z6DQ8frfPVzX+bN73w7oTrMgY94Kll1DQc/6EhOPevh3PjTD/D8ia9y/LHTVJIOyACxSjggY/tMwqs/chCnvuECbrxtitt+djEfOeelPGCkzp1bt/DYxzyWXbO7WHfkQxk69FSWy4SnvuzpbBwc4KoPPJL3vLJkYv02SAIgbGeDcEcHVw5x412Bc77V4PJbTdGMe5PyvMk9xTvx3JMSe/NpC4wNB8rqCsnGOuqHyAoUCUVrjAt+4mkd9RH6Rtbz6U99Bg805m4hnZ/i91u3sHO54NQzz2LTiWfxo8tuYt3hR3LqXzyKW371YV629qscefgSLl0Gc2AJ5iJiNyXML1Z440cP5OGvPI/rbtjOVd/7AccdMsjjDh3jOxdewJVXXUqtP+UDH/0Idywanz7vZzzu2WezZtMwv/vYU/n7F/QxOnEHqIUQatfpbV7BrUAven5y4wB/c25Vy13uVcrzJveU8QH/us++MHz42DVzVCol1ijR2gpUCog1Wu0aC7ORnfM1urUHUW0MYYJaX4OKK0m86LY6dArDp3VmizpX3biTTmWcdYcex9abvscLj7qcsdFplLSBFDNhMpwTINqdKv/1vcMZf9DLmN6xwNzt13LoAZGxbJ6R4T4ajSpJJnAFRQwsr4giVii6BX7zpWwYW6B/baDW38N8G3oV3FQHLUO3cMx0h/jg94b50qUdmRn3FuV5k3tC4uF/Palmzz5ploHqAl4R6xMarRPNMT9T0E2qDG8cIBvIsNCPioBJ4MCSiCVgCqBIdI6irFPGGoRBpncENv/utzzi6C6VyhLmCjAHYrfIH5WhwjVX99FYfwjNg0aoZB1inCOzBZwA84Dw8hAhdMBZCj7FJSuElWkWptu053qMj6ckvoNbCLAUieZpU+Xm7f286jPVr09O955h3DuU503+VBIcs8HPfPavWyPNsXlcEhCghrCRKh0PaaWBzBE6K6jVw6Yg9AyJPawhKmNV6PeoFghpgFhFriDGErMqlJ7YWybxAjPAQAaKrLIYgYSYTOAR8h2i2ph1SCNgCdbz9FoRLQT8oqPXyShiSVorcP1Vkn7halVMVejOIbVxi5G4FDDzFIilbp3P/nQtH/rBskI07g3K8yZ/Ku/E289I7fknLlIdWsSSEgGqCPoyemnERQcrUMz3CNOGm4KyCzGATyA2wOcimxB+XMRGREkCvsQwJIFA5hAeM+NuETBWyYS8J5qHGMACThHJIIB6nnJXpD0NcafhZ6DbE9GMpA4aEX5Y1EYTfF8K3iAGaBVYN2LmCRilpVy7eYS/Obd6/h3T3WdHY59Tnjf5UzjBhpHsM9/66/LFE2vmUX8X8yXIcHK4qsecIXNY12NLgWKuIM4ZZRcsQpqCGg4/mpAMg+VAvaRMIjixSgKJPSQwDElg/IFwJlaZRfYwgYEcmEW0IlhIiDMQdhm2CEWvJEZIKg76jGzE4/s91Aw5A/NYUUAZiSZWxdKYXa7zr98f59zLuyoC+5zyvMmfInXw/JNSe+djltHQLFY1vGcPJ4cyB04gYREUwIoIUYSiZJXPMkhSlDpIC+g3LCkIiYETdzPAkECO/5eZIYlVimKVRUMSGFgEOcAidEC9DDoJ1hOUQFFg0VCWgiK4iJxhEpKwaKgMWDAMUDToGbGo8pObD+al586p3TOMfUt53uRPUUvhU89K7DEPmCMZ6BAqBc6BJMwMpQk4UALRR6I38EI4nMTdBAJJmIvgDflIdBCdQGBmOMduwjmIFnESIBAIsMAeFiOSwATGbhHMUACCwyIQgAgSmBkxggGK4EqhIIgeK4FoECNmEZlBFKX1sXX7CC//clpcd2c7C9HYl5TnTfaWBBtHk//82os7L2oOz5BlAcsgJoBAgPMOnIfMKJOSkII5SKJHCCSQwBXIGQKcc5gTJgfOAw4QOIEckmEGkthDAgMMMMACYGAGMYJFUAkWCREMUAkuAAbR2KPnQBGSAnzhUOmhNDBDBtEiCkCA4B3F8gD/+4f9fPTioG5p7EvK8yZ7K3XwtOO9veesDvXGPL5aUjgjGcpw/VVit4dbKSiD8JnDkgA+gjNWCQc4XJqAM4gGeKISCpfQbTt6rYSyl9LrprR7ouMyQoiYGc4ldDodJIEZPslIk4TMetSrIq2UZFmPrB7xboFqxeNjDxEQKRYzsA7EDgZEAwtAABfBmaDjQAkkYmm5S8UgKzyyEot9/OJ347zi/J5mViL7kvK8yd7qr4j3PSnaX55k4OexWkkx6KiODxB7PdxyF9cq6YQEn6UoCTgnUAQViJRgGRY97W7K/HRkdiqwc97TqY2y8ZiH0ze4hlpllMQPkGT9dBwgIXkkMTc7x/DIMDFGLApJ+NJB7BLiEu3uDJ32NJuv/xW2Y5I1g4GhNY7hPGGwDkmlRK4F1sKiYREwDzGjs9SjXk+hXoVaRtFtU8y1qC1GFCKowq1T6zn7M4Umd5XsS8rzJntrzUDCuc+NdtTGBazaIfZn+INGIbaIC8skKyXqiS13lTQ3DeJ8C+SxWKW1bCzNJezcHthye4sd0yWzc8byomPRDfCM1/wth5/8aGJSw2IClmLOE1xJxJA8MUampqYYHxvD+4QyGE7CRQEBqQBXoNhl6tYb+fL73omfv4u0PzA4KDZNVFi3oU5zQ8roOFT6l3BqQUwI3QZ3/H6FTYelWGK4vipq1ClXusRtc2TdiKJn+/Ior/hig8tv7ShGY19RnjfZWwePZXzt+S1bNzFHUY2kG9fASEJcmsMtd6BTEEjZPBnZcOAQyiJLc5FtkyU33djijtthbtpoL3m6JJRKKHyDsaOO51XvfS9qDAEJBkTEHiqIgJMnxMDUzikmJiYAYQaI3XrIgWSYGXKG7/X47ic/yVX//U2sWKQajVoUaaVgYi2sP6DG+oN6HHhIwvBIhledO26b44BNAV8Bq3jUqKG+PsqZeWz7Ikkplso+3vudCc69uKUiGPuK8rzJ3nASDzsosS88c4aBvEWv35E+cBNaWcCWl6HVxczoqMFtNwSaa9dw8++2ccPVBZO3RNorgghmVSxmlM7Rc46iMcgTXvpqHvbUpxJdiiTAMAwwwJCEU0JRFExNTTExMYEkQEQMVCLxBw4nSCVuv/oKPnnOW6nOz1IPkSSCUeIUiVagtGTjweLoYzOOOWYNC3OzbFjbo9IXCVaS9FWgL8NGhuneuI20XRBCymd/toZ/+n5Uu2fsK8rzJnsjcfCkI7194smLJHmXYhzSZhUW27BsxF4AJezaUef668WWyTa339ahteyIRQUJJIcBwmEkFHiK4VFe/sF/56Djj8FVUpDwzuGdQxLeOxA45wkhMHn7JOvXbyDLMsAAEULJqhgjFg0BndYSM7vu4EOvegVs2UItFpShh1lE7CboJcIwqr7kwPWe445psHFjZOMhHp8WmOtAn6C/j2KqhZ/t4IuEH1yR8upvDmmxK/YV5XmTvZF5eOnDEvvHx86S5IFWo0d9bQNbWoYWxCKj3U65+rIOl1xi7Jo2YmC3BMkTZTjvcM7h5HCWQprhmuv4hy99m/6JMfAOE1iMWIzsYYDA+4QYA5OTk6xfv4EsS5Ecf2RmSIBxtxiJ5RIfftUr2fbLS/HdZUoKQoiYGQiiPJgjkSC0GewveciDKpz4qApjTUO+Q5kEXD0jLJa4pRJfJlz8G89Lvz6kubZnX1GeN9kblUS8+fTEXv6o7WRDYtkVpHWHLz1lK2NxvmRh1rjltxk//0WLEGtARM5wXkDEOYdzjlWOFEtS1h7/IF776fNRo4YRMQmxm7GbYdGQhHOOMgQ2b55k44YDyLIUw8DAMCSxSgiLBiZEwdff+04u/sJ/UY1dUEAShoFBLBNCiAQMnENWcMzB4tFnVHHVWUbGaqT1El/tkURhnUjsea68vsELzq1rru3YV5TnTfZGLRV/9wRnz3vkXTQGPR0iMUaKNvQ6ol6vkyRVrr68w4XfWKEoEnyS4l2CZJgMMJwTZuBIsSRjzQkn8LrPfAVqNQzDBDIQd4vRWOWcI8TA5s2b2bhhI1mWEs3YwwCBWCUwwAwouOjDH+THn/k0SW8ZVHI3IURS1okUdN0KXQwBp5xQ5UlPa2B+lpWViKlgYCjiADkoQ8KVV1Z48Zf6NNf27CvK8yZ7o5aJd/9Fas886S4qY56y10PREc1I0hQzY9Xttxqf/3SPXs+T+AzJAyIizCKSWCWDIvE0H/owXv/vX8FVG0QzTEKAMFbFGJHAOU8IgcnJSTZu3Eiapvz/GasksUeMmAp+9NF/4Yef+g+STptoJeKPRBIroILS9QgSWI+nnNnHQ0914OaJZQoRnDoYu1XBhQq/utzz4vP6Ndf27CvK8yZ7o5aKdzyxYs992DRuXSC02qSWYIC5CIhViwsp//nxLnOzKUIYqxzBEgQYhiREoMgcjSOO4e8/9y2q/SNEEybADAESmBkQkTwxRiYnJ9mwYQNpmoIJOf4g8keSwCIWOpz3zr/lyq9fQKUoMQuI3cyQhAQyY5WALOvw7LOHOfiIEnMLWBQ+OrCCKAg1SHsZv7os4YXn92uu7dlXlOdN9kY1FW9+bGavOGWaZIMRl1fwlmICcxFJgOh1a5z3+RUmb/UQBRgxeqISkDAzJOEIkCUU+Vr+/rzvM7R2PSjBBDIQhmGskgxwxBiZnJxkw4YNZFmGRZADMwMMiT0kYSEQVxb4yKuexx2XX04aAs4ZyDADBzgi4HByRGszOhZ4/kvWMpovEbUEQbgosIAJyjqk3YxfXuZ50fkDmmt79hXleZO9kSXilY/K7E2P2UH1kCosL0BXmIR5QxIgoI8fXWT86mfLlIUwAiIFMsxAEoYhi0SMMDjOi//tsxx6yimYiShwCDDAuFtE8sQYmZycZMOGDWRZhkVAxirJWCUJM4OiYNfmLXzgOU8mTu/Eu4gokYSZscq7gCxFONAShx7pePbzRkmyBSz0MDOcARHwoNGMuCtwyWUpL/3qkObajn1Fed5kbyQOzjra2weftpP+44bQyiK2WBDZzbOH955oFW67eZCvfX47rZZAAUhxVDADkzAzRMRFKLIBDnva8zn7bf+Ar9Qx55AJscowDIhInhgjmycn2bBhA2macTfDEGBIBhirYq/Lr87/Ot/+57fjO4uYAlDyRxI4RWQpkkgqy5x2xiCPfHRAtkwMETOQAQakQhN1wp0tvveLKm/81pAWOmJfUZ432RtO4hGHZPbxp29j5MSM1HXRzoJYQkyE5PDegzyLK33818dmmdqWIgkUIWYYYBKrjEgSAKUs5UM8533ncNypT8YnDaCCEKvMDLGbjBACW26fZP2GDWRpCk6YgfBEGaZAoTYKkembbufjr30D2nwLskWCM8zYw0tgwlkV6KGkQ1Yved7Lh9i4fgWsCybMDDNRmuGGEtxoldbNHb7wgybvvyioXRj7ivK8yd4QcMja6qVffMHCyc3j2mRDhtvRJbQj0QkhfJIgicIqXPJ9z6U/XaYsUoyIWYLkCGZIonQRGaTR0a163EHreP5b38/Bxz+CJGuAcyBhGH8UQ2RycgvrN6wnS1OEIbGbWBUpCaFkbutWzn3nu7jz4osZLFcIvkXpDYsOScgMIZxVESVKWmw6LPLMl+Y03AxmAcyIETAITvhmH0Uqlm8IvOvLY3ztqp7KyD6jPG+ytyYGEz77omBHHbtI9aAKbF8kLBZgIInEJ0QMJVU239zPBeftYGHGI8sweVZF7lZ4A4xKdASMdprQt+5IznzOC3ngo0+jvmYNSjMkh5ywaMQY2Ty5hfXr15NmKcK4mxF7PXrzs9x23TVc9PnPMXXVb6h2V0hjj9IXFD4CDhAyQwhvAnPU+js85kl9PPgUwxULYAZmmIFFiKkj2TROa6nH9PWOl32qr3PtHUUtmrGvKM+b7K3+qnjnU0o786QFhh86imZXKHYuotJwcjgJE1jiaC8P8e3z57n5+oBiH1FgZpjEqkhEAhcNBIaDUCH2DTB65AM5/glncPhDTqQ6NEGlVsOnKRYDd23ZwpoNG/BOmBndbpfu4iJ3XHs1V//0R0z+5nJ6M9OkocQT8RYxItFBKRAOmSEgVYITjK1r8YwX5IxOLKLQgWiYGRbBIvj+ChywloXNC9x2TZWXfDbRtrnAvqQ8b7K3Ug9/+WBv5zx1keET6yQ+Um6dg+UeHofzjiAjyogh46Zr61z0jUW6rQHKaBglJjBzJAYiEmSYBBg+Gj0zCl/Bqg1oNKhPrGV8fA1JrUKlr05raZlatYaFQLfTZsf0Doqd2+nMzEDRpeJFKHrgDAE+GmkUEQjOsUpmCJFYivctTjwFTn96jVAskTpQjBAgAqWJbG0fNt5k5v9s55eXN3jT15wWO8a+pDxvsrecxMY8Pfe8l7SfM3ZsYOCACr2tu2BHl4oHJY6QOEweXGRpro/vXbDILddWiWUD8y3kImZVUCSqZJWiw0vEGBAi4gCRRhiNCUO+wrZihVZiOEQSRFWeAV9lpWLMdhcJimAREyAwEwJMQoABZsYfCZFFR3Njm7Oe1c+aTfOYjBAcaS/ikoxeWVD2QfXgEZbn+iiuXeJd59X52nVRRWSfUp43+VPUUvjIM2UnP2SW/FGHYLt2Udy5k6wXkBMxdSAhVTBVuOka47/PX2JlYQR8F9TBHBieiMMhiMIBZoYkzIRMDBfi9Mp6xn2dO4tl7mov0o6BzCeMJ30ckAyyUjG+v3gj82kBAjPDJHpOIPF/Y2YIqKngUadnnHxGSlpdwKIjBCMpIqtaEtmGQZKJERZuWWLqmoJnf3rgE3fOla82Y59Snjf5UyQOnnNS3V57+jTrTtmAq/bo3bUN5laoIIIDlzigSrSCbmuE71+wwNWXB1ySgUqiCiIeyFjlo0cYQiDAhMwx3BFnWpOhJWPFiZ4zLILHkZmoFI7lkZTvxpuYrRSYwMwwQXQexB7RwDAksco5hzA2rmvz9OdOMLp2DiggeKzo4SJY6uhWPZX1a7H+MeYvu4Mf/jLjzV+P6hTsc8rzJn8KJ1g/UvmPTz27+7Lm0V3Gj8mJy7OUW3eRFQZy4MB7hykQQh/TW8c4/wt3Mr0jIlUwBUwOkwczvHm8hJkhDHBgjr7Cc8TKAAd0KiRBZNHhowhORIkQIjv6Ar/u28ZCtccqM5CEGSCBGSAQmBmSkKBSiZz11Iyjj0vIal2gSyyEyhJZpHRCE/24sQmWt7WZucU453zPT24qVQb2OeV5kz+Vd+JNj63Z2Y9cYOxB/fhGoNw5RZxr4yzBeUNJAAliSlmM8JtfF1z0rVlCr4YZmBcmgYHHIaDE8ICPBgiCY6hVY12vwmBI6AseF6HnoZeIlgV2pj221mYps4BMROcIzpABAqIhCRm46JAiPu3yoJMGOe1MT72xjGRAl1gIFwQqKRKRblpD9H0sXDfHFTcO8JpzSy22SszY55TnTf5UEhw+kV35+b8sH9w8vEt29DC2sovirjnUSfBZBEXMCTkBKUU35wffXOSqX63gqBGA6NjDRZBExxtpFOqVuCyh6zyZNaiVotYO1EthIdJ1RlH1LKgkNjKKYoWGHBSBkkg3NZwZwtjDIDGPD8InbTYcFDjrWaMMjS0j38NhxBBQdCh6Sl/ihysoHyfsMlZuMt5ygeeb1xSKxr1Ced7knpB48Y+PTe3sR7ZoHJmR5FBu3YnNlfhEyAMCJEwCMpaXB/nOeXPcdEMBVIkSSCgaEnRdxJmniA4GB3jYWWeSDo0ys30nC3fuYH7nNLEM+GqFxsgAA80Jxtc38Sttrvzej+hO7UKxR/QlSYyAIQkMXPRkioyva/OEp/ez4ZAC6LBHMGKMeAQB2gOO6sQAhH4Wb1zgt9eIF3218bS5tl3IvUR53uSeMjaYvu5jzyo+fOLxLRqHD0B7nvbWRZIgEu/ZQ4CL4MCswtzUMN+9cCe/vwViaABCZmBGz5dESyjqQzz1b17Pyc85G5cNAkJlIHYL5nfNMJSP4tMESxNwQHeZm378Yz779rdhC9N4CpwFJBFjJHEOFwuaa43TnzzAA45axCjBHBhYiFg0nCAGiOs8yVDO4u/b7Lipyhu/nHLFHSbuRcrzJvcU58STH4y99YxdbDjE4zdUCLuWKU0QHw0AAAdbSURBVKcLssQjgRngPDhHdAVOFWamKvzg2y1uvSGhLB0OBxYprEvPVciPfjCv/cSnqaxZh1OCmeFwlBaYm9nF6NAIqU8wCUkEM7rzM3zub1/PrRf/kIp1cNFwYjcjTURzXcnpTxxi4wMKXLoEKpE5YgQLBmbgwCrg11TotFJmbgt86+f9vPf7iYrAvUp53uSe1KjAOWcU9rQTZhk6sp9QL9DODuoZznmQQBCdMJUIUVrG4uwQV1za4tcXL0PRj4UuwXUpVOWos/6KZ73nX8n6BymsAAfeHKUFZmZ2MTIySuo9exi4mBB6XS76t3/mks98DLFElgnM45MOhz7Qc/IpwzTXdUiSLoYhRYhGCAEMzCA68CMZllVpbatxxdUJb/yKnbNjgfca9y7leZN7khMcnLuL/vWscMbRhy1RPyBDvYKwvIKTkHOYE0EBOYeZgUS0Cu12H7ffHLn6snnuvK0g9hxt1Tjiac/kOe/5V5LaAFjkjyxGZmZmGBkewSWeVZII5rCyw/c/9H4u/eRHSVnGpSVjaxzHPrjOA09IGRzq4CkQfxAjZgGLhhmYgatmqF6jM9/hjtv7+YcLKlw2aSoD9zrleZN7Wurh2HWZ/dNT2hxxUEk2GFDZJRY9JBEFOAPnMAwcRBmGiLHK/FSN237b4fqrWkzNiw2PewrPedeHyOprkAki4EQsA9M7d5KPjeGThFVyopBhvTm++5F3cdW5/8FEv/GAIxoccWyddZtKnJvFy1DpEGDRwAyLAeMPJFyjn9CqcOfmwAcvSvj2dYk6JfsF5XmTP4fUwyOPrNk7zlxm05oFKoMZsdchlgXOCZxDTiAjKIADcyAHLmYQ+2gXo/zuujm2FGs4+RlvYvTgk8H1IWOPzsICd2zZwoYNG6kPDWESyAjlCp2p67n0gg9RXbiOE44YpX+4BL8LqYUiKHgsGA4hA4sRiJiBAc47IlVWpgb46PczPnVlUKtn7C+U503+XBIHf3G8tzc/fpZ1eUmlYlgoiA4SlxCdIRkoEh3IGatEhlQl+BW8q7LCGpbiBO2VEWZbg/RKsBhJ0pSyLEnTlFAGVnlvBNvGmpEOo415am6K2FrGE7FY4gTOhEWHRZA5IGIWcYBFw+QIQays1Pns9yv870tTtQqxP1GeN/lzck48+UGJvf60ZQ4ZWiSplvRS8HI4B1LEHHeTBwnJs4d1EBBJUNKA2jDtSh8mz6oQApIDhMWA9wkiomIBFYu4coUk9nAGFjIEGLsZuwmLYAILAQmci4TCU8SE+eWUL/4446O/qKhTGvsb5XmTP7fEwWlH1ewtJ89x2Lou6WAbSyLegRngBAIT4DxmhiPBFWAYJEZMAyQJZlVWmQUMA4xVpogwJPAWUBQEB0FIwjBQxCxixm5CCIsiBCB60qJC7InNCyn//jPjK1emahfsl5TnTfaF1MMx63zxD48PydEPaNNoLJBWHHgHCpiLBAfIwMCZp7PdyJIEVxOqRqIznEuRwCxgMswiq5wMHEhg0UHhUcdhy5EQS8qRiK8YiQMkiKAooIp1PUXXUSxV2LYj4z0/Tfj5zT11CvZbyvMm+0rqYdNY8rPnPdxOPfPIFcZzSGpdXL2ASsASwzAwEJ7eQkpvscQ6gSQYToZSj5yQQI67mWGAxQgGvmvEIEoJX/WkgwlxuAAXcAIBioZ1hXUTinaV2Tm45MYan7k4nb9huw33Avs15XmTfckJ6hmceXRmf3Vc5IiNizTGS7JRw9dL8AEQUQbJAOo6WI6Uc23CcomVRigjIYAwzNjDHDgn0tSTGfj+FAYy6BdWB5IVemUkNYeLEWuLMC9WZits2VHlwss6fPGqPq30RIjs95TnTe4NzonxPv93L3hw75/PODFlYHSJfKJNbU0GVQ/VhOhFWYC3FG8pFA4rMuh0Cb0eGJgZhiEJX8lw9Sr4AmWGuRKsAB8wCkKZ4ItAe2qZpe2wMt3PT66BT19a/c+t8/aSMor7CuV5k3tT4uHQ8fSaJx7ljj390EUOWLdI1qxiQzWq4/24Sh8WM5xqyGVAFwR4BxICzAwhLAYwIFaAALGNWRss0J1q0d21TGy12LktcumNA1x4jefaraZeyX2O8rzJvU2Ac7BhKPnMqZs6Lz7xiH6OWb/M6FCHymANN9BA9Qaq11Fap1JrgAwhDJAETsSypNduo7KDOh3i4hLML6FeZHo6cOOuES69aYaf3JT+YHLWPb6Mwoz7JOV5k/2FEzhB6sXEkP/iQzd2zz55U8kBa2qMDkSGG4E0KfHegXNI3E3sYYBFI3Y9rXaFmSVx+/YVrpg0fj5Z+dHWeXtcEYwQIRr3acrzJvsjJ/AOqinUMsdgzf1g3WD5uDX9kfXDCaMNMVxz+MRIEti50GV6WWybLdi1nLJtoarFTmSpE+gURhkhGv9jKM+b3BcIkBMOwzvwDtLEI8CAsiwpowjRMESMYPzPpTxvcr/7HuV5k/vd9yjPm9zvvkd53uR+9z3K8yb3u+9Rnje5332P8rzJ/e57/h8tolMO+6R40wAAAABJRU5ErkJggg=="


# Иконки товаров 32x32 (вырезаны со скринов, фон прозрачный)
ITEM_ICONS = {
    "epic": "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAHz0lEQVRYCcXBW4xcdR3A8e/vnDO3nZmdndlbl9mt0qUttgVXATtt6VSgyJaqbIkPvGBETNCoWZUoXvBBEkO9BJYQY3jgpQk++MCEBx3BGNMRzWgoRmEpsNttu51pd7v3ue05c875/+22JZFxjPWJz0f4gAltbNvSxciuPq6FcIkYbNAIPqFAtW4erFYao6b2OvAdYvHA/KnZ1dzU6aUTtBDayGbSjI0Oc20EEQPRoEwTh2R4+qwev1BeeCwsftLCoenVVt45vfjtk1MLz9NCaCObSTM2Osy1EATRAgieGNRJhM/MBcbffmvqsfryUjIUDJDsTjE9PfuNmdNzz9BCaCObSTM2Osz/S0mQmtsxcH7F+t7s2XMPlc6UY/WaSzwR82tV+5szMxeepYXQRjaTZmx0mGuhuURrQKMkZlWc0N3nL9aOOk5jV61SMyprjhsIWG/MllafOPn2+ZdoIbSRzaQZGx3mf9ECWoPWYCDUnVDvwqp+tLHe+IpWdqfynWYoEJlMdSUm/vjnqVeKr52do4XQRjaTZmx0mGvlawONJSuVQLq2bn69vj73CH6zM2wF/tabSj7TFbdeyr082SgUz9FKaCObSTM2OgxoQPhvBNAolFjUnY6waXZn7GbznlL55IOWIV3dic5f9HbFngkYzfMvvvwOx4slWgltZDNpjowOA4oNog00oIX3EQ0KwSfYuVQJ39mdGnhgbu5cZq26GIpFQ8c39SaOhk1v0tCO++LvpjheLNNKaOPA7jRHRocBDWhAAEFjoEWjRbNBlKAIm3UncPP8gvNjz3P3eV4jHIl2/KG/L/GzcMB9NYDrCk1y+WmOF8u0Eto4sPs6jozegBIu0wIa0BiAYGhhgxJwVTS1tKweXl5c/I7g9ViWWU71dR9NJELHAnq9YuICHrn8KQrFMq2ENrK704wdGmaDiLBBYeBICI8w6CCWGURpn3rDvX1xvvLDZmPtLssQHYtHXukbiH03YLiTpnaUgQIUufwMhWKZVkIb+zNpxg4NA4LGEnRkk0d0sxOIB9dVgKZrYmCBUjQqi/c2Vpe+gO/0WKZxctNAYiIRs39t6PWa4COay3L5GQrFMq2ENrK7B/nsoa00jaDhSiJdbSS+XK1FRhu2H/V9B+Wto9AYpoV2611B3eg2TLETqehzfSnjJx1qYQGaiMEVWsjlZygUy7QS2shmNnP40C5WdWKw5nQ9UF0xv9as20OoumFqGxMXLaAMCyWCVgozGK7090R+3hWpPRU1l+pauYgYvCeXP0WhWKaV0Mb+zHDffYfvumVx4fr7qvOhw82V+qDJMpZRwdA2gocKrdOMrOMEFMrsQFlRO9EZz/XG3aNRqzxpKMc3xOAKTS4/TaFYppXQxv49O/d+7p4HvlX557a7m7NGLGJ4RqwfvOYa1aU1mvY6bnQRO3GeZtcqOmRhBzq0hHvm+3rjLySM6V+GqJ8x0T6XKXL5aQrFMq2ENrK3Z774mT0P/lS/urk7tGQxdHOSkfu34yy5vPqrEzRO22hVpxYvs9x7Eqd/ETsBbiSuY6muud5Y/amIt/h8iPUVrsrlpygUS7QS2sjuOzB++GMPTYQLmwhXAgyO9PDx+29k5WyD116cxJ/1UesudqhKJV6iliyzNnSeerdHsCfmDfR1/D7szD4R0itFrsrlpygUS7QS2vjknoPjh3c8PBH+Sw+hapBwl0VnOo5bUazNriEVH8Mz8AU808UJrXJhaJK1zfOoQc11H0qdCTVPPR7yL77AVbn8FIViiVZCG3fccnD8yM5HJqy/dxNYDqBdcH1NzAjh2y54misELRrf8KimFlgZPk1j+zwdaSmF1ZkfRFk+xlW5/BSFYolWQhsHRu4cH7vxSxORNwcILIcQB5SnMXwNvuY/GBo71qC2+QLV4RLu5sVz0dDs4/HA2jEu0VqTy09RKJZoJbSx96a945/e/vmJrre3EFmJYdqC8jyUq0EL/04AMTRuxMPurbE2OOutXf/W8c7u8o/ikeqfuERrTS4/RaFYopXQxq07RsY/te3IRO/0TcRXUwTtAMpVaE9AC++nwFB4IY3Tuc5S7ym7svX153o2Lz0ZiVTntdZsyOWnKBRLtBLaGNm59asHtt/xdPLdjwaSa4NE1uOIayCeiWBwhWaDGAolHs2gR61jlWr/dI2dJ59KDq09bVi1Vc0Vufy7FIolWglt3Dqy9d59u277vpwaui21sCXYvTqE1exAfAMTA1AgGtAoU9O0XGodC6zET7vu4OyJ1EeWnuxI2q8gTZurcvl3KBRnaSW0sT+zM3lw3617Lkz5jwbL/bt7lrZHY+sDBJthLGUimksU2vBoBOpUwqtUkjOOu+ncidR259muXvc3aLsGSnNVLn+SQvEsrYQ2snt2cOSeTPjiRffu+ZL9sHWxf19y9cPJDrvHDLlRAr6JxsezbFajc1Q6S26z/8JfB7bwi66U/q0WvyLaxTS4TGtFLv8WheJpWgltZPfs4si9e3F9YpW6u2Pton/InjcO6nr4pqAdSRiugcaHiN9w46vTJKrl7qHQsa6klbfErRigDeWD9tFs0OTyb3K8eIpWQhvbhocYufkGQKGApqeGHNu9pV5xPqFd6cUXtPYIdFjVUNQ4EQjqC+GQ9Q8RWRIUptagFaB5z+tvnOPdmYu0Ej5g/wK6OrNOEoMpCgAAAABJRU5ErkJggg==",
    "flip": "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAHmElEQVRYCcXBW2xT5wEH8P/3nWMfn2P7nGPH5EYdKAl1KGSBQimCrEBoqVhaNibUwRjkadIqkLpJq6aKqRpIBa2vg4lKfZuQtpd1aMvKpjVO05IrCTCISWJI4iRc7Dg3X8/xuXyDh0p7+l77+xF8xwg4FEVBW1sbnqGSJO2uq61rD1eFfcFgsMXr9W4RBIEwxlCpVGBZVrFQKPRmMpkh0zSvi6KYTiaT7sDAAHgIOPx+Pw4cOEBVVd22efPm30YikTZKqcdxHMk0TZ9t26CUQhRFiKLoAig98ySXy/UsLCx8Ojo6eqevr88GBwGHoihCR0dHy+7du88pivKWZVlSpVLB8vIyLMsCYwyEEBBCEAwGIcsyCCFQFMUslUp/v3r16rnh4eF74CDgCAQC+unTpy+0tLT83OfziZZloVKpwDRN5PN5fItSCl3XIcsyvF4vPB4PyuXywytXrrzf3d3dBQ4CDkVRIidPnvxk7969b2uaFvF4POQZUErx/yiloJTCdV24rgvbtlmhUBi7cOHCr0ZGRv4DDgIOURTXRaPRv+3bt+9pe3v7LlVVda/XC6/XC1EUQSnFtxzHQblcRrFYRDabdRKJxI1r165dSKVS/wIHAYcoik2apo0TQlKxWKyqvr5e03UdmqYhGAxCVVUEAgE4joP5+XmkZlKYnplGOp1m+Xy+zBi7lE6nfwMOAg6Px9OkqmrSMAxQSkEIASEEhBAIggBZluHz+eA4DnK5HGzbxnOMMQiCAL/ff3l+fv4MOAg4JElqatiwMfn0yRPAtUHAAAaAEAAMz1FK8RwhBHAdMBAwBnh9MmRFuTw7M3UGHAQckk9penn7G8lcxcHS3H3YxiqYC1DmQiCAQwAGF4wxUCICjEEkLmxGoEdqIAi4PJ2cOAMOAg6f7G/atONgEj4ddmEJlmWgXCrBzC/CKzI4rguznAcRBOjhWlSsCkrFPMqlMqoiEVcg9h+mJu//EhwEHLLsX9+8re3mikGrgsEQamvXYiGTgRc2Gje8gLnZh1heWkRN9EXkFtMwbQuSHMB8KgU14FlwjNWPHkzcvwIOAg5ZUSINGzd/VrSkH9av34K1tXWYnRrH0uIy9h44gP5vulHMFdD2RgdSyVvIZh9DkjU4FRuutfoQ1ur7E4lEFzgIOBS/P9y86eVL49NPjje17EBNpBo3vrwOwSPj0I9/ioEbfZBEES1bX8PIcA/KhafwB4JwXddxrXyXqng+HLtzNwEOAo5AwB9ubW29NHL7znHmFSFKMpxyBQQSdrbth9fjQzabQc2aF7CynEZy8jYMswjm2pXqSPhjLRC4cOfWbRscBBzBYDC8c+fOS319fceZAEAUEH1xE1LTMxBhQaAeCFSAXTFAqADHsQG4gOua9fV15zVVuzgyMsLAQcChqqrW1tZ2Lt4Tf88hrtcjqXj9zXcxMzeFqbEbEC0XAhUBWGBEACDAK4kwDcOMNkTPB/z+i8PDwwwcBByqqtL29vad8Xj8L4ZlNoiChOqaGPYd+hH++Y8/I5eehiBQAC4YBERq1iIcCuFBMmFu2LDuvEcUL94cGmbgIOBQVRUHDx6MxeM9XYZlNxKXQiAi1je/gsbYFvT8+3MUy1lQOBA8fuze8xYmJ+9iKTtnNsc2nmeOe3F4cJCBg4BDVVV0dHTEvoz3dDFfqNE1DBgrWVCPgtf2vYOKbeDm4HU4loGXWveAugTLmQzglsxodM15yzAuDg0OMXAQcGiahsOHD8e6u+Ndq2WrMbKmDh5BwsriEmwGtL35A0wkE1hMT6P1ldfx31vDqFIDWEw/MVq2xH5XLCx/MjQ4xMBBwKFpGo4cORKLx+NdC+lMoyCH0LDxe0jPpVDKZRGsjWLHnv24f28IjmFheSkDAQwiw8zOV7edXsg+/mJoYICBg4BD0zQcO3asuru7+9NHc4/e8QU0IVKzHsVyGbZtQw2tgRquwmLmMcpmBR5qA5YFt2IO7Nq14yePHs3MDg4MgIeAQ9M0nDhxgvb29p59kJw4y6goUSJB0qpRt74F9bVrkZoeQ6mUQ2zzNsxMjCE9/xB+Hwb27W97d3Z2bm6wfxA8BByapuHkyZOkv7/vw7v37nzkEip5fGE0NLZi7boYHs/NIrswi6CuoWIYiFbXYXxsyPbL7rXv79393vTD2YXBgWHwEHDouo5Tp06RycnJX3z19VcfC15/6KUt7fAqQUzeu4Hi8iK0qmoE9BBSM2OQPT44lUJ+w7r6s9t37Pjj+HjSGRocAg8Bh67rOHXqFAzDWNv7Te+5TLb4s8Yte6T5x7Mor8wjGNChR6oxNZmAYawArgOR0tXtW1t/3RyLfTZ2fxyDA4PgIeDQdR2dnZ14hjxNP23v/brv98urhW2KX6YBRYFXkJFZWIRh5gBiA4S41ZHIrVe3b/8gHK6KJxIJ9Pf3g4eAQ9d1dHZ24jnbtpWpqam3x8bGPiiWSk0VsyI5Dnyu64IKMMIhfaKmri6xLhr9aygU+gJAKZFIoL+/HzwEHKqq4ujRo3BdF4wxuK4bKBQKh1ZWVlpXVlaa8/n8VtM0EQqFbjU0NPxJVpR+SskqGCp4JplMYnR0FDwE37H/AS6FXk5LM/AxAAAAAElFTkSuQmCC",
    "fortune": "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAJLUlEQVRYCcXB2Y+dZR0H8O/zPO9y9m3ObGe2LlA6032m0LBIWqCRRlDUhOXGCEiiXnBlQmLwyhuvjHplQuRCI1gggBHbQlssuABF2Upb2pm202Vm2pnpnHPmvO95t+f5/YQLNHn/AT4fga+YQIplWVBK4QvMjC8xM77EzPgSM+N/GGB8Tgjbsp2ecrlS9b1OOwy6ywyOmQhpAin1nh6Uy2UYImgigAjMDGMIzAQiBjOBiMDMYGZ8gYlAxDAMpdzsWK136OH7vnHfvqOHXnv74uy5PxAlF6IwiJAikNLf249atQrNBoYIxAQmhjEMJgaxAZEBM4OZwMwAA0wEMKuE1KCbLd1Tq/c+snli0/a/H3vjTJJEfzSs31ptNT9DikBKY7CBek8PDBloJjAAMgxjCEwAMYEoATOBSYOJQZAAkwJhUKj8XmXnH3Ysucv3VktR7HdyuexRZYn9Vy7N7keKQMrwUAN9vb0gIhADzAwiwBiCYQaxBpEBMYNJg4jAkJIJg1K6e5WVfUQndIuOgnIUBUK5tq71VE9Zip8//eknv0CKQMroyDAG+vtAxGAGQAzDAJGBZoJhhiZkCBjQZCoglmDhCGFvy2aL34mDcFfY9UsmjgQJQrFaS4rlwodL85eeW5i7/GukCKSsHVuLxuAgiBnMBCYCAzBMMIIdw2IgFu4EO/mvCcsZJ60V6cSySDYkyXXddrMYB6siTgJIx8LIyNg1bZJXLp777OX2yvJhpAikrF97I4aHRkCUgNjAsLCg7CFW9vqEVCNTrO6o9Q/dCitzQ5joHtZGggwiz8fS5SvotBbBxgckI1vI08hQ49jClUu/ur608K/rS9euI0Ug5cb1GzA6PAriBBqk2M6tl075AZWp3aORHfRDqkfdbt0kocUmASAAKQGdgLoetPbAiAFbYniksWQC75nlq/PPeO2V2YWFK0gTSLnpxo0YGx0DsbEiyFHkBx6yM7UHwxDjnhe6YdAFxQFAMQRpsACEsqBYQLIBMUETQeVsrF0z/PH8zImfUeQfbrWXwyuXLyFNIGVi4wTWjK2zjbTGtFP6JuWHv9fxzMagveqKxAe0B5gIZBIABsQEIQTAEkLaECILVhk4hRzqtdx/OgszP02ClWMrzcV4dvY80gRSNm3agrGxjf3ZnqFvI19/dL6ZbF9t+Q51fTgcwFExAI04DhBHAUAGSjEEC0hhgWUGJDOwC1XUaqU5i9rPtpcuvrB49eLs+bNnPKQIpGzevKNww8bJ7eXRiR8v+nT/hYsLhbybQTXnwBUx8hmFRMdorbbQbK7A6BCSEkgiCEMgKaCFA7gV5ArlZLBROuU1r/zp0umP3pg+9ekHSBFI2bJ1csuOXXu+Jaujj5xfWL2p3WqrnlIBaxp17Nq+CTnXwgefnsTHpz7DUqsFZoKkGMbvwKIYyhLQULCdGmSmiFqj7BdsfeDM+289/+kH/34FKQIpWyZ37t21e9+joVPfN389qHjNJpSOsGvHZnz3/nuRcW389cgxvHfiNALNkEohCT1Qt4OwvQKTdAEwHKcMaedQHKjFtYJ87+zxY899ePyd3yJFIGXbrbfv23nXvsdjVdm70opK83NXgSjEuuF+TG3bBMdxcGWpiXZMcPJ5FAo5OIIQdDycPXkaQaeFyGsBcQJlKRQH+mior9xeunBi/6svvfAjpAik7Lxzz/e337n3h8YpbV1uhtko1FhauIqsJbBh3RhGRkfRTQjLqx5iTQAIcdDBytIKdGRQymWQdwXay1cRBj6K9SoafRUsX/zsxZf3P/8gUgRSbrvr60/vuOPuJwPY1WtN3yLY8NodUJygXqsgk81gteOhG0SwLBurq20kSYRcJodCoYRquYT+3jIEx1iYv4go6aKvnMXihekX//zSiw8iRSDltt17f7D99j1PsFtYu9j04WRLotPxS1571dFxAt/vQicaUkkU8gVoraEshVwuj0q1ir7eGgb6a8g6Eq32ImbOnITDMZZmZ1489NpfHkSKQMrUrXeMb775jj2Zcv2W66uBF2lRimJ9d+h1G7ZyEMcJfN8HGYLjOqjUanAcBwBjcKiBsdEGhgb7IIVBFHl4559/88PW9ZWl2ZlXjxw68CRSBFK2Tt3sbNg21acypVEvpI4f6O3Kdn4Sh8lWKRSMYfieD601MpkMNozfhHpPHTPnz6Gvv45GYwBr14yglM+i4zWD4+/+453lyxfeXr587t23jhx+HSkCKZt3TGLdxs3SCMeKjCJt5B2Vnt6nOp6/27bsjOO4iOMErVYbzWYTa9auwfj4OK4tLcJ2LfTUaxgbHUY5n8PC1bmZUyc++mVnaeG15vyF5bePHgmQIpCyZccOjK7fgCBmxFpBkxqp1nsfy5eKj0mlRsulMrTWmJubw9mzZ2FZFgYag5COjUq1hmw2g6HBARRyWXQ67ZOXLsz8nLqdvzbnz3vHDr+BNIGUyZ1TGF23HqudCJGRENIdMUI+1g3DxyKtR4kNHNdFHMfwOh6kFGAWgLLguhkwGeTzOTgSyGXsVTLJ7weqxd+0rs1Nv3n4daQJpOycmsKNN22AH8TwggR+pHd73fCphLGboDKxJlTKFSRao91uoZAvIJPNwnFdtFptBN4qMo6FUs41xax7tVbKP1stF56du3Jx9o3XDyFNIGVqchLjE+NINKMbRbje9u/1gvDphMUuw8KKYoN8rgDLsrF47RrKlTKUktDawPM6cCyJWrmoq6X8fMFVB+u1yu9yGffE9PSZ8NCh15EmkDI1NYmJiQkIZSGKNdodf3OnGz4exMkDUWKGu2FkCWHBdhz4ngdmhuNYKJYKiOPQuLbyyvncfL1WfbOnUtzvWvJ9ARHOzEzj4IFDSBNImZqaxPj4BJRlgSEQaZPvBtGU53cfCqJkX5ToEWPIklKAiBDFMZQSVCjmOq5tz2Vd55NiIXe8Wi6949jqhCWlz0Q4N30OBw4cRJpAytTUFMbHx6GUgpASBAijqRRrvScI4yeiKL7TGFNgARgyiOMYjmPHxWL+bD6bfTvjOkczWfe4Y9nLUiASQjCYMX1mGgcOHESaQEo+n0cul8MXhBBgfI5ZMlAg4gEiqgBQ+Bwzg5khpCClVFdJ2RJStKQQPiBI4P+CIECr1UKawFfsv5U17V0/gHahAAAAAElFTkSuQmCC",
    "heads": "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAJeUlEQVRYCcXBi2+d5X3A8e/ved/nXOxjO3acpGG544SiAhODQbtSRgNdaaYC6oUxRse2oHYDmk0ZKhXdVrSNrmJSVDFNU1GHhmAEytIWEK0o4RIGE4yEECeLQ0KMb7F9bj72OT7nfc/7PpfVrSadnf4B/XyEXzGhiwCBKDp5hF8QvKihvv6+TSMj2zcPDAwMW2sDYw1Ju02rFTE3P1dZrC2MOmcnwad4EDwrPL9M6KJEyCqNx7NCEAQFXmElyK1av/HaXZ+94aadOz951fDg0IhJ0zBJE+I4ptFYZmzsxOnR0XcfHfuf489Vq8UJ044bYAGP9/wSoYsSIRtovPf8guA9PxOSLwxvvfu+v/2bS6/46GdWDQ4MZiXQPkklaidY51AKms16vLBQOnP6veP//dqrB185dXL0v+qL1TnxNnbW4D3/j9BFiZANNN57VnjAEiC60Ddy4WU3fOuhR/5O5wtbtdZoAlr1iFq9RZKmhBryWY9Im3Zcj1vLi3PHj7792g+ffnL/uakzb3oT1/He00HookTIBhrvPSucElAZwt61Wz99021/ecfdX99tReWCICCUgNpCi3K1QZp6BEcQGHToCJXB2RZLC3PV/3z5Jy8cOvjs9+vl6ZdwdpkOQhclirzO4PGscCgsmjVbLtpx+5333n/VNbt+34ngxINXVBZaVCpNvA0BhYhFvCUUi1IJcVT1sxNjU6+9eODFE2+9cL9JonN0ELoEStGTyfJ/vA9A9+qPXHndFX+85777Nm4e2eUEvECUCPPFZVqRwVlAAvAKwYK1IFCcmyaqFaPy1JFzB3/00I2NpcpJOghdAqUo5Hrw3rPCSShhfuhDn/vSnbtvvGX3V8Ke/AaHx6NYrDtK5QjjHMY5PAp8iABKhLgNx4+eIEgjgnSanz79zctrlekjdBC6hEFAX08veH7OSCazbvOFV93+p3v3/uYnrr3OBzrrvMf7gErFUF1IMM5g8XgER4hSIc4q5udqTIxPgYnJuhKvHPj65bXyxBE6CF3CIGSwrx+P5+fCfGHn737uD7+y5569/cMf2rYcKTHWYg0UqymVWkpqPc4LTgSPgIS0W57JiXmq5UV8Ghmi8eYbz/31b9drM8foIHTRYcjwqiGcc6zo6RvasPvOv7jrpltuu8MQDlcXE0Kt0aHmg7kG89U2xgQ4r3EITsC7kEY95fSpKUzbglmuzY2/+s6J1x/6chJVx+kgdMnoDOvXrMUYg1LCyAWX7Przr91/35YdF10RpU5bEvp6e4iiNrXIM78QE7UUaaoxNiS1QuJCZmaqTE+WCL3z8fK56TPHfvjs1MkDD7i0OU8HoUs2k2Xj+l/DeYcS0Z+58eY/uu2Or96b61t9/nKU0D/Qiw4czkA9ciw2LY1GQmoC4jY0llMqSylnJyvUKhFim0l57ujrH5x4/rGFqdd/4Excp4PQJZfNsXnDFlaEWm/Ye+83/+ryT/zOzYlXgxaFd9Cby5C0Yxbrbdop6FyWuO0IwgxR7Dl6ssjo2Dy2rbBxsTh59uAjs2cO/etyaWzCmbalg9Aln+9hZMt2HGFO96665p/+5ZFvb9qy8eJm4tXSckwcx6zq7ydUQrOZ0ohilprL6FyBhVqLXM8AoyerHD9exDswzfcOnX73Px5sVMZeWSxNRCZN6CR06e0p8OEPXyqiC+df/akb9lz/2c/vLhQKPdmcJggVXhyz50rErTZaZ1A6oKd/gLYR5op1IhPy9tsTzM7GaHG2WX7r8ZlTz/29iebfn52ZIEnadBK6FAr9XHTxbxX6hjZdf8vtX77nvK0jV2ayGXJayGUDnPOcmysRZrKEYUActxGlaSfQthmmZpd56/BZ4hYEtlGcG3/pwXjh8GPKLJbHx88QRxGdhC6FvgEuvfy6dRdcctVd199485/1DQ4OhwEU8poQj8cyPVtiYPUw1hqMSQiUYrHeIjZ5joxWOXlqDkFwranR+bMv7tF26g0xDXNqbIxWq0UnoUtf/6D++M4vXnLl1TfcddnHr/69TDbTk9dCqIQkbpPP52lGEV4pWu0WPfmA/kKGZstSb2Z58gejlGptAh/HtjH2cn32jXu0L4+JaXHs2HGWm006CV36Vw0P33Tr3ruvuf7mz6/btPFCxAWaAG8DqrVl6kt1egtZBvrzhFoRasNgX4aopRg9ucALr35AbAWbVifd0tHvBK0TDwd+sUXa5s23jlBvNOgkdBlcvX7Dn+x58B8+tnPXp3L9hXUeT0BIHEGxXCdup4ShoJQBseQ0rFk9QJpkefnQCd6fbgMeF507rZrv3p+z4/uFFs4YXjv0BotLS3QSupy3cfsF33jwqe9v2L5jm+iwoFA4H1KvJ5TKdaxTOBEQi+DRAWS1ptHwHH7nDJXFhJykJoim3snZ9x7QbvpZUQZjHC/+9CC1Wo1OQpdtOy7+jX2PvPRmWOgLrYgEQYY08ZTLyywttkBlsCJ48Xjn0EGIM56ZmRqTExWa7cSGpjqRM1NP9auZf1Nm/owECmscz//4eRYWqnQSuoxccMll33n0pcM+kwOlSS0kiaO60KLVTEEyWBG8ePAKRUirmTJ+Zo65+SUUaSvjZ5/q8eP7BvTCmDc1qwKNNcIzzxygUi3TSeiybftHLvvH7z5zWPf0ozJ5jA9ZXIpYqrdJU8GjsSJ48SgJsSagXk85dXKSqNEmoNUoBFMPDwST+7LUZpVKcF7hjOLpA/spl0t0Erps2bbj1x/Y9+ihnlVreoNMX5hKlkqtSTNyOKfxaKwIXjzegbEBxWKLs6fP4dqWDEuNgXDq4aHM9D5NY9aLwws4Izz51BOUyiU6CV3Wn7dp49e+8e1vbdgy8jEV9myJyQRLkSNJAzwZHDkcghPBe08rVpw9W6U0v4QyKVkpzQzq6X8eyha/F/qo4sTj8HjneWL/fkqlEp2ELmvWrNNf+OIfbB9cPXzt5s1bd/b2r/6oDfNr40SpZuSwquAJcqkKc4kR7UtVw7HRc4gF7ZeXcn5i/3mDy48VgtophUmt9xhnwRke//cnKBZLdBK6rF27jltv/VLYTpLBbCZz4aYt53+1MLjm09aFfXEqNCIxxun3jQ9P+SATlRdjpmfqBKLIqubsgK7sH+qNj2uaicLiAIfHGcPjjz1OsVikk9Aln88zMrKdFdbaHp3JXtpb6D9fJMg5LyTGW2N8JbW+6CFNjCVJPUoJAbaVDdNJrVxLYQHPCs/PeMfp02eIoohOwq/Y/wKQIhls3NsGPQAAAABJRU5ErkJggg==",
    "large": "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAH6klEQVRYCcXBaYxdZRnA8f/znrvf+947d2a6DfumgUhSAhSl7LRoE4yISm+RYFBUvgHRhGjhC3HBgMgSNMRgTAkmfjKaIAiJhKg9VwQpcA6ydJgu0+nMtDOduXP3c877yJSY6Plg+o3fT/iYCSmFQoGLL76YEyL8F4fg4chmB0O29Fa6ny1l3DI6WDGZzNyBmUN/m5k9/AEpQoq1lkajwYlQEVYJDqMOxSMxlcLRpeGdy3Nz9xS06+K40xsmcmz/of0/3H9w6rekCCnWWhqNBidCheMERVRR8UhMoXC0PbxzZu+793SW5uvOGGxtAzMHJ++amZ58lBQhxVpLo9HghIgCCiqAgGSIyGxY7Ha/d/TggduOTB+stHs9bG1N0u0cu3v6wOTjpAgp1loajQYnRBRQUAN4KB79xF0+t3j0kbjX2zjsdOh02q1CsfLu7OGDP943tff3pAgp1loajQYnQkUBAQTRDINYafV6W9vt5Z9rNDwb55aLxeIfrK3+5o09r+15O3xrlhQhxVpLo9HgRKiAiKAqJA5p9+J84ri23Zp/xCXRWfl8YXe9Xv9BPpt5oen7LgwC0oQUay07GttZpQj/lyhgcCr0IgrVan3TYNC98sD+924XkbHRsfEnqpXKo5pEM03fJwxC0oQUay07GtsBBQzKhyThOPUAAzhAMSgOQ5R4XqvPutNOnbhj7tDUVxeOLZSK5dLL42OjD2gchahGTd8nDELShBRrLY3GdhAQNSgKEqOSgOZRDEKCoBhVnGa93lBOX2wNv6Su9wVx3Y25Qunlar32YMa4v4pzER9q+j5hEJImpFhr2X7zTaAGMHxEERJUhFWigAqJGJD8aHu5//Ujx47d7Rk3ns/IzOiasYdyOe9pTaKWoKxq+j5hEJImpFhradzcQBEQARRVRRBiPJxm8bIlYic4cVmT6Jalufnv9Pqtq4wxK7Va7Vdj49XHB4PuAVHnBGVV0/cJg5A0IcVaS2NHA0RIBBzixZpZFzvvlETzuXxpFJU8DkiiwVh/+cjtvWPzV5B0i5l8/rX1ExP35rzkz8Nhz4kkiIIo+L5PGIakCSnWWr6y4yYiMQxMbjTOlD89UPv5QZTZNOjGZY2GeMRIkiBO8kTdDTJcymclaY+uqT9ZrhZ/4ga9I2iEiGOVKPi+TxiGpAkp1lpu3LGdtpcvrZTX3pCMbPjmistd2O8PyzpYMdlBl9xgQKbbQ/oxXpTgqZL1cq216+xDIp2HJR50DBEiCaIc5/s+YRiSJqRUrJVtt94yfmx8/efijZffszyy7pNJxsuUXA+GKwx7HVxnQHx4nszcAqUjLTLtiKyW+pVq9neV0vCB7HA5lKSfGHGIcpzv+4RhSJqQUqpWi1fd8e3t8plLb1vadMWls8VCpp7zONMoURJxeBizMBgSLyyT23+Q8tvv403NkO+I5rOZufF67plcb+YXXtTd5ymJKMf5vk8YhqQJKcVarX71zvt+arZed8PUOZ+oR7kMl2YM14mwCDyfxLzulHakZHttalMHyIWTFN7dT26xpevL+VnrWg9re+GpgugxUTAKu5s+QRiSJqQUR+obtj74s2fja649970Nawsmm2GzZ9giMAs85xJex7Cigqij3OtSnFukvCeg8M4kGzq9eINEL8YLM/cXdNhEwSjsbvoEYUiakFIaHT1j2xNPvtfdfIU3tXZU+lnhZIVzPI9FVcI4YtbL0kdYpaLkEmXs4Azl1wMm9k1zVjzY52b338vK4jMGwSjsbjYJwoA0IaWyZs0ZN/766Q86F13C3lHLrMSoMeTw6An0gAjBoSigKmRUqMUx6w8vMP7Wv5jY9/607n1nZ6GzvMsTAYVms0kQBKQJKeWx8TO++MunJuPLLpepsRGmNaHtKTEeEUKCsEpxHKdCVgWrykQ/Yt3kFLVXmtMEe3bazsouzxhwSrPZJAgC0oSUcn10YtvDj73INVefNX3yRH7eKMtADyEGHKCsUlaJQkaFqsI4sH5ulspLL02bV1/ZWVtp7cp6Hig0fZ8gCEgTUoq1kdEr77v/Me/aq68/+qlza/MZwwpCX2EIOJT/EBFUlYxCBagBE8tLFJ97YTr3ir9zrN3alfUyiILv+wRBQJqQUqrWypvvuOu24UUXfWtpy2XnL45UaYmhB8T8LwEEJauOolOqiWPtzPyg/KcX/2LDN35U7668lDUeAvi+TxAEpAkpZVs119x6+9lLp5/53da1V36tc86ZucVKkR7KEEERlI8I4AF5ddjBgJG5+ci+Gf6z9Oo/Hhk7Ovd8tT9Y8ozBALv9JkEYkCakVKzl+h23FBYqdvPiued9P75g4yXts88or5TytDNZIjEoYABPIZ84Kv0BtbnZQWHPG6+V3tjz+MjC3LO1JG5nI6eeMRiF3U2fIAxJE1KstXx5+030PFOYt7WtK6ec/o3hBRdu7p16Sn25XvOiQhZBMLEjmyi20yN3aDoqvPnW30vvv/9EfXHxj1UdtrI4XOLwRDAKu5s+QRiSJqRYa7mp0SACup6pLBdK57XG129zJ522ZXDqSedHI5Wal8vixQm63CV/+Mi8d3Dfm3Z25inbW3mu5OJWwakKSuIcRgSjsLvpE4QhaUJKoVDgok2bcKxSYjEMTPaUfiZ3YSef2xQXcmvwDMYpXuQo9Af7i4P+a/k4eiVDsiCieMpxqoqIIAqTH0xyaGaGNOFj9m/QHPJO16xUsgAAAABJRU5ErkJggg==",
    "luck": "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAHXElEQVRYCcXB+2+ddR3A8ffneb7PuT/PaU9bxmAXunZX3JKREARlRkE2KMxyW6mJxJDoD7g48U6CJk7jxB9UzFDjJDMjoMF4AVMN/CAhpmddt0IcY4x27bqVtVtH23Panstz/cr4A76/8noJHzPBoFAo0NPTQ5IkFnBbqbVtZ6lU+mQun1+fyWRQSpEkEWEYEoYhtVqtOT09/Uaj0XgROD4xMVEfGRnBRDBwXZfe3l4rlUpt7+7ufqqt1H57KpV2gzBI+b5PFIWIgFIKpRSWZelms7lYrVZPTU9PvzQyMvLn4eHhWQwEA9d17d7e3q3bt2//UaFQ2BmGcdr3fSoLFRrNBpYIYoGIkM1mcV2Xq/L5vI7j+Ozhw4e/Pzw8/DcMBAPXdVsef/zxn27duvUrmUxGRWFMFMfUlmvU63W0TkA0VxUKBTzPw3EcHMchCILo+eef/9XLL7/8HQwEA6/olr7+5NcObu6+sd/LeKScLLZSfESDiAAJIgIiiGiSOCFMApqxz6HfHXp24B//2ouBYJAv5kpf+l7fwe2bb+pvy7eTsz2UlUYpG0sshA8JiAhJkhDpkFgHBNqnFi0nv/3FoV+/MfDfJzAQDHJetu2hb+3+zY3bNu1pa70Gz2ohQxrlOFgiCBbCh0RIgEhHNJIlfF2n0WzOPvf0kaeGXjtxCAPBIOtmVvU+cc9r3Tet29zW0obrFEhZaZRSWJZgIYi2QIRYINYRQdwgCHyay/744adf3PfW6ycHMBAMsm6me/feu8a6bl5He7GDXDqPYyuUcrBEsAABRIQETagT4tgnbMY0FoPx5w4c2XeqfHoAA8EgW8h093z1jrF1t6yhvf1aCukCKVuhlEJEEAQR4apEa5I4JkoigjCmNlefPPKzF7556tiZv2MgGOTcbPfnH719rOtTnXR0XIObKZCyHJSysSwbEQsRi6u01sRxTBiGNMOAykyl9tIv//r0O8dHf4yBYJBzc92f6//0WNeOtXR0dOClCziWQjkOyrYRsQFBREiShDiOCcMAPwq5OHqRgT+8+uzpE2N7MRAM8m6+c8cDt55c+5nrCitXrMDLtJCybZTj4CiFZdmAhdYanSREcUwQBfiRz9ibZxn8y/Fn3x4+vRcDwaDg5jtuu/uWw6t2tPesWr2KYq6IY6dwHIWjHCzLBs1HtIY4iVluLlFr1hg9NhGd/PfpZ/53/NS3MRAMCm6htOPu2w6235zvX7u+EzfnknbSKFuhbAfbsrhKa9CRJk5iKo15Gn6DU6+/Nz05NP3km8feOoKBYOB6bumOez97sLjN6V/ZtRKvUCSVSqFshS02juOgtcYSizCMqFQqXJiZJJ/LceHEzPj54Uv7TgyNDGAgGHieV7pz950HU91x/+oNK0nnsoRBiK1sLATP9UgSjaMUs5evkM6kGT8/Ri6dY2m0MT45fGnfUPnYAAaCged5pbt27zw4m73Qv+3WTRRLReIkIZ1O4/s+2UyWJEpwHIdKpYJSDvOVOZrVOpX36uNXTlf3HR08NoCBYOB5Xsuu3Xf/fFqNP7bl1g12sVTk0qVL5PN5stksOtE4toNYFlprdJKwuLRIsBRy5eT8+NzY0r6h8vAABoKB53lOT2/PrvPJ2O9Xb1t57XWrr2VqagrHcVizZg1zc/N4BY8wCIjimEa9TqFQIK7BuaGpM5WJ5W8MlY+9ioFg4Hke9z1w38aJ4N2B9vUtXZ3rb+Dy5cvU63W2bNlCo95AtFAsFqlUKtTqdaoLVRoLYRROJS8sXaj/8Gh56AIGgoHnefTu6d04FY8P5NekutasW83cB3NUq1Xy+TzpVJrOtZ2kMxnOT04yMzNDo+7jV2LfrbXuX7pQO1AulzUGgoHneXyhr3fjxWB8oLgh19W+oo3AD9FaUywWyWZzOLbD9MWLzM7OEoYRzXqIPxf5bfGK/ZXziwfK5UGNgWDgeh73P9K78WLt3IC3OdvVdk0LWgu5XA7XdVG2Yvr9GWZmpgnDkCiKCRsxwVzsr7RX77987oMDRwfLGgPBwPM8Hui7f8NUdeIVd3NmY/v1bWQyGdLpNKlUiiROGBs9S71WJwwDojAmrIeEV/jghkL3d98fn/nj0cGyxkAw8DyPh/seLM0svf+MWqUfae8sqZybw3EclFIIwuTEJAsLC8RJgt/wieox9nxqZF3Lpi9OjJ4bLQ+WMREMPM9jT9/DUo+Xd1btK/vbN5VuzJWyOcdxsB1FSjksVpaYnJyksVyn2fSJlzVus3XohlL3njOn3psqD5YxEQw8z2NP30NoovRSVN2sr+fLxVXuo6mM3SoKmn6ADjQLs/NUZqsEtSCxqmquLb3ipY6WFT945+13F8qDZUwEA8/z6Ot7ENGaWCKpxovrbFd+oly7d745n2mETUiAho5ZkrlU6Ay1ZEuvFPLF/1jYk6ffOaPLg0cxEQzcQoHd9+7iI6KJdJxuBI17mon/WLW+9IlIByKWkBJVac22/jPv5P9kW6mzCIEgjI6e5cTIW5gIH7P/A4UGSE7t9riLAAAAAElFTkSuQmCC",
    "money": "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAG9UlEQVRYCcXBa4xcZR3A4d//fd9zzly6M7O73d3ublsLtFikXFoCawMYg6XFBgjRGFMrhJZCYuLMSlpiDDUSkYigxJ1VsIYEDa7YpiIClSqCpEjp0hZSkbKYAtWW0k7bvczO7cy5CR/4es5Hnkf4lAkJeuZ2s3DBAsnO6Ti/f2DghoGBgSvy+fxFjuOYj/Ax3/fxPA/XdWcrlcqLjUZjv4g8d+DAgerExARxhAR9vT1qxfJLF126fMW3F35m0dcdxykAadd1pd1u8zFjDFprlFKB53mzMzMzR6ampsq7du165vDhw9PEEBLMHxxccsem2+7s7e9fF4ZRwXVdqtUqzWaTKIr4hG3bFAoFRARjTJhOp9997LHHtuzdu/dpYggJrrryyts33bahnO3IpXw/wHVdXNelWq0SRREfExEymQz5fB7LsrAsCxFh27Ztpd27d48SQ0iwetXVxdtv21BOZzqxLAdjDChFGEWEQUgEiAhaa0RAKYXve/hek18+/Ejp2Wd3jxJDSLB2zeXF4rduKVtOD1qn0MpCtAWiUWKIREAEIgjFIww9JAoI/VlGf/Fo6cmnnh8lhpBg7ZpLincO31TOZPvRMgelbERswAAWiPAJkQChAZFLGDT5yUOPl3b+6aVRYggJrrv24uLm4bXlQqEHy2RRotFGo5SFiEPER6IIAYSAtlcHfNpuwI9/ur20888vjxJDSLD6SxcVtxTXlDsLeWw7i9YWRtsoZSFiEUkEUUQURRCFNJt1RCvaXsh9D/6h9NQzr4wSQ0iw6osXFrcU15S7CwVsJ4tYNkpZGGUhIgghoImikDAM8AOPIPRouwH3PrC99Mxzr40SQ0hw1colxbuKa8rzenuw0x1gDKIMRjTih4iEGJOGMCCMfLzQJwha1Kcb/PDBJ0t/fenQKDGEBJddurD43e+sLs8f7COVzqEsm0g0WgypSEAiQjGoMECCgHbk4/selVNnP7z3Z0+V9uyb2EkMIcGypX3FuzevKS9cMI+UMwetbZSVQkRheyFe6KHTGYJ6A1otIm0INJyenNn//ft3Du87eORVYggJFp/TdevWzatHzp3fmzOSwihDuqOAMgap1kHAzucJanWC2gyh5RClHSrV+viWe8aG3/jX0XFiCAkGBzqu3rr52pHz53cvzzg5UlYaK5VB2xbR9AxaNFZnJ+3qNEFjhshxwHE4cbo+vvlH24ffPHxsnBhCgp7u1NDWu1aPLF3cP9SRzZN2OogQLG0IZ6tYGHRXJ/7MFDRrtLwmvt/igylvfOvP/z58+MjJcWIICTrzZujuzatGLvjs4FCuows7lUUrC0sUOvTx2z4qnUFqNcLGLJ7XwG/Xef90c/yeX+0dfufIyXFiCAlyc2SoeMfnR1ZeccFQPteN7WQxYtBegG2E0LIIUNBuETRreLOztFq16J2T1b0PPDp+55H3Tu0nhpBgTpqhW9ddOHLdqsuG8pkcllhosdBugEQRdmeeIJUi8l2U38ZtNKg2640DEx9ue+Q3+x58/2jlQ2IICTI2C75243nfu+n6yzZ0WlbKCTRG26hIo8RCZzL4HVm8Rg28NiZlqHn+5Iv//E/ptzsOjh39X4U4QoKUQV1/7cDNX/3K5Q/1WLrL8TS2k0YwaGWjHAdVyOPOzuDVazgdWaYa7uTze94p7dj19tjRY6eIIyRwNFxz1dz169atLM/LOl3GFVKpLEY0EoJ2UphcHrc6hdusYXJZzlTdyedeeLv09AvvjR37oEIcIYGj4YoV3etvuXlleWFfviut0zjKRnsBXquFZduYXAF3ZhovcAmzDjP1cPLJXW+Unt9zfOz4iQpxhARK4OJlhfUb160oL1o0tyubzmFaIbrexEhElE5hOvI0qjMoo2lrYabG5BN/fL306sEPxo6fOEUcIYESWHzunPWbvrmsvGRxb1cm04VpR+h6HSsKCFNZTK4Tt9FAtNCKfCpn/ZOPP7F/+NDEmR2nTp8ljpBAgP4+58sbv7Fs5JKLBpbkct3oCOwgJHRbBNqQ6ujCb9Sp16uQdnj3ePMfv/v966Uj/53+99npGeIICQTIOMy7YdU59914/fJbsh22sS0LS9s42sL12tjGxp8+Q7U+jcrneP3w5Nj2HW+VTlaak1O1GnGEBErAgO4rWCtu3/SF+5d+ruuaVNrBKAdLWYiE4Hs0pyughEaUOfWXv03c//KeY78+M9tqVJtN4ggJlAgG0BKlll3Yc/PGjat/0Nnp9GYcbTmWhRKfKAyjeqM9WzlZf2vf3nd37Hvt/SfqDalMu62o2moRR0ggImgRBESrcN7Spf0bzjtn7trBwa6+eb3d5AsZarWm++ah9/YdOnh0e+VE8xVEN0WpaNZ3qXtt4gifsv8DziTePzZzfQQAAAAASUVORK5CYII=",
    "pliers": "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAIRklEQVRYCcXBa2yV9R3A8e/vORdOj6WtQKHQll65WyoQLi29nEJrTJxzL5Zse7FXbsmysQ1vKPGFm5dU4yQumZbd2OKyxVum2/TFFsVMZ5QDyq2CIFBaWltKac+lPec85/k//9+GyZbteSPZGz8f4QsmBKxfU13dWF99x5WZuT4Hb2jxgthz5aXOcVGjCP+32TmPF14/Q5AQsLl1xdcb61fsnfNkbX5uZrpqoTy/qiH+k2ikOCZqrarybyLC9UplXPoHkgQJATff1PzQ8vrmB10TjvimoGE7d6W5LvrYkkX6mxA26wj/ISJcr1TGpX8gSZAQsGVT8501tXUPZfPh2ogTpliY1Vgk+9bqpvJHK+L6TsgxBuEz4giiXJdUxqV/IEmQEJDY3rS+qanu3onp8Fd9Ey7xfYPnpvPVi6KvNtZG98aiZsQRX7nGERzluqQyLv0DSYKEgJ1dDfNa1tV9ZXiCR2dno80WB1MsECU3tKo59sDiBeFXw1IsChZHQlyvVMalfyBJkBDQ21lL25ammvEr7B2esN8ydl40JCFMcdZbUKGvNNVFHy4v0dMha6wDqICI8HlSGZf+gSRBQkBfZx0dW+ujs/nIjjPDuUfTc+H14UhJxJiC+l72alNd7NnGqpKnY443g1pUQET4PKmMS/9AkiAhoK+zge6ty7ESjV5JR247N5x+wPWjWyQSJj+Xpbyk+KebVpTtujFuRwXlGhEFBBCEa5SgVMalfyBJkBDQ19lIom05ECJXjC0aGZ/dPTZZuMtKSdwYn7K4eXtNU+meBaX+UVHfA1URxUFAHUBBLEGpjEv/QJIgIaCvq5metnpA8XwnlHV189Bw+sl0NrTCLUYWlsR0bsmi0MHqyujL82PyhuPkJwXBwQEUsCj/IvyPVMalfyBJkBDQ27WKRFsjDj4Gg1HKcgVpnZ6WbUMjhbsJOUvmRTFhmz+/oDzyUk1N5JVY2H4cccJ5B1AMoPw3ESGVcekfSBIkBPR2raGnfQWO+ljHw4rF+kImE0qcPJs9kMnlG8LRMPnsnLXGzTQ0lL3TWFf+TFmJHnTU9xxruUZEEOEzIkIq49I/kCRICOjrXkeifSWCRdUDx8f3IZORxOHByQOp7GzNqpXVF65MXp2fnqXK+kVvSWXk0KrGiscXlYffD6mXRtWKgINwjYiQyrj0DyQJEgL6uteRaF8FWAQfFYv6ynTGJJInxw5MTWUq2zY0/HpeVHJnL2Vvn067K3xTZOmiWLKptuz1xZWRF8OOuehg1UEQFRyEmYxL//4kQUJAX6KFRMcaUB+sD+KDQt6V7YeOj/xidGy6sWn5jS+vW1XV7xotPXdx6u7xieytaqPl0QiphrrSl5rq5u+LR9yzotaiIRxHSWVc+geSBAkBfYlWEttXgyhYA2oRUYxxao6eGn/s7PnJr0Ucb7Q3sXZ3+Q36xkzabLg4mv7+yFjuDmPDJdGwmV7bXP5cXXV8fzRkPkFERSzpTIEn9h8mSAjoS2ygp2MdYMD6qFoEg9XwvHNDqV3HBkcfzOVnS7vam/c3VEcetsbM5IqhdWeG0ntHxuZuM35ofkm0ON1UW/ZCU335w7GomUB9UhmXJ/YfJkgIuKVnE4mOFkQNWB/FRzCo4kynbXvyyMV941Mzm1tbqn5/U3P5/REnP6Y44Wze2Xh+OPvDkbHcl11Pb4iG/Yub1i+5a+lC52/zwiafyhR4fP8HBAkBtyS2kOhoRdQgakAtIgbF4PmhuveSI/s/uThx6+Kl8UNtG2sfrIh7bzpqsDYUyhUjG06dvXrP0Njc7YZQtLKCt1rXLnx6cYX/RiY75z0xcIwgIeCWnm30dGxE1AJFBAsYVD2sOrWnz8787MjJ819ScWe6tq1+rH5Z+KeOX7RqFR/CmazdcvTU1FPj04UtYIs1VaUHt7Qu+kF+LnPhyf2HlQAhoK+nnR2dm0F9RD3ABzWAwSplE1Pu7iPHz989efXqvPrlC19t27h0dzzMZawHeFgj5Zem8rtOnrnynaspauZFQ5c3b6jcU1YiL+77+TsFAoSAvh0dJDq2IvigBjA4akANimW2oFsOn7jw+MVLV7pFzERvR+O9yxbGXwtpIYt6CA4FX6pGLhe++eHxyT2FoiyoWhb6c1NN+VO/+t17/yBACOjb0Ul3x1YERTEIPoKPWA8wuD4VQ6PTuz4cvHBfOp29oWXFgr/fvHbZj0tj/ttYAypYEcl5zsqjJy4/O/pprpOIe7l5ecUf/viXY/cTIAT07uyku7MNwYL6IArqI2pQNXh+0fGttrx76OQzo+OzbfGYc3Xj+uqHGqrLfhnCM6IGAYxPdGLK3HZscPyByczsxhvL5HTy8PB6AoSA3p1ddHe2AYqoDyhgUHzAghoUv3R4ZOrOEyeHvzedzdZWVZb8tWPz6kfKSuwJyHkOiiLk3NCi0+emdw9+PH5XWApXPjpzuZ4AIaB3ZzfdnW2AImpBFNRH8QGL4KPq43uy7MypkT0nz138ruvlTHPd4tc2tdTti5UUjjjqGRSsRkKT0+72t989+1tTnHMGP5mqJ0AI6NvZTXdXO9eoWkABi6gPomANYBElUpj1Nn8weOaRS+OT26x1bcu6mudXr6z8UUS9MUdBrZIrmsZTH4/fk55JRd98f/jbBAgBfTt76O5q5xpVC1hQi2ABC2oBH0Fx1IlczWR2Dp4+v/vSp2M74nE+2rG99b6KePgtx+Jb6+GLiXhGFqbTOXn6lwfHCRACNmy4mfUt6wAFVcCCgmABRdWCWEQVQfHVxnOFwq3DIyPfsH5xZmXD8gOxqBwWVV+xgI+i5OaKvPjahwQJX7B/AmZUPF3KS/ZIAAAAAElFTkSuQmCC",
    "roll_luck": "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAItElEQVRYCcXBa4xc51nA8f/zvufMzM7uzl68a3vj9c6xG3sdmobQS0zS0jbZ3SRN1VZFiIugAlo1UhECUZqKCkLFpUg0jSpapILgU6GlCKlCfOqdtpSAzzaOd+wkJnYuXq/t3fXsZc7Mzpzr+5BtSFQd8b2/n/ATJpQ0Gg3m5ub4f4l6xvOC8YmJN01OHDhs5Eco8oL8Zb1ebz2KohfieHDZiIl4jdJut1lfX6dMKAmCgKWlJX6cNRanToqqmzk0d+QXb7v9px8+PD17ymKFokAKJYnjNNrtXV7f2PzBldUX/7XfiZ4q8qIt6nJHxsrKOcIwpEwoCYKApaUlfpxTR+E7n4PVdzfvnP9o49D0XTW/UfXFx1OQFIbtkHrOK9Je3In3kmc2r67/x+a1G9+LtrdWlP7GSuspwjMhZUJJEAQsLS3xGoFCHIN6drSYrz9SOTb2q1ldJg0eLlfifkLezZn0xpgdnmFmaJqhrOZMv7Iz2N178oWLz3x2Z+vq186vnOWHZ85QJpQEQcDi4iKvEci8nG4ju7t4w8hn5Ej9rrziPKuWrHBs7XYY9BKGqDDCEBN+gwNmgpmhowylQ5eitfaj6//z3D+fC5/gyfAJyoSSIAhYXFzkVU6UpJLWksPmPenrRz/lDtgTGMVzHklRsNHZZpDEWDFYFawKtazKBJOMp+OrY8nIZ3Q9/vsz3/za4Ox/f58yoSQImiwuLSBqEIXMKnu1LLCnJj4Rn6j8WlpL6yIO6yx7ScbN7W3UKagDFCeACn5ikZ089m+a5aBy7K8vfy/8zye/+51rlAglQdBkcWkBcYIgJF5uo/H8Tv/2yU/ls7UHEi8FC6KGaLdL1OkgCM45nCjOKKjgx9Bb28FtZoPDZmY5On/1by/8+xNfpkQoCYImi0sLiBOcKEk1H4tuKX7B3tZ4hMn6fGod4nukWcbOZps8TlABp4oDnAFbCKaTEq1to52C0byeRCvXHrty5tlHKRFKmkGTpaUFDIZYcpJGccSdGv79rFn9sKvaEWcEsYZu1GVnextRRVVxvEzAYfAyR3qjw2Czh9cXhvOabp29+um1s5f+gBKhpBk0WVxawBpL1yb+YJq7/TdMPjKYkvudpWKMocgLdra3GfT7qAiqyj4RAQxmUBC9sIF2U/zE0/G4fmXnmeufvbT89OcoEUqaQZOF+xcQEXpD6fSgWfmgOTn2kaTBnKJiREjimK2dbbI0Q8SgKAJYBBDcbkJ0aR0vhUrixweTxr9tXbz+dxeWz32LEqGkGQTce/8CSsHeuLsnu63+CZ2tL6Q1HeJlAvT6e2x3O2jhEKcoYBQ8MWhe0L/RIb0a4aeGauy9EOjBP7/x7OrXzy7/8DolQkkzCHjnAwvkkpr+YX7F3TH+yXzCP1H4ilEhz3O6ez16yYAiL8A59glgEdjLuPHsKvWBj58ahpNKOO8d+ciLFy49tby8rJQIJc0g4B0P3kdSyw7mx6sfy081fiOpuGljDdYI/X6fqNsjyzOcU5wqKooCxgnc3GP3+Q1saqilXj7lRr9/a2Xmdy+ee/rCmXCZMqEkCALe/uC9dCfS26tvnP6rvSnv7ZnJPWsMzjmiKGIw6FM4hwJOBRUHCpoUZNd2iK93MbnkY+nQS3Pe9D9MyejfPHPu6c0wXKZMKGkeC3jrQ++sdW7J7vPvnHosrstPqQWLkKYJnSgiS1MUUMApqDiME4oooXdlAzo5NvN2Z/LxrzS9qc/XpHrxwrnzbjlcpkwoOXp8zr75fW87nt5W/W1OND6UGjdsjUXUEccxnU4H5xz7FEEV1Di8TEg2InaurFNNPCqJt3GU6cePmANf8I3Xa62cZzkMKRNKZm6dnTr9gXvfU8wPP5zdUjldUIhgkMLR7XbpDwa8SgFVQcXhp9BbbROttaklPo28vjHnHXx8yox/wYrXa62ssByGlAklB+ePnPzZ31r6qL119OcHDaZzLcCB5o5Op0Oe57xKAVUBcRBl7F6+TtFJqae+m8pGLs1WDz0+IsNfMnj98ysrhOEZyoSSw3fMveX0xx/8SzdTvSuuuGGHYrEMen26vS6qiqryCkGdIlqwd71DdHkLP7c00sraMTf5j9NDB75otfKcRYpWq0UYhpQJJbOnX/fQW/743V8eDOejucWAQZ3S60TEccw+VeUVghVDvrfHzkttshsJldxjPKl+e75y+NExf3TZOZNbhFarRRiGlAklc/ecfP/pP3nvV3t+TGEcikeepUSdDnmes09VeYXgYUm2IrZe3ER2C2qpn0xkQ1+ZH579s7rUnncOLEKr1SIMQ8qEkvm33vH+hT/65a9u+hH9SkyO0u1GDPo9VB37VBUQRCyeswyu7bL90ga2D8Opv9qsHvqLGTvxT776EQqi0Gq1CMOQMqHkTW+7+70f/tOP/8tqseFf0w3puIiN3iZ912efqvIqp4LNLN3nNujf6GCdMJbUzp8cOfo74wx/1zoDCKLQarUIw5AyoeRn3njX3b/3h5/8tEx6r79WbExcTzZ5bvd5drRDLgUqDieKiqIIyW5CdHED7SR4heRT2XB4qhF8bEhr/2VU2CcKrVaLMAwpE0pOnDw19eu/+fDi7PHmL9nR6v09kvqNvTbrgzZb2TZ7pktP+gy8BNSxfXWL7uo2tdhSS+x20zvwpaO1g48J/lVRYZ9BaLVahGFImVDSbDblgXc9NDw+PnV6bu7YB8bGpt6cC3O7yd5wO981N4s27WKHyPSKNB7k7bV17e/2tJqa9Ym8tjzrj39x3A5/wxkvUxH2WYRWq0UYhpQJJc1mk3sX7kPEq9XrjeboSOPnRkcnHzDV6j2J6i2dbEAnHdBLBmuDpHc+7kddV+SqcXxuRMy3G8a/XMXsAqpGUBEsQqvVIgxDyoSSRqPB7NxRUMEaaxU5ZMQc9/3q66xfmchVyYqCNC+2nctXERcLiivym0bdmgeJ8H+EHxGEdrvN+vo6ZcJP2P8CZjKbXRr7RCkAAAAASUVORK5CYII=",
    "scroll1": "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAK7ElEQVRYCcXB2W9c133A8e/vnDv33tlnyOEiUqQ2S6Qoi5b32oodQ0GDJG1tZ5Hs2AWyNE7SFgHy0hZFH4zmISjgp7Zp4dgo0gZpakl2HcR20jaJ4122Ja+SKFI7JUukOJzh7Ou953QIz0P+g3w+wu+Z0Ld96zif/dStWKslGkvNZrNDj61Va7cYawmCECWC0hqUQimFiMZag9YOItIU9MsiKo8IoQ1p1Jum1Wy91m63j1hr60DFWGvpeeWVV1hcXGSd0Ldz+0bu++wfSMSNT4+MTPzd/MlTXxATRnuIRBwEMAKhNThuhIjngQhBGIIVGwSmU280TbvdQWmN50dxXe+q7yWWIo7/a4t6P18snmm2mudefPHF9oULF1gn9O3cPs4X7r0zOzS86dFrV1YfiWsbG4xGiIhFiSAKdCSCE/XIjuTIDA0QYMEKoLBAaAxBaGi12tSbTcqVKsXVKleuFpfqjSDYOLH1Qic0/3HomWeevnD+QoUeoW9mx5h6+MFP77M29YNWtTlFq8rEQBptDVqDiKBdh1g6Rio3QGIgBRGNQrPOWovBggXLx0QEa4VmK2Dx8jVeefVdu3nrzHsHn372W/MLp4/RI/TN7Bgb+/affenRI2+e+oqD4w36DlOTY2gMSim0UjieIpp2SQxkSGQzKC8CRlgnyvIxAQsigNAjgBAYwzvvn+HE3JXuh6fOP/DWW0efpUfo27VjbNcjX9//+Eu/PfaJdq3Dto0bGIi7eErjOA6e5+FGHbRv8RMxvESMbG6QeCwOAkoJ65QVhB4FIoDVgCGQgMXLBX71m3eZP3/1wBtH3jpMj9A3OzOx58H9n3/y0ulLt1QLq5xfXMSi8JRDzI1gRCGOJqIDXDeC5/mkMmlSmTie75JIxEgm4sSjUeLxKLFkDD/mopVGKUVghRMnL/PBiYvMnb944I0jbx+mR+i7/eYd9/3hp/Y+pRpdfziWoF6v0+12ScYTaBGCMKAbhoRhgDWGIAjoBAGr9Satdotup00QdAkDQxgaQmtwYy6xVJJUNku3C/l81dx0y23zPz38zLdOnlp4jR6hb+/tM/vvuuOGQwPaJ2aFVqOJUuB5UYLQ4DgarUCJ8DEhCENWyxWicZ9UKoFgEQuBEUqVKoW1EpeKZUrtILzjjtvXkvHEfKVS/Yennv75i6fPXWzSI/Tdfefs/tv2TB0a0DEaa2sEGAYyWfL5NYqVOkODGUayKSJagwhBEFJr1BAFxgYM5gaIxz0sBtCUanWsRHh3/iK7b7v9WK2y/FirUT9hjHP2uf95tbNwdpF1Qt8n996wf/d1k4cmMkM0y2UqjTqpZJK1tTKlah1DSDadIOq7IIquMYShIRb3ERG6nRaxaJSIEyGeSqB9Ta1luXSlyPYdm/81f+3iX4uoukHzs1+8zsLZy6wT+j65d8/+mU2jh7aPTmLbbbo2JO77KDSVRoNqo4pSFmMDjFiiyTiu7+O4DlhLaa2E4zhgBNfzSA+lWS01KZXbjAwl/rFeXvlbUdIMEJ594U3mz1xhndB3z949+6cnRw/t2DAJ7TalehXHWoZzOdYqVTqmg++7aE+THc6wYXwUN+qjIg6OjlCt1SkWCliEIICI73B1qcCJU+e56cbr/7N0bfG7lu6qQXjmhaOcOn2VdULfPXv37J/ZMnZoYzqHi1BtNahXSkSjHpV6DaMMYxNjjI1vYHh8FLTCi0YJwxDtaBwnQqm0RmGtQLdjSKfSGAM/Pfg8n7j77sthbfWbnVbp/yzGHH7hGHOnr7JO6Lv7juv337zrukNJ65Hyfbo2JBr3CU2HQrVENpdmemaKRCrJmXPnabY6IILv+2glrKzkmZyYpFqrUK012bxlE0rg4kd5Xn75aPiZfXf9eyF/9m8IO4WDzx/j5Okl1gl9N+2evOeB+z/948pSZcK1UKyWyA6msAoS2SQjY8Ns3jxJaEJKpQojI6MggrUGQVheXmZ4eJRqtcrS8hJKC4O5LO1Oh6PHFiiXGvnpqdHvl/KLjx9+7r3WydNLrBP6dk+P7vrOIwd+uHyxuFeFhlq9Rtd2iPgOkbhPbjjH7Oxugm6XfH4Vx9F0g4Co74MIy8vLDA4OUS5VqFTKZAezRGMu8XiUVsvyy/99nantW48ou/rtHx985cOTC8usE/p2Tw2P/cXX/vjRSlm+Yhpdr5jPk8wlyAxlMFqRSGXYtnUrNgzJ51eIx+MopYhEXFDClStXGR4epVyqsFoo4PsOIoZtmyep1OqcW1zh+PH56q03bX/sX554+p9PLiyV6BH6ZqeG1VcfuHNfMrvlB5WV6lSrXCE3liOeTXL+8hU6QcjY2AZinkejUWNsbAzHcdCOJuK5FAoFhnIjFAtrfHTlKtlsksmJcdyIplKuUm11+NVv3rDXbdl04icHn/vG8bnLb9Mj9M1OD/Hl+3ZlB0a2f69T09+srBTd8U0b8NMJlvJFLMLw8DCDg1mq1TLddgcrQqfTJggDOu0OrutRrTbodgKGhnPkchlSyQRht0ut1eHoOydpNlrBm0ePP/DG23P/TY/QNzud48F7d4ofH74/ogafqK9VcpObx8ltGCNfLFMolTBhSCqVZCCTIQgCkpk0YKhUq9RqNRr1JqGxCMKWLZNYQrRSRL0oxXKZs+eXuHB+kfnTlw689Pr7h+kR+manczx0704cN3VXOrP1R17E2+b7mkR6gEq1QddAt9vBUZpUOokf9RGlCIIOIZZisUCr1cbzfNaNbxwFE6CswhGHcr3BxcurzB2fY+HcRwdeev39w/QIfbPTOR6+bxoRLzcyceM/5QaHv9yoFdGRKLV6CyMKayxBt4O1FjcSwfFcgrBDs93EWoMb8XBdF2st4xtH8d0IGodWq0Ol1uDipTxzJ+dYOPvRgZde/+AwPULf7HSOh++fRkeiMxu33f54KjFwV6dZpd0NSKeziChEa2xoyefzGGNQjtBoNYj6HrnBHFoEwhCsIZVMoZRgrKXSatNotpmbv8TKynL7nfdOPfjqkbmf0SP0zU7neOjzMyqR3HBfenDrE9l0KtftNAmsYnx8HEQQUdjQ0Gq1ubZyDWtDYok46UwK143ghgJrNcrFEumRHNZ1sFqzVq/Tage8dew46XT0vYNP//Ib7x2//C49Qt/1Uzn+9Is3Dw6N7vx+rdL82q7pzZFqrQZOlKGhHKIUvysMu1QrFZLpFFprbDeke/Ea7csrdJtt4htyyEgGnUlTrtep1Fu8/Mbbdvb6Lb/+4ZOHv3N8/toCPULfDTtHs3/+1c88VG37f5VNRTddNzFMoVwjlsqQTKUQsfwuEYu1FhGNApbPLVJ5cw4KVepiGLx+G6ltk5hYjFa7zbnFK1xaXqldtzn190/+2/OPn1hYqdEj9O29dWrfF+/d96O5hY8mbpydlkzSAzGkB9PE4jGstYgISjSiFGItSoFSGqyBdkBYqGJbXephQIOA5bUifiKJcqO8duSY3bJ1Yj4i+b/8yX+99tvj8yusE/pu27Plxq8//EePnltcuXUlv5ZttgPRghNP+I6I4DgarTXJZIpoNIrvuXiei6MdtFZorRERlCgQzbrS2hqFUpUz5y6RTEZKe2bHvlcpXHjyqWc/qB2fz7NO6JvZnnO+9Lndo9FY9k9iicy0FS1BwA3AbmstohQmDAnDkG63i1IKBKwRrLUopVDKwRiLCQ1hGNBudwitEIvHyWWc99cKZ79rus0PD//iNCfPFFgn/J79PwLWCmyi5mR6AAAAAElFTkSuQmCC",
    "scroll3": "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAKsElEQVRYCcXB6Y/c913A8ffn+7vmN/fMHrO7rr3ejRPnsJO4JCHkqKjbhijQpgTsHDxAgYaCEBJCQkjwIOJQhZQnqERqUB9AeUTtlFStQkuSBmjc2LV37Ti24yO242PXXu/s7ty/md/1/bKTzv/Q10v4JRNGtirFw5ZHYpR4teq9tz342VdSz35AK0UiYESDZVCWS6odtAGNkGiNRvqp8H8GqQtCGEX0+4HuBf1DqU4Pi0jPcZy2ZdtGLMXCwgLLy8sMCSPblcXnxBarVLrzrt/c+zfLaecZy7V8P+Nj2Q5iQKMxCJbr4XkeKUKSpiRJapJUR4Mw0v1+H2MMnuNheZkbbiZ3E6M+iqL0/fWNxrEwiS4dPnIkXFpaYkgY2aYUn3Ocyo7HHn1Zz02+5OVUdjzrYVkWIoIRG+X4OL5NpVagWC2BpRAsjBHAkKaaJEmJBiG9IKDVGbDa6LK0tBr1gqRXm9xyqtcffOeHb775+vWl5TabhJGtIupL0zN75/Y+/qouZ3YSdpger6KU8AsKL5PBL/pUJovkykWwLBDhUwKCwhhDmmpECaIsYq0YRClXr93k0HvHzMyW208cfOP7X7946fICm4SRaZGZ537tsZdXsur3s0Xfq7qKHbNbEKVQSiEi2K6DX8hQGCuSLxexMxlEQOsUMAyJCGAQAUTQWGhAGzhx8mNOnlyKP/zo3LMLi8ffYJMwUlNyz4tf+epr59v1x6Io4LaZKcYLeUQE13NxXBvl2HhZl0w+Qzafo1Ktks37iABiAIOIQRSfElGIUSAQG82VpQ1+/NYHXLj0yf6jR48dZJMwsiXj3//CV5/6dl/FDzRbLS5+/AmWsrAtC8e2sZTBEo1tK2zPIeNlKJbyFIpF/LxPLp/F9z1yeY98MUc2m8HPFPBsF6U0EXD8zFWOLlzm4uWr+xcXFw+ySRi5o1Z7+ukvPPofpZKXqeSz9IKQNIV8Pg8Y0iQhTRLSNCVOEwZRRJwmdPshvX6XOI2Jopg41WitMQJexqVcKlMoFBikhpWNrp6dv/vc69974+vXl5YOsUkYuXt2674nHtpzYNtMlZyjaHW6OI6H57oMiQgCWEphDBiBKIlptBr4OY9yuYQBUqNIE0PQC6i3OyytNVlvddPbd+5qGFHnPrl67R9/vrD47kaj0WeTMLJ7x/y+x+67+8C26Qn6zRZxqilWijQ3Nmg2moyPVRirVnEdByVCnCT0BgGJjlEKKmNFsjmfoTQ1dDsDYtvl5IWr5Eu1hYXFD17p9/unUdbF6zdvRO12myFhZM+ue/btuWP+wO3TY0TdDt0goFgqslqv0wl6GA2lchnfzyBiSNIYA7iei7KFMByQy/vYtk02l8PNZOj0E85eXglu3Gy9fPbs+VctSwa241Lf2KAb9BgSRvbs2r1v947tB+7bXoM4JElTstksqTH0ogHdIABt0DoBpckXctiug+tnSJKYVqeNEsWQ5/uMTU5QX+9y9drGjYXFj/at3Fo9bFnKYCma7Q79cMCQMPLZe+/dt2t+9sC9s5NIHNLp9VCWRalSptPvESUJtg2ua1ObnmC8NkE2n8N2XUQJ3W6PjUaTNElItMH2XFZWGiwunu+trw/++sQHp/9FWSpEKTpBhzCOGBJG7t+1a999d8wfuHO6jCeabhDQ7fZwfI9Gt41yLKZmptmydZrp6UkQcFwX27HRgFKKVrvDxsYGUZRSLJdIU/jud99kaur2999++6d/0Wg2jqHQQRgQJTFDwsjOHbfte3D33Qd2TBQouEJiNIVikV44oB30yJdy3LnrTkqlPB9fvEC/P0CUjeO4eJkMS8tLbJ3dxqA/oNXuMje/HWMMy8sbvPPOsTSXm/i3t956568SHa+HaUSSpgwJI5VC8dd/58tP/fuYp7fmrZRGu0mpWkE5NtlSjqmZGtu2bwFjaLYajE9MgNgMpalmtX6LydokzWabW6trWDaUyhXiWFhYPM3yUrd+9erqN46fWHwtSuNBolOGhBFLZOfzzzzzzbmpwhezkqhme4NIx2TyPl7OZ2ysyj333MPQyq2b2LbFIIrI+j6Iol5foVyt0m71aLfblCtF8vkCGT/LIE750X/9DKFw+L/f/skf19fXP0yNZkgYUUj2kQceeunzj+75+0w6KDRba+SqOcrjVVIM5WqZ+bk5jDHU63V838dWCsuysCyLlZWbVMfH6HQCVlfXyPg2WifM3zZPs9Pl+rV1Dh8501lf773yvz899M8a02STMCIIterY488/+5VXpwve7m57QyY+M0m5WuLytatoY5iaquE4NlEYMjMzg2UrlCj8jEe9vkZtusb6WoOlpWWqY2W2bKnhZTKsrTfpBTHvvnvERJF3+vU3fvi1YDA4yiZhxEKwRWUfefzBP/zCw3v+QYfd4pbZKbKFLCtraxgDtckJyuUSnU6HNE0xxtDr9RBRDAYDfD9LEAT0+wMmxicYnyhTKhcI44huEHB88RyXLzWTw0ePP3vl+vX/ZJMwYiHYIkxtmXhi/9NPfqeYUVPb56aYmBqn3mjSaLRIk5RyuUixWCSJE8qVMkYbut0O/cGATqdLkqQMzc/PoXWCbQuen6HZaXPxwg1OLFzlzIVL+0+d/eggm4QREXCUkC9kd+7/7d/61q/u2fl5z02ojJXYaHcwWhFHEZYoCoUCvu+D8KkkSWg0mgzCAbZjYYxhdvssWqfYSoEIrW6b69cb/OzQec5cuLj/1JkzB9kkjIiArQTHtgu/99wz//TUEw//QdRfRywhCEOUcjBaMwgCjDH4vo9tOwz1+wFJkmB7Dq7rMDQ7uxXX8cAI/UGPZqfN0vUmRw5f5NT5j/efOnPmIJuEESXgiODncuN/8tIL33zs4buej8I2YRxRyBdwXA8RIU0Smq0WURhiWQ5hGOK4NuPj4yAGozVKoFQoYIuDAXphQKfX58zZa5z68Eb48xMnn7v0ySffZ5MwogQcETXzmZkv/dGLv/utu26fntMmQmvN1NQUIoKyQGtDHMfUV+tEcUI2m6VSKeG5LmJANzoEG03KMzViS2E7Lo1um/4g5f0jp7m52j3xvR/86Gu9oH+cTcKIAlzHHnvyyb3feGjP3Iv3797h9IIelmUxOTmJCFgCxgDGEEUR/X5IsVRCKUMaxqTL6/Su3CQNQ/IzEzBRQZULtIMevUDzzk+OmrVG8M4PfvzWn6XanGeTMGJbVuX+3Xe/8Mijv/KXO3eMz942O0W73SWbzVIpl1FKEAxgEG0wgKUctE5BDDeuXCN4/yNY69CVmMq9Oyju2I7xPHphzJVrq5w+c6X7wYfn/vbk2fOvGeiySRiZ2za79ze+uPdfw7i99b7d81IuZRAD1WqFbDaLiEGMwbIUlhIEQSmF1gYRjU5STL2FhAndZEDLRNxsdSiWJjDicujQgokT69xbb7/7p2vN1v+kxjAkjExUx/Y8sXfvy9rEDwb9dgXRYtmWnS/kbVsEUYJlWRQKBfI5Hz/j4TgOlq2wLMGyLJRS2LaNCJsMrWaP1XqTS5euY4zTvHWr/ndHjx39dmJ0N9WGIWHEEmV7ypkaGx/7cq1Wu7NYLkihWLgPzG4RwWBwPRfLslAiICAIiAEBAVzXxXVdhCFNEqUkscYY4dbK2gfvHXrvz4Ow/6EBDL8g/JL9P67G+11lVXZaAAAAAElFTkSuQmCC",
    "small": "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAIZklEQVRYCcXBa2yV9R3A8e/v/zznOef0tKc3aLFwuLWASPECBbk6yoYiM84sZi5mc87oiyV7sYCLxkWNCZsLG7A3xsxXm4tZsmXJsjTdNAaYpUJsCxPGraUthZbeb6en5/78f2tdzLKT897PR/iKCUU0bojRsLqWL1kVQABBVQBBURQFBaugKoDBGo9s3ts+PR1/NiC+DZr8hHHM5Mjk5Kc9fbcuU0Ao4tFHNrFjSz1gUMBaQRFQA2oAwaIoC1TxVVErWHHBjTKTCD3dd+vW8aDJVEo6nshb5ocnJ9+92n3jBAWEIh575D52bF0LCKhgVbDKAgfUAIKqogKqimWBNSguvokQT4eevtp97fjM1N2Vms1RUXkPE1MTJ3p6rh2hgFDEwa/dy84tqwGDqsGyQAVwQB1UFauKCigLFFDBEiBPqGwqbX98e3Do8MTYyJLpqVkcpyxvhBO9vddfoYBQxMF969m1ZTVgUDVYFgmoA+qggEVRQAFRQMEnYFK+t3lkcubX8+l0cz6bd+JzyTzqXpmLJ05cvnz5fQoIRRxsXseuratADWCwCKqAOoADCopiURBADaiQybuRqYT/XDwx93o2k7kHMZlQScmF0tLSd65f6/uo/dOucQoIRRxsbmB30ypAQAVfBRDAATWogqIoFsHg46BqSGbcqmTGfWpmdvQ1P5et97zglcqqil+GQt7fLly8ET/TdpFCQhGPNzewqynGfwmKAQRVg6oBBEUBRcSQV1fSWdd13PI9JeHSAze6rzxlbW5FeTT6h4qyyNtGdKjjYrd+3PY5hYQiDu1vYFdTDEUBBQQwqDqgICqAogIqhkzeC8fnnT2uU/KCqL93ZGI0EAwHTy2pKPtN0GiXI+TPX+jho08uUUgo4pv7G9jdtALLAlFAQQ2KAwpGWaCogE+AVCa8fmIy/Uomm/2O72dKvJJIW2VV9K1wgHZHc1mjyrmuXj765AqFhCKeaK5nz7YYirDIV0WNYNVBEcCUIqYMMBaXuZnAk2MT40dUcmsRmamsqv5VRTTyrrGZGYccqHKuq58P/3mNQkIRTzQ3sHdbjEWKkFeMxZiceF5GvZh45ftEgk1+NhdysYwOTzSkkrMP4OCGw6GOutqqnxpNnxebswYLKOe6BvjHmRsUEop4ormB3VtjWISscUoylGzP+pHGZNarQEIPixvensv51aI4+cw8mblhbD5FIORcX7Kk8mQ07P+RXHzOZYHyhU+7Bvj7mR4KCUUcaq5n55ZVTtK4NYlA2faEU/NSPFvWlE26nqRSJZ7NBB2bI5fLoJrHzc0g+EQrI9dqaiJHPX/mz5JL5FwWCYvaO2/TeuYmhYQiHt2/1tu8tWHTWKT2pWRd46PTTm0sZ8UjN4ekp/GSCbz5edz4LE4qQyCnqHiEI26qroo/hXTsTSc7P2AQwLCovfMOrWduUkgoYt/X122s37/zxZmNe78/HGtcki2pkrADYbJkU3Mk0wny05O4/X1ER0Ypm5jCyUDA9XRJdejf5TL4Iy8Xb3eUBQII7Z13aD3TQyGhiJ0HGl9oeP65V6d3f2tdf3WMcMjjAQM1Yhjw83RqlrlcluDwMJUD/VRc6qLk7ijB+TzlkdKxpYHRt4LZ8feDJp8Qqyxq7xyk9UwPhYQith1s+sW6nxw5cueB3d5oZQ3LnQBPO4aYwFngL1gGFYyfpzw+S+3Vi1R1dxO6OUBZNp+/J5T8q5ccfLPCy10z6qtVn/bOIVpP36SQUMS2J/cc3/jG0cM9DfczGimlBpe9jhAVuGCV8yJMKvgCruapTMapHhqivKuDmsF+Vjv5O5G52z8PpsZ+5xnNWOtztuMOrad7KSQUsfuZQ8c3vHH0cM/K9QyVhMj5PsuMg2cchq0yZoQ0YAEBAtanMpWktvc6y69fYvXEcDw63n0slBw+6TmaRH3aOu7QeqqXQkIRe7775PENP3vr8MDa9QyEQ4zjg7j4CBnAB1T5gig4CiWiLJ+bJtbfzYpLXfHyW53HSucHTwbFJo36nO0YpOV0L4WEInZ8+8Dx+157/fDopq30h8KMo6SBrAp5EZT/EYUAUCKwzM+xfHKUpec/iUc///hYzfztk0Fs0rGWs52DtJzupZBQRNOhHcfvPfzy4dmH99MXiTKJkFElheAbQyEXCANV1lKbmGXZuY/j0c9aj61I3D4ZEpt0VDnbMUjL6V4KCUVs+8ZDR1d87wcvxx85FByKrWLaCZBWS0bAF4Py/wxKCEuFhdq5GWLtH8ajHa3HYsmRkyGxSRefto4hWk71UUgoYs/+xmfrHnv81fFt+xtH739IpiqrSRghC1gExbBIUAyKYAnZPDWpDEsHB3TZ+dbemt6Ot2uz0x8EsRkHS1vHEC2n+igkFHFg3/p1DTu2PD+wYuMPp3fsXTZSv0ni0SrSxsECPoIAAQVXFfEzlGYy1PTdtEs+/2yorr/jvdr0yO8jNjXoiK+OQlvHEC2n+igkFPF4c7374La1DXe96hdHV216dnLzrmUzqzdIvLyKrBvANw4KeL5S4ueJzEwRGe7X0ovtt2N3uz+omx99r9Qm77iSsyIWo9DWMUTLqT4KCUUcal7Dw9uXm4QNrJzwql+6W7X6mcSaxrr0yoZwrqISGylFVXBTaUKJONJzyUYHe+7WTPS9U5uf+6A8nxkMGF8RC6IYhbaOIVpO9VFIKOJQ8xp27ajDx5i0emumpHTfjFf52Gy0ZmOqrKLOLyutQgU3mRoPJuIjZXO3E1Wp2dNVueRvQ5IbDKEWUVSURUahrWOIllN9FBKKePC+payvr2CRxZBVU5LF3ZxWqc8bZxOOt9LmrbrYPk/sdU9yiaDa665qrxFVFijKl0ThRt80/7o6RiHhK/Yf/5kYXQX/JNQAAAAASUVORK5CYII=",
    "super": "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAHG0lEQVRYCcXBbWxVdx0H8O/v/M+555x77mNLSwuUW7grUCgPEhhP7RgaxrZCjINsg0SdvjDRdgNnXHQhPjABZQ+ss5BFjTExUbMXZmbiss2pS6CDNizNWuiotKWU3pb29vb2Pp3n8zcYF/fqnJf7fAifM0IAgQASBGHZsoadmzZt+moqldqdSCQUTdNARLjHsizouo5isWj09/d/MDQ09IdcLtfneV6Fcw4/hABMILFlfcvG9vYDxxsaGvYoihKzbZsMw4DnebhHFEWIoggi4pVKpZDJZAZ7e3vf6Onp+ZNt2zPwQQhQX7d4/TNHn/lRMll9wLZt2XEczM/PwzAM3MMYA+ccsVgMmqbB8zzIssxt27555syZH0xOTv4ZPggB9rc/cvTJI4d/HJa1pG07sGwbpmGjUMwDxPGpeDyOaDQGkTEIjMHzPOfXv/nVq2//7e3vwwchwMHDX/nlwYOPdUaVOBRJBREDYwwcHjzuwuMuBBLAGAOIwXM5LMeC6eg4f/78uXcvvNMJH4QAjx7Z1/3lQ/s7FkfqoEgaBBLBBAYiAhGBwAFwgACPA44LGI6OilvEK6deOdf7r75O+CAE+NLh1u6HDj3YURdfCkWKQBJDEAUZDAwEgkAAJw5OHK7rwHFtGJ6JgpXHy8+fPTfcO9YJH4QADzyxrXvPkzs6FsUXQ5U1iEyGJIbASASBAALAOTg4HNeG45lwPBvFUgUvPnu2OzM48zR8EALsemxb9xeP7OioSiQQVsIQJQUik8EEBuL4DILjurC5CcsxUVkw5k91vvhCbnThLHwQAmx9ZHP33m880FFdFYeqqBBZCIwpkBiDQPgfAnGC43iwuQXD0VGa00dPfucXx4qTlbfggxBg/e613Q9/a09HTU0SqhKGyGSILARJlCAQPkOAa7uwXROmayA7kR956btdR8sz+gX4IARo2rry5P7Ovd+rra2SNTUCkSlgTIQkSmAC4f8Itu3Adk04jonRgYmR13/y26P6nHkBPggBGlqWHDpwbN9LS+prU5oSQUhSIAgSJFEEEwif4gAc14HtmTB1Ax9fvD7yxmtvHq3kjAvwQQhQm65q339sb1cq1ZCOhCMISQqYIEFkDKLA8F+c4MGD7dko6kVYpun2vz944e+//+CH+dnCdfggBKhPL2p/6Nu7u1LpVDqiRRCSZEiiBCaIYCSACQzgBMd1YDg6CkYRpm5aH77Zd7L/nWunstNzDnwQAixvqm/f882dXcvuW5qORCMISTJExkAkgAkiBBLABAbLtjG/kMPt6QlEw1Hz2vufnBh478bpzJ0pDh+EACtWL9+9/fEvvLy0uW6zqqlkWTYkJoEIiEVicF0PkhTC7GwWoVAIY7dHIUshc/Lq3Z8O/XPk57fGbnP4IAS4r3mFtmx77fENbc3PJhbFQ57nQpJCMHQTiqqCc0ASQ8jn85AECbO5u6iU9PHJvumnM/1zfx2+cZPDByHAmpamVPXG2AstbasOx5IRMZvNQlVVKEoYnBNEJsLzOARBAIOAfHEOlZJ55VbP5BNzQ4Xxa4ND8EMI0LJp7b54s/rq8o31a5ak6jExcQchSUIq1YjZ2SwSiQR03YBtWzArJsJRGZ7JLg+8d+Px0mhlor//Y/ghBNi0ZUO71iR3Va+KpRubUpi8MwnHcbBu3TroZR0CY9DCGnK5OZiGhfxCHqWcOVAcrjxVmdA/+uhqP/wQAmzZtrk9ulrtiqbV9LJUPbKzWZRKJYTDGmRZRirViLCqYGxsHNNT09B1E8a8VwrNy8fLE+XX+nqvcvggBLh/x5b26GqlK96kpavrknBMG54NxBMJqBEFkiQhk8lgamoKlmHBNl0Ys66ZdGtO5G8XTl/puczhgxBg+8772yNppSverKWTtRHA5QjLMcTjCZAEZKYymJqagqHrcGwPjuHAnYW5WFp+Ynp05vSVnsscPggBduzatk1bHj6jNUmtdakqQZJEqHIEIUWBy23cGB5GoVCAaztwLReu7sGdEbOpaPq58X9P/O5Kz2UOH4QAra27lGRj1fNunf5c3cqErEVlSCEVgiiCiDA2NorZ2Sw81wU3PDgVAsspV1ckVx0Z+WRk+MOeHvghBGhra6PGtSv33aXxEzXp2LpoTTgsySFIkgJwoFgsYPzWbejlCryKB7fMvIiR/MeKqvTXrw9cz1y6dAl+CAFad7WhecNauWhnm90q46loo/a1kCYnJYgwHROO62B+Zh7zUwuwi67nlmlqsbr0TF2k7vVrA4PWxUuX4IcQoLW1FS3r1sMhm/JObiUl+M/EsPBoqVzQdLvCODg803OdBT4nu+rlZLj6L3E1+a4I8c7g4CAuXrwIP4QAW7dsxapVa8CJw4MrV5zyw2WrtKesFx90PCvBmADGWb5Kq3krKsf/KJB4k0AWB8fw8A309fXBD+Fz9h80QyFOwTWVjwAAAABJRU5ErkJggg==",
    "ticket": "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAI5ElEQVRYCcXBT2gc1x0H8O/vzZvRavbfrFarlayVbHml2Iqdjf9GKjZ2Tya9+GIItF1BoISekksOJcQ6JAiSkJCmYPChKbSsQ5wW65RDExpDAqUxiiMlBIOjeIXkXW30b/94dmd3Zue911mIoZQeetPnQ9hnhH1G2GeEfUYIHDx40AyMNBqNISGERkRQSuH/QUR4jIjwGBGhh4hARPiJ4pzXTdPcaDQadrlcBiHw2muvXYzH4y/dvXv3F57n9UspwRiDlBKe50EpBaUUpJToUUpBSgkiQg8RgYhAROghIhARiAiMMTDGQEQgIhmNRpfOnDnz9vr6+t/feuutFiFw5cqVtzVN+43jOJbv+6RpGtLpNBhjKBaLcBwHQggIIaCUghACSin0KKWglIJpmmCMwXEcKKVARCAi9BARGGMgInDOnZGRkTv9/f3Xb968+TdCYHZ2thCPx/NKKQghYJompqamoJRCtVpFsViE4zhQSkEIASkllFJ4zDRNTE1NgTGGtbU12LaNHiICEaGHiNDDGAPn3BNC/Hlpaem3hMDs7GzBNM08EYExhmg0iuHhYRAR2u02pJQoFotoNpsQQkAIgR6lFEzTRDqdxuDgIAzDQKfTwdraGhzHgVIKRIQexhiICD2MMXied+Prr7+eIwROnTpVsCwrr+s6YrEYxsbGYNs2dnZ2MDQ0hEajgW63i1KpBM/z4Ps+iAiapmF0dBSWZWFvbw+ZTAZSSjQaDTSbTVSrVWiaBqUUeogIPYwxSClvfPnll3OEwNmzZwumaeY1TUM8Hkcul0OlUkEoFEK9Xkez2cTo6CiKxSJarRb29vZARNB1Hel0GgcOHEC73Uaz2QQRIZ1OY2NjA91uF+12G1JKEBEe0zQNjLEbn3/++RwhcObMmYKu63mlFKLRKDKZDBKJBLa3t/Hw4UOkBlOIW3FYloVarYZisYharQYhBMLhMCYnJ9Hf3496vQ5d19HtdlGr1TA5OYlSqYRGowHGGB4zDAOMsRuffvrpHCFw+vTpAmMsT0ToMQwDyWQSjUYDoVAIuVwOOzs7YIzBNE3Yto1SqYRarQYhBOLxOBKJBEZHR1EsFqFpGlKpFDzPw+7uLjqdDogIj5mmCcbYjY8//niOEDh79mxBCJEnIvQIIcA5h2VZOHLkCGzbxr179zAxMYF4PI5oNArHcfDgwQNUq1UwxqBpGpLJJDRNw9TUFFZXV9FqtSClhFIKjDEQEYgI4XC4q+v6X27duvUCIfDMM88Uut1uXimFHqUUlFLQNA0jIyOwbRuu62J2dhZKKdi2Dc/zUCqV0Gq10MM5R19fH7LZLFKpFL7//ntwztFoNCClRA9jDD2xWGwjFAq998EHH/yeEJiZmSl4npf3PA//jYgwODiIbDaL8fFxLC0tYWBgAI8ePcLm5iaklOjhnEPXdei6jkOHDiEajaJYLKLT6aBHSgnOOYgIlmUtRyKRhffff3+REJiZmSl4npfvdDr4iQegAqAlpYz09fUNZ7NZQ9M01Ot15HI5VCoVrK+vw/M89HDOwTkH5xyhUAipVArtdhuRSAS7u7twXRe6roOIYFnWciKRWLh27doiIXD+/PlCo9HIu66LUCjkPf30018cO3bsmmVZ64GJpaWlF3Z3dy9Eo9GwaZrI5XLY3NwE5xxbW1uoVqswDAM9nHNomgbOOaLRKLLZLFzXxe7uLmzbhhACyWRyOZlMLrz77ruLhMCFCxcKjUYj3+l0kEwmH83Nzf3h2LFj73DOHzmOE/n222+vfPLJJ78rl8vTiUQC00en4bQdjI+P44cffkCpVEIPYwycc3DOQUTQdR2ZTAZKKdi2DdM0Ua/XYVnW8tDQ0MKbb765SAhcvHixUKvV8u12G1NTU4/y+fx7ExMT1xljHdu2+27fvv2rL7744uVqtTrKGEMsFkM6ncbx48dh2zY6nQ62trZQrVZBRNA0DYwxEBH6+vrQ39+P8fFxdLtdVCoVWJa1PDw8vPD6668vEgKXLl0qtNvty4Zh7Gmaxp588skHJ06cWBFC+OVyWVtZWZl0HOcIEQ1WKpUBpRRLJBIYGxvDwYMHsbq6ilQqhbW1Nbiuix7GGIgInHMwxjAwMADf9+E4DkZHR5fT6fTC/Pz8IiHw7LPPFnK53PDJkyf/tLOzE11ZWfl5pVI57ThO0jCMH48fP/7X2dnZu/V6/fJHH330662trYiu64jFYkin04jFYshkMqhWq2i32yiXy5BSoodzDsYYGGNgxAACDh8+vGxZ1sL8/PwiIXD58uXCwMDAkXPnzr2TzWZvt1qtwfv375/zPG94ZGSkPD4+/o9QKNT85ptvXv7www9fqtfrMSKCrusIh8M4cOAADh06hFgsBs/zsLq6imaziW63C8YYGGNQSoGIoGkajh49uhwOhxeuXr26SAg899xzb5RKpTnDMNbOnz9/44knnngwMjKyZhhGw3Eca3t7e2JnZ2fyq6++ev677747SUQ6Ywycc2iahkgkgunpacTjcUgp4fs+XNfFxsYGpJQgIvQwxsA5x1NPPbXMOV949dVXFwmBF1988Uyr1Xr+zp07lzudjjY0NLQ7PT39L8uyNsvl8ujDhw9n9/b2UkQ0SEQ65xyMMXDOwRiDrusIh8PIZDJotVqYmZnB/fv3Ua1W4bouiAg9RIRQKCROnDjxTwBvvPLKK38nBObn5/mpU6eOfPbZZ79cWVk5K4RAwCUi4XmeLqU8rJQaF0JoCOi6jv9kGAYYY+jv78fk5CQZhqGvra0xBIgIRAQiglJKRCKRexcvXvzj9vb2ratXr24SAvPz87h06RITQiQ6nY7leR48z4PneXBdV3dd92edTuec53l93W4XnufB9324rgvf9+H7Pnzfh+/7kFJGhRCzQoi07/uQUkJKCSklIuHIj+fOn3vn6NGjhZs3b25fv34dhMDY2BgsywIR4X8gADEAUQAMAaUUeqSUUEpBSgkpJYQQkFJyIcSAlDIkhICUEkopSClhGEZnYGBgnYj2yuWyrFarIOwzwj4j7DPCPvs3wDMRXRCjGvoAAAAASUVORK5CYII=",
}


def _show_crash():
    """pythonw не показывает ошибок — пишем их в crash.log и показываем окно, чтобы было видно, что случилось."""
    import traceback
    err = traceback.format_exc()
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "crash.log"), "w", encoding="utf-8") as f:
            f.write(err)
    except Exception:
        pass
    try:
        from tkinter import messagebox
        r = tk.Tk()
        r.withdraw()
        messagebox.showerror("Merchant Macro", "The macro crashed / Макро упало:\n\n" + err[-1500:])
        r.destroy()
    except Exception:
        pass


if __name__ == "__main__":
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("potion.macro")
    except Exception:
        pass
    try:
        root = tk.Tk()
        App(root)
        root.mainloop()
    except Exception:
        _show_crash()
