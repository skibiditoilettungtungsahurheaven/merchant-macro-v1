@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Merchant Macro - setup

set "PYVER=3.13.17"
set "PYDIR=%LOCALAPPDATA%\Programs\Python\Python313"
set "PYURL=https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-amd64.exe"
set "PYSETUP=%TEMP%\python-%PYVER%-amd64.exe"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "CHECK=import sys, os, tkinter; assert sys.version_info >= (3, 9); print(os.path.dirname(sys.executable))"

echo ==== Merchant Macro ====
echo.

rem ---- 0) the zip must be extracted: all files next to this .bat ----
if not exist "macro_gui.pyw" goto nofiles
if not exist "potion_macro.py" goto nofiles

rem ---- 1) our own Python, installed earlier by this file ----
set "PYHOME="
if exist "%PYDIR%\pythonw.exe" call :try "%PYDIR%\python.exe"
if defined PYHOME goto found

rem ---- 2) any other working Python (3.9+ with tkinter) from PATH ----
call :try python
if defined PYHOME goto found
call :try py
if defined PYHOME goto found

rem ---- 3) no usable Python - download and install it (no admin needed) ----
echo Python not found. Downloading Python %PYVER% from python.org...
"%SystemRoot%\System32\curl.exe" -L --fail --progress-bar -o "%PYSETUP%" "%PYURL%"
if not exist "%PYSETUP%" "%PS%" -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri '%PYURL%' -OutFile '%PYSETUP%'"
if not exist "%PYSETUP%" goto nodownload
echo Installing Python %PYVER% - takes about a minute...
"%PYSETUP%" /quiet InstallAllUsers=0 PrependPath=1 Include_tcltk=1 Include_pip=1 Include_launcher=0 Include_test=0 Shortcuts=0
del "%PYSETUP%" >nul 2>&1
if exist "%PYDIR%\pythonw.exe" call :try "%PYDIR%\python.exe"
if not defined PYHOME goto noinstall
echo Python installed.

:found
echo Python: %PYHOME%
rem ---- make "python" work in any new cmd window: put it at the front of the user PATH ----
call :addpath

rem ---- libraries the macro needs ----
"%PYHOME%\python.exe" -c "import cv2, numpy, mss" >nul 2>&1
if not errorlevel 1 goto launch
echo Installing libraries: opencv-python, numpy, mss ...
"%PYHOME%\python.exe" -m pip --version >nul 2>&1
if errorlevel 1 "%PYHOME%\python.exe" -m ensurepip --upgrade
"%PYHOME%\python.exe" -m pip install --upgrade --disable-pip-version-check --no-warn-script-location opencv-python numpy mss
"%PYHOME%\python.exe" -c "import cv2, numpy, mss" >nul 2>&1
if not errorlevel 1 goto launch
echo Libraries look broken - reinstalling them...
"%PYHOME%\python.exe" -m pip install --force-reinstall --no-cache-dir --disable-pip-version-check --no-warn-script-location opencv-python numpy mss
"%PYHOME%\python.exe" -c "import cv2, numpy, mss"
if errorlevel 1 goto nolibs

:launch
rem ---- quick self-test: if the macro can't even load, show the error here instead of silently doing nothing ----
"%PYHOME%\python.exe" -c "import potion_macro" 
if errorlevel 1 goto broken
if exist crash.log del crash.log >nul 2>&1
echo Starting Merchant Macro...
start "" "%PYHOME%\pythonw.exe" "%~dp0macro_gui.pyw"
timeout /t 4 /nobreak >nul
if exist crash.log goto crashed
echo Done - the macro window should be open. This window closes by itself.
timeout /t 3 >nul
exit /b 0

rem ======================= helpers =======================

rem ---- :try <python> - sets PYHOME if this Python is 3.9+, has tkinter and pythonw.exe ----
:try
set "CAND="
for /f "delims=" %%i in ('call "%~1" -c "%CHECK%" 2^>nul') do set "CAND=%%i"
if not defined CAND exit /b 0
if not exist "%CAND%\pythonw.exe" exit /b 0
set "PYHOME=%CAND%"
exit /b 0

rem ---- :addpath - puts PYHOME and its Scripts folder at the front of the user PATH (once) ----
:addpath
echo %PYHOME% | find /i "\WindowsApps\" >nul && exit /b 0
"%PS%" -NoProfile -Command "$d='%PYHOME%'; $s=Join-Path $d 'Scripts'; $p=[Environment]::GetEnvironmentVariable('Path','User'); if(-not $p){$p=''}; $parts=@($p.Split(';') | Where-Object { $_ -and $_ -ne $d -and $_ -ne $s }); $new=(@($d,$s)+$parts) -join ';'; if($new -ne $p){[Environment]::SetEnvironmentVariable('Path',$new,'User'); Write-Host 'Python added to PATH (new cmd windows will see it).'}"
exit /b 0

:nofiles
echo macro_gui.pyw / potion_macro.py not found next to this file.
echo Extract the WHOLE zip into a normal folder first ^(right click - Extract All^), then run start_macro.bat from there.
pause
exit /b 1

:nodownload
echo Could not download Python. Check the internet, or install it by hand:
echo   https://www.python.org/downloads/   ^(tick "Add python.exe to PATH"^)
pause
exit /b 1

:noinstall
echo Python install failed. Install it by hand: https://www.python.org/downloads/
echo ^(tick "Add python.exe to PATH"^), then run this file again.
pause
exit /b 1

:nolibs
echo.
echo Could not install the libraries ^(see the error above^). Check the internet and run this file again.
pause
exit /b 1

:broken
echo.
echo The macro failed to load ^(error above^). Send a screenshot of this window.
pause
exit /b 1

:crashed
echo.
echo The macro crashed on start:
type crash.log
echo.
echo Send a screenshot of this window.
pause
exit /b 1
