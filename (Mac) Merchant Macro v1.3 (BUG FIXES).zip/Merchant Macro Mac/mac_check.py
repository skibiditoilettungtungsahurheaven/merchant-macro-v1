"""
Проверка Mac для Merchant Macro — запускать через mac_check.command (после первого запуска start_macro.command).
Ничего не нажимает в игре: только смотрит, что macOS разрешает макро, и сохраняет снимок экрана
mac_check.png рядом. Скрин окна Терминала с результатом + mac_check.png — то, что нужно прислать при проблемах.
"""
import os
import platform
import sys
import time

import platform_io as pio

HERE = os.path.dirname(os.path.abspath(__file__))


def line(name, value):
    print("%-26s %s" % (name, value), flush=True)


def main():
    print("==== Merchant Macro - Mac check ====\n")
    line("macOS", platform.mac_ver()[0] or platform.platform())
    line("CPU", platform.machine())
    line("Python", sys.version.split()[0] + "  " + sys.executable)
    try:
        import tkinter
        line("Tk", tkinter.TkVersion)
    except Exception as e:
        line("Tk", "ERROR %s" % e)
    for mod in ("numpy", "cv2", "mss", "certifi"):
        try:
            m = __import__(mod)
            line(mod, getattr(m, "__version__", "ok"))
        except Exception as e:
            line(mod, "ERROR %s" % e)

    print()
    try:
        miss = pio.missing_permissions(ask=False)
        for key, title in (("screen", "Screen Recording"), ("access", "Accessibility"), ("input", "Input Monitoring")):
            line(title, "MISSING - turn on Terminal" if key in miss else "ok")
    except Exception as e:
        line("Permissions", "ERROR %s" % e)

    print()
    try:
        mons = pio.monitors()
        for i, m in enumerate(mons[1:], 1):
            line("Monitor %d (points)" % i, "%dx%d at %d,%d" % (m["width"], m["height"], m["left"], m["top"]))
    except Exception as e:
        line("Monitors", "ERROR %s" % e)
    try:
        line("Cursor (points)", pio.cursor_pos())
    except Exception as e:
        line("Cursor", "ERROR %s" % e)

    try:
        import cv2
        m = pio.monitors()[1]
        t = time.time()
        img = pio.grab_rect(m["left"], m["top"], m["width"], m["height"])
        dt = time.time() - t
        out = os.path.join(HERE, "mac_check.png")
        cv2.imwrite(out, img)
        line("Screenshot", "%dx%d in %.0f ms, mean brightness %.0f -> mac_check.png" % (
            img.shape[1], img.shape[0], dt * 1000, float(img.mean())))
    except Exception as e:
        line("Screenshot", "ERROR %s" % e)

    print("\nNow click the Roblox window within 5 seconds (checking which app is in front)...")
    time.sleep(5)
    try:
        name = pio.backend().frontmost_name()
        line("App in front", "%r  -> Roblox focused: %s" % (name, pio.roblox_focused()))
    except Exception as e:
        line("App in front", "ERROR %s" % e)

    print("\nNow press fn+F7 within 6 seconds (checking hotkeys)...")
    code = pio.hotkey_code("F7")
    pio.hotkey_pressed(code)
    seen = False
    end = time.time() + 6
    while time.time() < end and not seen:
        seen = pio.hotkey_pressed(code)
        time.sleep(0.03)
    line("Hotkey fn+F7", "seen" if seen else "NOT seen (Input Monitoring permission?)")
    print("\nDone. Send a screenshot of this window and the file mac_check.png.")


if __name__ == "__main__":
    main()
