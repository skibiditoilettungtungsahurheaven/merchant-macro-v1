#!/bin/bash
# Merchant Macro для Mac — запуск. Двойной щелчок (первый раз: правый клик → Открыть).
# Сам находит Python 3.9+ с tkinter, ставит библиотеки в папку .venv рядом и открывает окно макро.

cd "$(dirname "$0")" || exit 1
clear
echo "==== Merchant Macro (Mac) ===="
echo

PYVER="3.13.12"
PKG_URL="https://www.python.org/ftp/python/$PYVER/python-$PYVER-macos11.pkg"

fail() {
    echo
    echo "$1"
    echo
    read -r -p "Press Enter to close / Нажми Enter, чтобы закрыть..." _
    exit 1
}

# ---- 0) архив должен быть распакован: все файлы рядом с этим файлом
for f in macro_gui.pyw potion_macro.py platform_io.py; do
    [ -f "$f" ] || fail "$f not found. Unzip the WHOLE archive into one folder and run start_macro.command from there."
done

# файлы из интернета macOS помечает «карантином» — снимаем, чтобы Python спокойно их читал
xattr -dr com.apple.quarantine . 2>/dev/null

# ---- 1) подходящий Python: 3.9+ и tkinter с Tk 8.6 (системный python3 от Apple с Tk 8.5 не годится)
CHECK='import sys, tkinter; assert sys.version_info >= (3, 9); assert tkinter.TkVersion >= 8.6'
find_python() {
    # сначала Python с python.org (новые версии первыми), потом Homebrew, потом любой python3 из PATH
    local cand
    # сортируем по номеру после «3.» (13, 12, …, 9) — в пути есть ещё точка («Python.framework»)
    for cand in $(for d in /Library/Frameworks/Python.framework/Versions/3.*; do
                      [ -d "$d" ] && echo "${d##*.} $d"; done | sort -n -r | cut -d' ' -f2) ; do
        cand="$cand/bin/python3"
        if [ -x "$cand" ] && "$cand" -c "$CHECK" >/dev/null 2>&1; then echo "$cand"; return; fi
    done
    for cand in /opt/homebrew/bin/python3 /usr/local/bin/python3 "$(command -v python3 2>/dev/null)"; do
        # /usr/bin/python3 от Apple: Tk 8.5 (окно макро там не работает), а без Xcode Tools он ещё и
        # открывает окно «установить инструменты разработчика» — не трогаем его
        [ "$cand" = "/usr/bin/python3" ] && continue
        if [ -n "$cand" ] && [ -x "$cand" ] && "$cand" -c "$CHECK" >/dev/null 2>&1; then echo "$cand"; return; fi
    done
}
PY="$(find_python)"

if [ -z "$PY" ]; then
    echo "Python with tkinter not found. Downloading Python $PYVER from python.org..."
    PKG="$TMPDIR/python-$PYVER-macos11.pkg"
    curl -L --fail --progress-bar -o "$PKG" "$PKG_URL" || fail "Could not download Python. Install it by hand: https://www.python.org/downloads/macos/"
    echo
    echo "The Python installer will open now. Click Continue / Install until it finishes,"
    echo "then come back here. / Сейчас откроется установщик Python — нажимай «Продолжить» / «Установить»,"
    echo "потом вернись в это окно."
    open -W "$PKG"
    PY="$(find_python)"
    [ -n "$PY" ] || fail "Python is still not installed. Run the installer from $PKG and start this file again."
fi
echo "Python: $PY ($("$PY" -c 'import sys; print(sys.version.split()[0])'))"

# ---- 2) свои библиотеки в папке .venv (не трогают остальную систему)
VENV=".venv"
if [ ! -x "$VENV/bin/python3" ] || ! "$VENV/bin/python3" -c "$CHECK" >/dev/null 2>&1; then
    rm -rf "$VENV"
    "$PY" -m venv "$VENV" || fail "Could not create $VENV (python -m venv failed)."
fi
VPY="$VENV/bin/python3"
if ! "$VPY" -c "import cv2, numpy, mss, certifi" >/dev/null 2>&1; then
    echo "Installing libraries: opencv-python, numpy, mss, certifi (first start only, takes a few minutes)..."
    "$VPY" -m pip install --upgrade --disable-pip-version-check pip >/dev/null 2>&1
    # --only-binary: если для этой версии macOS нет готовой сборки — берём более старую, а не собираем часами
    "$VPY" -m pip install --disable-pip-version-check --only-binary=:all: numpy mss certifi opencv-python \
        || "$VPY" -m pip install --disable-pip-version-check --only-binary=:all: numpy mss certifi "opencv-python<4.11"
    if ! "$VPY" -c "import cv2, numpy, mss, certifi" >/dev/null 2>&1; then
        # старые Mac: подходит только старая сборка opencv, а она не дружит с numpy 2
        "$VPY" -m pip install --disable-pip-version-check --only-binary=:all: "numpy<2"
    fi
    "$VPY" -c "import cv2, numpy, mss, certifi" || fail "Could not install the libraries (error above). Check the internet and run this file again."
fi

# ---- 3) быстрая самопроверка и запуск
"$VPY" -c "import potion_macro" || fail "The macro failed to load (error above). Send a screenshot of this window."
rm -f crash.log
echo
echo "Starting Merchant Macro... Keep this Terminal window open while the macro runs."
echo "Запускаю Merchant Macro... Не закрывай это окно Терминала, пока работает макро."
echo
echo "First start: macOS will ask for Screen Recording, Accessibility and Input Monitoring for Terminal."
echo "Turn them on in System Settings -> Privacy & Security, then quit Terminal (Cmd+Q) and start again."
echo
"$VPY" macro_gui.pyw
if [ -f crash.log ]; then
    echo
    echo "The macro crashed:"
    cat crash.log
    fail "Send a screenshot of this window."
fi
